#!/usr/bin/env bash
#
# supabase-ctl.sh — start/stop the self-hosted Supabase stack whenever you want.
#
#   bash lua-assistant/ops/supabase-ctl.sh up        # start (data preserved)
#   bash lua-assistant/ops/supabase-ctl.sh down      # stop  (data PRESERVED — no -v)
#   bash lua-assistant/ops/supabase-ctl.sh restart
#   bash lua-assistant/ops/supabase-ctl.sh status
#   bash lua-assistant/ops/supabase-ctl.sh logs [service]
#
# Does NOT touch your app code or the backend stack — only the Supabase stack
# living in ~/lua-supabase. Run setup-supabase.sh first to install it.
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-$HOME/lua-supabase}"
DOCKER_DIR="$INSTALL_DIR/supabase/docker"

[ -d "$DOCKER_DIR" ] || { echo "Supabase not installed. Run: bash lua-assistant/ops/setup-supabase.sh"; exit 1; }
cd "$DOCKER_DIR"

case "${1:-}" in
  up)       docker compose up -d ;;
  down)     docker compose down ;;          # keeps named volumes -> data is safe
  restart)  docker compose down && docker compose up -d ;;
  status)   docker compose ps ;;
  logs)     shift; docker compose logs -f "$@" ;;
  *)        echo "usage: $0 {up|down|restart|status|logs [service]}"; exit 1 ;;
esac
