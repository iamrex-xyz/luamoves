#!/usr/bin/env bash
#
# setup-supabase.sh — idempotent self-hosted Supabase deployer for the Lua backend.
#
# What it does (only what's needed, nothing it doesn't have to):
#   1. If Supabase is already RUNNING            -> exits, does nothing.
#   2. If it's installed but STOPPED             -> just starts it (secrets preserved).
#   3. If it's NOT installed                     -> fresh install:
#        - clones the official Supabase docker stack into ~/lua-supabase (OUTSIDE this repo)
#        - generates fresh, strong secrets dynamically (Postgres pw, JWT secret,
#          anon + service_role keys, dashboard pw, vault/secret keys, logflare tokens)
#        - wires the stack onto a shared Docker network `lua-shared` so the backend
#          talks to it DIRECTLY (no internet / no Caddy hop -> lowest latency)
#        - saves ALL secrets to ~/lua-supabase/credentials.txt (chmod 600)
#        - writes ONLY the two the backend needs into lua-assistant/.env
#        - starts the stack and applies the 8 migrations once
#
# Re-running is always safe. It NEVER regenerates secrets once installed, and
# `down`/`up` preserve data (handled by supabase-ctl.sh).
#
# Run it from anywhere inside the repo:  bash lua-assistant/ops/setup-supabase.sh
set -euo pipefail

# ---- paths -----------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LUA_ASSISTANT="$(dirname "$SCRIPT_DIR")"          # .../lua-assistant
MIGRATIONS_DIR="$LUA_ASSISTANT/migrations"
BACKEND_ENV="$LUA_ASSISTANT/.env"

INSTALL_DIR="$HOME/lua-supabase"                  # outside the git repo, in your home
SUPA_REPO="$INSTALL_DIR/supabase"
SUPA_DOCKER="$SUPA_REPO/docker"
CREDS_FILE="$INSTALL_DIR/credentials.txt"
MIGR_MARKER="$INSTALL_DIR/.migrations-applied"

NETWORK="lua-shared"

# ---- config you can override via env ---------------------------------------
SUPABASE_DOMAIN="${SUPABASE_DOMAIN:-supabase.lua.ibrcloud.com}"
PUBLIC_URL="https://${SUPABASE_DOMAIN}"
SITE_URL="${SITE_URL:-$PUBLIC_URL}"               # auth redirect target; set to your Vercel URL if needed
# How the backend reaches Supabase from INSIDE the docker network (direct, low latency):
INTERNAL_SUPABASE_URL="http://supabase-kong:8000"

log() { printf '\033[1;32m[supabase-setup]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[supabase-setup] ERROR:\033[0m %s\n' "$*" >&2; exit 1; }

# ---- helpers ---------------------------------------------------------------
command -v docker >/dev/null 2>&1 || die "docker is not installed."
docker compose version >/dev/null 2>&1 || die "docker compose (v2) is required."
command -v openssl >/dev/null 2>&1 || die "openssl is required."

# base64url without padding (for JWT)
b64url() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }

# Sign an HS256 JWT { role, iss:"supabase", iat, exp(+10y) } with the given secret.
jwt_sign() {
  local role="$1" secret="$2" now exp header payload signing sig
  now="$(date +%s)"; exp="$((now + 315360000))"   # 10 years
  header='{"alg":"HS256","typ":"JWT"}'
  payload="{\"role\":\"${role}\",\"iss\":\"supabase\",\"iat\":${now},\"exp\":${exp}}"
  signing="$(printf '%s' "$header" | b64url).$(printf '%s' "$payload" | b64url)"
  sig="$(printf '%s' "$signing" | openssl dgst -sha256 -hmac "$secret" -binary | b64url)"
  printf '%s.%s' "$signing" "$sig"
}

# Upsert KEY=VALUE in a file (replace existing line or append). Safe for JWT/base64 values.
upsert_env() {
  local file="$1" key="$2" val="$3"
  [ -f "$file" ] || touch "$file"
  if grep -qE "^${key}=" "$file"; then
    awk -v k="$key" -v v="$val" 'BEGIN{FS="="} $1==k{print k"="v; next} {print}' "$file" > "$file.tmp" && mv "$file.tmp" "$file"
  else
    printf '%s=%s\n' "$key" "$val" >> "$file"
  fi
}

# ===========================================================================
# 0. shared network (needed in every path so the backend can attach to it)
# ===========================================================================
if ! docker network inspect "$NETWORK" >/dev/null 2>&1; then
  log "Creating shared Docker network '$NETWORK'."
  docker network create "$NETWORK" >/dev/null
fi

# ===========================================================================
# 1. already running?  ->  done
# ===========================================================================
if docker ps --format '{{.Names}}' | grep -qx 'supabase-kong'; then
  log "Supabase is already running. Nothing to do."
  log "Credentials: $CREDS_FILE"
  exit 0
fi

# ===========================================================================
# 2. installed but stopped?  ->  just start it (DO NOT regenerate secrets)
# ===========================================================================
if [ -f "$SUPA_DOCKER/.env" ]; then
  log "Supabase already installed but not running — starting it (secrets preserved)."
  ( cd "$SUPA_DOCKER" && docker compose up -d )
  log "Up. Credentials: $CREDS_FILE"
  exit 0
fi

# ===========================================================================
# 3. fresh install
# ===========================================================================
log "Fresh install -> $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

if [ ! -d "$SUPA_REPO/.git" ]; then
  log "Cloning official Supabase docker stack..."
  git clone --depth 1 https://github.com/supabase/supabase "$SUPA_REPO"
fi

cd "$SUPA_DOCKER"
[ -f .env ] || cp .env.example .env

# ---- generate secrets ------------------------------------------------------
log "Generating fresh secrets..."
POSTGRES_PASSWORD="$(openssl rand -hex 24)"
JWT_SECRET="$(openssl rand -hex 32)"                 # 64 chars (>= 32 required)
ANON_KEY="$(jwt_sign anon "$JWT_SECRET")"
SERVICE_ROLE_KEY="$(jwt_sign service_role "$JWT_SECRET")"
DASHBOARD_USERNAME="admin"
DASHBOARD_PASSWORD="$(openssl rand -hex 16)"
SECRET_KEY_BASE="$(openssl rand -hex 32)"            # 64 chars
VAULT_ENC_KEY="$(openssl rand -hex 16)"              # exactly 32 chars
LOGFLARE_PUBLIC_TOKEN="$(openssl rand -hex 24)"
LOGFLARE_PRIVATE_TOKEN="$(openssl rand -hex 24)"
POOLER_TENANT_ID="$(openssl rand -hex 8)"

# ---- write them into Supabase's .env --------------------------------------
log "Writing Supabase .env..."
upsert_env .env POSTGRES_PASSWORD              "$POSTGRES_PASSWORD"
upsert_env .env JWT_SECRET                     "$JWT_SECRET"
upsert_env .env ANON_KEY                       "$ANON_KEY"
upsert_env .env SERVICE_ROLE_KEY               "$SERVICE_ROLE_KEY"
upsert_env .env DASHBOARD_USERNAME             "$DASHBOARD_USERNAME"
upsert_env .env DASHBOARD_PASSWORD             "$DASHBOARD_PASSWORD"
upsert_env .env SECRET_KEY_BASE                "$SECRET_KEY_BASE"
upsert_env .env VAULT_ENC_KEY                  "$VAULT_ENC_KEY"
upsert_env .env LOGFLARE_PUBLIC_ACCESS_TOKEN   "$LOGFLARE_PUBLIC_TOKEN"
upsert_env .env LOGFLARE_PRIVATE_ACCESS_TOKEN  "$LOGFLARE_PRIVATE_TOKEN"
upsert_env .env POOLER_TENANT_ID               "$POOLER_TENANT_ID"
upsert_env .env SITE_URL                       "$SITE_URL"
upsert_env .env API_EXTERNAL_URL               "$PUBLIC_URL"
upsert_env .env SUPABASE_PUBLIC_URL            "$PUBLIC_URL"

# ---- attach kong + db to the shared network (override file) ----------------
log "Wiring stack onto '$NETWORK' for direct backend access..."
cat > docker-compose.override.yml <<YAML
# Generated by lua-assistant/ops/setup-supabase.sh — do not edit by hand.
# Puts the API gateway (kong) and database (db) on the shared external network
# so the Lua backend (app/worker) reaches them directly, with no internet hop.
services:
  kong:
    networks: [default, ${NETWORK}]
  db:
    networks: [default, ${NETWORK}]
networks:
  ${NETWORK}:
    external: true
YAML

# Supabase's shipped .env pins COMPOSE_FILE=docker-compose.yml, which DISABLES
# auto-loading of docker-compose.override.yml. Append our override to that list
# so every `docker compose` in this dir (incl. supabase-ctl.sh) loads it and the
# kong/db network attachment survives down/up.
if grep -qE '^COMPOSE_FILE=' .env; then
  cf_current="$(grep -E '^COMPOSE_FILE=' .env | head -n1 | cut -d= -f2-)"
  case ":${cf_current}:" in
    *:docker-compose.override.yml:*) : ;;  # already present
    *) upsert_env .env COMPOSE_FILE "${cf_current}:docker-compose.override.yml" ;;
  esac
else
  upsert_env .env COMPOSE_FILE "docker-compose.yml:docker-compose.override.yml"
fi

# ---- save full credentials (private) --------------------------------------
umask 077
cat > "$CREDS_FILE" <<EOF
# Lua self-hosted Supabase — generated $(date -u +%Y-%m-%dT%H:%M:%SZ)
# KEEP THIS PRIVATE.

## Studio (admin UI)
URL:        $PUBLIC_URL
username:   $DASHBOARD_USERNAME
password:   $DASHBOARD_PASSWORD

## Backend (already written into lua-assistant/.env)
SUPABASE_URL=$INTERNAL_SUPABASE_URL          # internal, low-latency
SUPABASE_SERVICE_ROLE_KEY=$SERVICE_ROLE_KEY

## Frontend on Vercel (set these in Vercel env, then redeploy)
VITE_SUPABASE_URL=$PUBLIC_URL
VITE_SUPABASE_PUBLISHABLE_KEY=$ANON_KEY

## Core secrets (recovery only)
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
JWT_SECRET=$JWT_SECRET
ANON_KEY=$ANON_KEY
SERVICE_ROLE_KEY=$SERVICE_ROLE_KEY
SECRET_KEY_BASE=$SECRET_KEY_BASE
VAULT_ENC_KEY=$VAULT_ENC_KEY
EOF
log "Saved all secrets -> $CREDS_FILE"

# ---- write the two the backend needs into lua-assistant/.env --------------
if [ ! -f "$BACKEND_ENV" ] && [ -f "$LUA_ASSISTANT/.env.example" ]; then
  log "Backend .env missing — seeding from .env.example (fill the rest yourself)."
  cp "$LUA_ASSISTANT/.env.example" "$BACKEND_ENV"
fi
upsert_env "$BACKEND_ENV" SUPABASE_URL              "$INTERNAL_SUPABASE_URL"
upsert_env "$BACKEND_ENV" SUPABASE_SERVICE_ROLE_KEY "$SERVICE_ROLE_KEY"
upsert_env "$BACKEND_ENV" SUPABASE_DOMAIN           "$SUPABASE_DOMAIN"
log "Updated backend env -> $BACKEND_ENV (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SUPABASE_DOMAIN)"

# ---- start the stack -------------------------------------------------------
log "Pulling images & starting Supabase (first run can take a few minutes)..."
docker compose pull
docker compose up -d

# ---- wait for the database, then apply migrations once ---------------------
log "Waiting for database to become ready..."
ready=0
for _ in $(seq 1 60); do
  if docker exec supabase-db pg_isready -U postgres >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || die "Database did not become ready in time. Check: docker logs supabase-db"

if [ -f "$MIGR_MARKER" ]; then
  log "Migrations already applied previously — skipping."
else
  log "Applying migrations..."
  shopt -s nullglob
  for f in "$MIGRATIONS_DIR"/0*.sql; do
    log "  -> $(basename "$f")"
    docker exec -i -e PGPASSWORD="$POSTGRES_PASSWORD" supabase-db \
      psql -v ON_ERROR_STOP=1 -U postgres -d postgres < "$f"
  done
  shopt -u nullglob
  touch "$MIGR_MARKER"
  log "Migrations applied."
fi

log "DONE ✅"
log "Studio:      $PUBLIC_URL  (user: $DASHBOARD_USERNAME)"
log "Credentials: $CREDS_FILE"
log "Next: (re)start your backend so app/worker join '$NETWORK', and point Vercel at the anon key above."
