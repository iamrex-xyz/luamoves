import type { TaskRow, UserRow } from '../types/db.js';

/**
 * The structured task-list "view model" — the JSON contract consumed by the
 * Lovable frontend (GET /api/tasklist/:token). Grouped by the master-list phase,
 * with progress, so the frontend renders without re-deriving anything.
 */
export interface TasklistTaskView {
  id: string;
  task_key: string;
  title: string;
  category: string | null;
  due_date: string | null;
  status: TaskRow['status'];
  explanation: string | null;
  tip: string | null;
}

export interface TasklistPhaseView {
  phase_order: number | null;
  name: string;
  tasks: TasklistTaskView[];
}

export interface TasklistView {
  user: { name: string | null; move_date: string | null; move_type: UserRow['move_type'] };
  progress: { done: number; total: number; pct: number };
  phases: TasklistPhaseView[];
}

function toTaskView(t: TaskRow): TasklistTaskView {
  return {
    id: t.id,
    task_key: t.task_key,
    title: t.title,
    category: t.category,
    due_date: t.due_date,
    status: t.status,
    explanation: t.explanation,
    tip: t.tip,
  };
}

/** Group tasks into phases, preserving the incoming (sort_order) sequence. */
export function buildTasklistView(user: UserRow, tasks: TaskRow[]): TasklistView {
  const total = tasks.length;
  const done = tasks.filter((t) => t.status === 'completed').length;
  const pct = total ? Math.round((done / total) * 100) : 0;

  const phases: TasklistPhaseView[] = [];
  for (const t of tasks) {
    const name = t.phase_name ?? 'Overig';
    let phase = phases[phases.length - 1];
    if (!phase || phase.name !== name) {
      phase = { phase_order: t.phase_order, name, tasks: [] };
      phases.push(phase);
    }
    phase.tasks.push(toTaskView(t));
  }

  return {
    user: { name: user.name, move_date: user.move_date, move_type: user.move_type },
    progress: { done, total, pct },
    phases,
  };
}
