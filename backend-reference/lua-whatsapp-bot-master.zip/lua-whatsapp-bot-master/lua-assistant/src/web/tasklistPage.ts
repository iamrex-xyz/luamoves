import type { TaskRow, UserRow } from '../types/db.js';

/**
 * Server-rendered, mobile-friendly task-list page (plan.md §13). No framework,
 * no auth — reached only via the unguessable tasklist token. Tasks are grouped
 * by the master-list phase; each checkbox PATCHes back through the token-scoped
 * API and the same updateTaskStatus() the WhatsApp path uses.
 */
function esc(s: unknown): string {
  return String(s ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

interface Phase {
  name: string;
  tasks: TaskRow[];
}

/** Group tasks into phases, preserving the incoming (sort_order) sequence. */
function groupByPhase(tasks: TaskRow[]): Phase[] {
  const phases: Phase[] = [];
  for (const t of tasks) {
    const name = t.phase_name ?? 'Overig';
    let phase = phases[phases.length - 1];
    if (!phase || phase.name !== name) {
      phase = { name, tasks: [] };
      phases.push(phase);
    }
    phase.tasks.push(t);
  }
  return phases;
}

function renderTask(t: TaskRow): string {
  const done = t.status === 'completed';
  const due = t.due_date ? `<span class="due">📅 ${esc(t.due_date)}</span>` : '';
  const cat = t.category ? `<span class="cat">${esc(t.category)}</span>` : '';
  const tip = t.tip ? `<p class="tip">💡 ${esc(t.tip)}</p>` : '';
  const expl = t.explanation ? `<p class="expl">${esc(t.explanation)}</p>` : '';
  return `
    <li class="task ${done ? 'done' : ''}" data-id="${esc(t.id)}">
      <label class="row">
        <input type="checkbox" ${done ? 'checked' : ''} onchange="toggle(this)" />
        <span class="title">${esc(t.title)}</span>
      </label>
      <div class="meta">${cat}${due}</div>
      ${expl}${tip}
    </li>`;
}

export function renderTasklistPage(user: UserRow, tasks: TaskRow[]): string {
  const total = tasks.length;
  const done = tasks.filter((t) => t.status === 'completed').length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  const phases = groupByPhase(tasks);

  const body = phases
    .map(
      (p) => `
      <section class="phase">
        <h2>${esc(p.name)}</h2>
        <ul>${p.tasks.map(renderTask).join('')}</ul>
      </section>`,
    )
    .join('');

  const empty = total === 0 ? '<p class="empty">Je checklist is nog leeg.</p>' : '';

  return `<!doctype html>
<html lang="nl">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title>Jouw verhuischecklist — Lua</title>
<style>
  :root { --bg:#f6f7fb; --card:#fff; --ink:#243044; --muted:#6b7a90; --line:#e6e9f2; --accent:#3b7a57; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--ink);
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; line-height:1.45; }
  header { padding:20px 16px 12px; }
  h1 { font-size:1.3rem; margin:0 0 4px; }
  .sub { color:var(--muted); font-size:.9rem; }
  .progress { margin:12px 0 4px; background:var(--line); border-radius:999px; height:10px; overflow:hidden; }
  .bar { height:100%; background:var(--accent); width:${pct}%; transition:width .3s; }
  .pct { font-size:.85rem; color:var(--muted); }
  main { padding:8px 12px 48px; max-width:680px; margin:0 auto; }
  .phase { margin:18px 0 6px; }
  .phase h2 { font-size:.8rem; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); margin:0 0 8px 4px; }
  ul { list-style:none; margin:0; padding:0; }
  .task { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:12px 14px; margin-bottom:8px; }
  .row { display:flex; align-items:flex-start; gap:10px; cursor:pointer; }
  .row input { width:20px; height:20px; margin-top:2px; flex:0 0 auto; accent-color:var(--accent); }
  .title { font-weight:600; }
  .task.done .title { text-decoration:line-through; color:var(--muted); }
  .meta { display:flex; gap:8px; flex-wrap:wrap; margin:6px 0 0 30px; }
  .cat, .due { font-size:.72rem; color:var(--muted); background:var(--bg); border:1px solid var(--line); border-radius:6px; padding:2px 6px; }
  .expl { margin:8px 0 0 30px; font-size:.88rem; color:var(--ink); }
  .tip { margin:6px 0 0 30px; font-size:.82rem; color:var(--muted); }
  .empty { color:var(--muted); text-align:center; padding:40px 0; }
</style>
</head>
<body>
  <header>
    <h1>🏠 Jouw verhuischecklist</h1>
    <div class="sub">${esc(user.name ?? '')}${user.move_date ? ` · verhuisdatum ${esc(user.move_date)}` : ''}</div>
    <div class="progress"><div class="bar" id="bar"></div></div>
    <div class="pct"><span id="doneCount">${done}</span> van ${total} afgerond</div>
  </header>
  <main>
    ${empty}${body}
  </main>
<script>
  var TOKEN = ${JSON.stringify(user.tasklist_token)};
  var TOTAL = ${total};
  function refreshProgress() {
    var done = document.querySelectorAll('.task.done').length;
    document.getElementById('doneCount').textContent = done;
    document.getElementById('bar').style.width = (TOTAL ? Math.round(done/TOTAL*100) : 0) + '%';
  }
  function toggle(box) {
    var li = box.closest('.task');
    var status = box.checked ? 'completed' : 'pending';
    li.classList.toggle('done', box.checked);
    refreshProgress();
    fetch('/api/tasks/' + encodeURIComponent(li.dataset.id), {
      method:'PATCH', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ token: TOKEN, status: status })
    }).then(function(r){ if(!r.ok) throw new Error('save failed'); })
      .catch(function(){
        box.checked = !box.checked;                 // revert on failure
        li.classList.toggle('done', box.checked);
        refreshProgress();
        alert('Kon niet opslaan. Probeer het opnieuw.');
      });
  }
  refreshProgress();
</script>
</body>
</html>`;
}
