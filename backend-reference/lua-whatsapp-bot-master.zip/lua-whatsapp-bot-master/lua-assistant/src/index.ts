import { config } from './config/index.js';
import { prompts, promptVersionShort, PROMPT_FILES } from './config/prompts.js';
import { createApp } from './app.js';
import { logger } from './utils/logger.js';
import { installHttpAgent } from './utils/httpAgent.js';

/**
 * Boot sequence:
 *   1. config/index.ts already validated env at import time (fail-fast).
 *   2. config/prompts.ts already loaded the behaviour spec + computed its hash.
 *   3. Start the HTTP server.
 */
function main(): void {
  // Warm, reusable connections for every external hop (OpenRouter/Bird/Supabase).
  installHttpAgent();

  logger.info(
    {
      nodeEnv: config.NODE_ENV,
      mainModel: config.MAIN_MODEL,
      summaryModel: config.SUMMARY_MODEL,
      configVersion: promptVersionShort,
      promptFiles: PROMPT_FILES,
      promptBytes: Object.values(prompts.files).reduce((n, c) => n + c.length, 0),
      tz: config.TZ,
    },
    'Lua assistant starting',
  );

  const app = createApp();
  const server = app.listen(config.PORT, () => {
    logger.info({ port: config.PORT }, `HTTP server listening on :${config.PORT}`);
  });

  // Graceful shutdown so docker stop / SIGTERM drains in-flight requests.
  const shutdown = (signal: string): void => {
    logger.info({ signal }, 'shutting down');
    server.close(() => process.exit(0));
    // Hard exit if it doesn't close in time.
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main();
