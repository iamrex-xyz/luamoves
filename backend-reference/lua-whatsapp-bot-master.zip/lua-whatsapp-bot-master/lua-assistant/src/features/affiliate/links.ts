import type { OfferKey } from '../../types/db.js';

/**
 * Offer → partner metadata, the single source of truth for affiliate links
 * (monetization.md). Partner names and base URLs are defined HERE in code at the
 * client's instruction — this intentionally overrides CLAUDE.md's "partner URLs
 * from config" rule. The model never produces a URL itself; the [AANBOD] directive
 * shares exactly the buildLink() output (see eligibility.ts + LINK_DISCIPLINE).
 */
interface OfferMeta {
  /** Bare domain — used ONLY inside the tracked URL, never in conversation text. */
  partner: string;
  /**
   * Human brand name shown in conversation (e.g. "Verhuisoffertes"). Has no TLD,
   * so WhatsApp can't auto-linkify it — the ONLY clickable link is the backend's
   * tracked URL. Mentioning the bare domain in text created a second, UNtracked
   * link (lost attribution); the display name fixes that.
   */
  displayName: string;
  baseUrl: string;
  /**
   * true  = active affiliate → the first-offer transparency disclosure applies.
   * false = "Commission to confirm" (monetization.md): present as a convenience
   *         only, no disclosure, no active pitch.
   */
  commercial: boolean;
}

// Placeholder referral/UTM query string appended to every link — the real
// per-partner params are a client dependency, swap them in when confirmed.
const AFFILIATE_UTM = 'utm_source=lua&utm_medium=whatsapp&utm_campaign=moving';

// Single source of truth for affiliate partners (monetization.md §Partners).
const OFFERS: Record<OfferKey, OfferMeta> = {
  energy: { partner: 'overstappen.nl', displayName: 'Overstappen', baseUrl: 'https://www.overstappen.nl', commercial: true },
  internet: { partner: 'overstappen.nl', displayName: 'Overstappen', baseUrl: 'https://www.overstappen.nl', commercial: true },
  insurance: { partner: 'overstappen.nl', displayName: 'Overstappen', baseUrl: 'https://www.overstappen.nl', commercial: true },
  moving_company: { partner: 'verhuisoffertes.com', displayName: 'Verhuisoffertes', baseUrl: 'https://www.verhuisoffertes.com', commercial: true },
  cleaning: { partner: 'werkspot.nl', displayName: 'Werkspot', baseUrl: 'https://www.werkspot.nl', commercial: true },
  renovation: { partner: 'slimster.nl', displayName: 'Slimster', baseUrl: 'https://www.slimster.nl', commercial: true },
  lock: { partner: 'werkspot.nl', displayName: 'Werkspot', baseUrl: 'https://www.werkspot.nl', commercial: true },
  mortgage: { partner: 'ikbenfrits.nl', displayName: 'IkBenFrits', baseUrl: 'https://www.ikbenfrits.nl', commercial: true },
  // Commission to confirm → convenience links, no disclosure.
  moving_boxes: { partner: 'gamma.nl', displayName: 'Gamma', baseUrl: 'https://www.gamma.nl', commercial: false },
  contract_cancellation: { partner: '123opzeggen.nl', displayName: '123 Opzeggen', baseUrl: 'https://www.123opzeggen.nl', commercial: false },
};

/** Bare domain — internal use only (inside the tracked URL), never shown in chat. */
export function partnerName(offer: OfferKey): string {
  return OFFERS[offer].partner;
}

/** Brand name for conversation text — no TLD, so WhatsApp won't auto-linkify it. */
export function partnerDisplayName(offer: OfferKey): string {
  return OFFERS[offer].displayName;
}

/**
 * Unique {domain, brand} pairs for every commercial partner — used by the backend
 * to rewrite any partner DOMAIN the model wrote in its reply back to the brand
 * name, so a bare (untracked, auto-linkified) partner domain never reaches chat.
 * Only partners listed here are rewritten; non-commercial referrals Lua may share
 * (postnl.nl, mijnoverheid.nl) are not in OFFERS and stay clickable.
 */
export function partnerDomainBrands(): Array<{ domain: string; brand: string }> {
  const seen = new Set<string>();
  const out: Array<{ domain: string; brand: string }> = [];
  for (const { partner, displayName } of Object.values(OFFERS)) {
    if (seen.has(partner)) continue;
    seen.add(partner);
    out.push({ domain: partner, brand: displayName });
  }
  return out;
}

/** Whether this offer is an active affiliate (disclosure applies) vs a convenience link. */
export function isCommercial(offer: OfferKey): boolean {
  return OFFERS[offer].commercial;
}

/** Build the partner link with the (placeholder) UTM/referral params. */
export function buildLink(offer: OfferKey): string {
  const base = OFFERS[offer].baseUrl;
  if (!AFFILIATE_UTM) return base;
  return base + (base.includes('?') ? '&' : '?') + AFFILIATE_UTM;
}

/**
 * Deterministic safety net: rewrite any COMMERCIAL partner domain the model wrote
 * in its reply back to the brand name (e.g. "https://www.verhuisoffertes.com/x"
 * or bare "verhuisoffertes.com" → "Verhuisoffertes"). WhatsApp auto-linkifies bare
 * domains, so an in-text partner domain becomes a second, UNtracked link — this
 * removes it, leaving the backend's tracked URL as the only clickable link.
 *
 * Apply to MODEL output only, and BEFORE the tracked link is appended (so the
 * tracked URL itself is never rewritten). Non-commercial referrals (postnl.nl,
 * mijnoverheid.nl) aren't partners here, so they stay clickable.
 */
export function delinkifyPartners(text: string): string {
  let out = text;
  for (const { domain, brand } of partnerDomainBrands()) {
    const esc = domain.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // optional scheme + optional www + domain + optional /path?query → brand
    const re = new RegExp(`(?:https?:\\/\\/)?(?:www\\.)?${esc}(?:\\/[^\\s]*)?`, 'gi');
    out = out.replace(re, brand);
  }
  return out;
}
