import type { AffiliateFlagRow, OfferKey, TaskRow, UserRow } from '../../types/db.js';
import * as affiliateRepo from '../../repositories/affiliate.repository.js';
import * as messages from '../../repositories/message.repository.js';
import { decideOffer, ONE_IN_FIVE_WINDOW } from './guards.js';
import { partnerDisplayName, isCommercial } from './links.js';
import { logger } from '../../utils/logger.js';

const log = logger.child({ feature: 'affiliate/eligibility' });

/**
 * Partner-topic keywords → offer key (en + nl). Priority order matters when a
 * message mentions more than one topic: the first match with an on-radar task wins.
 */
const TOPIC_KEYWORDS: Array<{ offer: OfferKey; terms: string[] }> = [
  // Cancellation first: "energiecontract opzeggen" also matches 'energie' below, but
  // the intent is cancellation — let it win when an "opzeggen/cancel" word is present.
  { offer: 'contract_cancellation', terms: ['opzeggen', 'opzegg', 'stopzetten', 'beëindigen', 'beeindigen', 'cancel my contract', 'cancel contract', 'cancel my subscription', 'end my contract'] },
  { offer: 'mortgage', terms: ['mortgage', 'hypotheek', 'hypotheekadviseur', 'hypotheekaanvraag'] },
  { offer: 'energy', terms: ['energy', 'energie', 'stroom', 'gas', 'electricity', 'elektriciteit', 'energiecontract'] },
  { offer: 'internet', terms: ['internet', 'wifi', 'wi-fi', 'breedband', 'broadband', 'glasvezel'] },
  { offer: 'insurance', terms: ['insurance', 'verzekering', 'inboedel', 'opstal', 'aansprakelijkheid'] },
  { offer: 'moving_company', terms: ['moving company', 'movers', 'verhuisbedrijf', 'verhuizer', 'verhuisservice', 'verhuiswagen', 'removal'] },
  { offer: 'moving_boxes', terms: ['moving box', 'moving boxes', 'packing material', 'verhuisdoos', 'verhuisdozen', 'verpakkingsmateriaal', 'inpakmateriaal'] },
  { offer: 'cleaning', terms: ['cleaning', 'cleaner', 'schoonmaak', 'schoonmaken', 'opleverschoon', 'poetsen'] },
  { offer: 'renovation', terms: ['renovation', 'renovate', 'verbouwing', 'verbouwen', 'klussen', 'klusser', 'verven', 'schilderen', 'klusmateriaal'] },
  { offer: 'lock', terms: ['lock cylinder', 'cylinder', 'slotcilinder', 'cilinder', 'slotenmaker', 'sloten vervangen', 'cilinders vervangen'] },
];

/** Topics the user mentioned this turn, in priority order (pure). */
export function detectTopics(text: string): OfferKey[] {
  const t = text.toLowerCase();
  return TOPIC_KEYWORDS.filter(({ terms }) => terms.some((k) => t.includes(k))).map((x) => x.offer);
}

/**
 * The first mentioned topic that is ALSO on the user's radar — i.e. has a pending
 * checklist task carrying that affiliate_trigger (pure). This is the "trigger must
 * be on the user's radar" rule (plan.md §11); we only offer when the user raised it.
 */
export function onRadarCandidate(topics: OfferKey[], tasks: TaskRow[]): OfferKey | null {
  const pendingTriggers = new Set(
    tasks.filter((t) => t.status === 'pending' && t.affiliate_trigger).map((t) => t.affiliate_trigger!),
  );
  return topics.find((o) => pendingTriggers.has(o)) ?? null;
}

export interface EligibilityResult {
  offer: OfferKey | null;
  reason: string;
}

/**
 * Decide whether an affiliate offer may be made this turn. The user must have
 * RAISED the topic and have a matching pending task; then the declined and 1-in-5
 * guards apply. The backend then injects the directive — the model never offers
 * unsolicited.
 */
export async function resolveOffer(
  user: UserRow,
  text: string,
  tasks: TaskRow[],
): Promise<EligibilityResult> {
  const candidate = onRadarCandidate(detectTopics(text), tasks);
  if (!candidate) return { offer: null, reason: 'no-trigger' };

  const [flag, recentCommercialCount] = await Promise.all([
    affiliateRepo.get(user.id, candidate),
    messages.countRecentCommercial(user.id, ONE_IN_FIVE_WINDOW),
  ]);

  const decision = decideOffer({ candidate, flag, recentCommercialCount });
  if (decision.offer) {
    log.info({ userId: user.id, offer: decision.offer }, 'affiliate offer eligible');
  } else if (candidate) {
    log.info({ userId: user.id, candidate, reason: decision.reason }, 'affiliate offer suppressed');
  }
  return decision;
}

/**
 * The offer still awaiting the user's accept/decline: the most recently SHOWN
 * offer that hasn't been declined and whose link hasn't been delivered yet. This
 * is how the keyword-less "ja" turn is resolved — resolveOffer can't find it (no
 * trigger word), so the backend looks up the pending offer here and, on accept,
 * delivers the link. Returns null when nothing is awaiting a response.
 */
/**
 * PURE: pick the offer awaiting accept/decline from a user's flags — the most
 * recently SHOWN offer that isn't declined and whose link wasn't delivered yet.
 * `link_sent` gates re-delivery (a delivered offer is no longer pending).
 */
export function pickPendingOffer(flags: AffiliateFlagRow[]): OfferKey | null {
  const pending = flags
    .filter((f) => f.shown && !f.declined && !f.link_sent)
    .sort((a, b) => b.updated_at.localeCompare(a.updated_at))[0];
  return (pending?.offer_key as OfferKey | undefined) ?? null;
}

export async function findPendingOffer(userId: string): Promise<OfferKey | null> {
  return pickPendingOffer(await affiliateRepo.listByUser(userId));
}

/**
 * The directive injected when an offer is eligible (the TRIGGER turn). The model
 * only ASKS permission ("Zal ik je doorsturen?") and names the partner — it does
 * NOT write a link. When the user accepts on the next turn, the BACKEND delivers
 * the exact link (see findPendingOffer + applyAccepted). The model writes the
 * offer + disclosure text in the user's language; the backend owns WHEN to
 * disclose (`includeDisclosure`, true only on the user's first-ever offer) and
 * the actual URL. Wording follows monetization.md (named partner; disclosure ends
 * "jij betaalt niets extra").
 */
export function buildAffiliateDirective(offer: OfferKey, includeDisclosure: boolean): string {
  const partner = partnerDisplayName(offer);
  const commercial = isCommercial(offer);
  const lines = [
    '[AANBOD — toegestaan]',
    `De gebruiker heeft dit onderwerp zelf aangekaart en het staat op de checklist. Je MAG nu één aanbod doen voor: ${offer}.`,
    `Partner (merknaam): ${partner}. Noem de partner ALLEEN met deze merknaam.`,
    `BELANGRIJK: schrijf ZELF NOOIT een URL, link, webadres of domein (dus niet "${partner.toLowerCase()}.nl/.com"). Gebruik uitsluitend de merknaam "${partner}". Je VRAAGT alleen om toestemming; zodra de gebruiker ja zegt, voegt het systeem automatisch de juiste link toe.`,
    commercial
      ? `Aanbod (zelfde strekking, in de taal van de gebruiker): "Ik werk samen met ${partner} — zij vergelijken meerdere aanbieders. Zal ik je doorsturen?"`
      : // "Commission to confirm" partner: present as a neutral convenience, do NOT
        // pitch it as a partnership and do NOT add the fee/disclosure sentence.
        `Aanbod (feitelijk, als gemak — GEEN partnerpitch, GEEN vergoeding/disclosure noemen, in de taal van de gebruiker): "Je kunt dit via ${partner} regelen. Zal ik je doorsturen?"`,
  ];
  if (includeDisclosure && commercial) {
    lines.push(
      'Voeg HIERNA, in hetzelfde bericht, de verplichte transparantie-disclosure toe (alleen bij dit allereerste aanbod), zelfde strekking, in de taal van de gebruiker:',
      `"Even transparant: ik werk samen met ${partner} en krijg een vergoeding als je via mij overstapt — jij betaalt niets extra."`,
    );
  }
  lines.push(
    'Schrijf het VOLLEDIGE bericht in ÉÉN taal (die van de gebruiker) — nooit talen mengen.',
    'Doe maximaal één aanbod. Zet signals.affiliate.offered op deze offer-key als je het aanbod daadwerkelijk doet.',
    'Als de gebruiker het aanbod afwijst, accepteer dat direct en zet signals.affiliate.user_declined=true.',
    '[/AANBOD]',
  );
  return lines.join('\n');
}

/**
 * The directive injected on the turn AFTER an offer, while it's still awaiting
 * the user's answer (the keyword-less "ja"/"nee" turn). The model classifies the
 * reply into accept / decline / unrelated; on accept it confirms briefly and the
 * BACKEND appends the real link — the model must never write a URL itself.
 */
export function buildPendingDirective(offer: OfferKey): string {
  const partner = partnerDisplayName(offer);
  return [
    '[AANBOD — in afwachting]',
    `Je hebt zojuist aangeboden om de gebruiker door te sturen naar ${partner} (${offer}) en wacht op hun antwoord.`,
    'Zegt de gebruiker JA / akkoord (bijv. "ja", "graag", "stuur maar", "yes"): bevestig kort en vriendelijk dat je de link stuurt en zet signals.affiliate.user_accepted=true. Schrijf ZELF GEEN URL, webadres of domein en herhaal de merknaam niet als website — het systeem voegt de juiste link toe aan jouw bericht.',
    'Zegt de gebruiker NEE: accepteer dat direct, dring niet aan, en zet signals.affiliate.user_declined=true.',
    'Gaat het bericht over iets anders: beantwoord dat normaal en laat user_accepted en user_declined allebei false.',
    'Schrijf in ÉÉN taal (die van de gebruiker) — nooit talen mengen.',
    '[/AANBOD]',
  ].join('\n');
}
