import type { AffiliateFlagRow, OfferKey } from '../../types/db.js';

/**
 * Affiliate guards as PURE predicates (monetization.md §Frequency / §If the user
 * says no). The orchestrator supplies the facts (DB reads) and acts on the verdict;
 * keeping the rules pure makes the hard guarantees unit-testable.
 */

/** Recent window the 1-in-5 rule looks back over. */
export const ONE_IN_FIVE_WINDOW = 5;
/**
 * "More than 1 of the recent 5 Lua messages was commercial" → suppress. So with
 * 2+ commercial messages already in the last 5, the next offer is suppressed.
 */
export const ONE_IN_FIVE_MAX = 1;

/** True if a new offer is allowed under the 1-in-5 frequency rule. */
export function passesOneInFive(recentCommercialCount: number): boolean {
  return recentCommercialCount <= ONE_IN_FIVE_MAX;
}

/** A declined offer must not be re-offered in the same session (sticky flag). */
export function isDeclined(flag: AffiliateFlagRow | null): boolean {
  return flag?.declined === true;
}

/**
 * Final eligibility given an on-radar candidate and the gathered facts. Returns
 * the offer to inject, or null with a reason for logging why it was suppressed.
 */
export function decideOffer(args: {
  candidate: OfferKey | null;
  flag: AffiliateFlagRow | null;
  recentCommercialCount: number;
}): { offer: OfferKey | null; reason: string } {
  const { candidate, flag, recentCommercialCount } = args;
  if (!candidate) return { offer: null, reason: 'no-trigger' };
  if (isDeclined(flag)) return { offer: null, reason: 'declined-this-session' };
  if (!passesOneInFive(recentCommercialCount)) return { offer: null, reason: 'one-in-five' };
  return { offer: candidate, reason: 'eligible' };
}
