import type { OfferKey, UserRow } from '../../types/db.js';
import * as affiliateRepo from '../../repositories/affiliate.repository.js';
import { buildLink, isCommercial } from './links.js';
import { logger } from '../../utils/logger.js';

const log = logger.child({ feature: 'affiliate/apply' });

export interface OfferedOutcome {
  /** The outgoing text as written by the model (offer + disclosure, one language). */
  outgoing: string;
  /** Whether this message counts as commercial (drives the 1-in-5 guard). */
  commercial: boolean;
}

/**
 * Apply the model's offer outcome. "Backend disposes": we only honour an offer
 * that matches the one we deemed eligible this turn, recording `shown` and (on the
 * first-ever offer) `disclosure_sent`. The disclosure TEXT is now written by the
 * MODEL — the affiliate directive instructs it to add the disclosure only when this
 * is the first offer — so it's in the user's language and never mixed. The backend
 * owns WHEN to disclose (via includeDisclosure in the directive); the model owns
 * the wording. No text is built here anymore.
 */
export async function applyOffered(
  user: UserRow,
  eligibleOffer: OfferKey | null,
  signalOffered: OfferKey | null,
  outgoing: string,
): Promise<OfferedOutcome> {
  const offered = signalOffered && signalOffered === eligibleOffer ? eligibleOffer : null;
  if (!offered) return { outgoing, commercial: false };

  // Only commercial (active-affiliate) offers carry the disclosure, so only they
  // consume the one-time `disclosure_sent` flag. "Commission to confirm" links are
  // a convenience — they never disclose and must not burn the flag.
  const everDisclosed = await affiliateRepo.disclosureEverSent(user.id);
  const setDisclosure = isCommercial(offered) && !everDisclosed;
  await affiliateRepo.upsert(user.id, offered, {
    shown: true,
    ...(setDisclosure ? { disclosure_sent: true } : {}),
  });

  log.info(
    { userId: user.id, offer: offered, firstDisclosure: setDisclosure },
    'affiliate offer shown',
  );
  return { outgoing, commercial: true };
}

export interface AcceptOutcome {
  /** Outgoing text with the partner link appended when delivered; else unchanged. */
  outgoing: string;
  /** Whether a link was actually delivered this turn (→ commercial, 1-in-5 input). */
  delivered: boolean;
}

/**
 * Deliver the partner link when the user accepts a PENDING offer (the "ja" turn).
 * "Backend disposes": we deliver only when the model reports acceptance AND a
 * genuinely pending offer exists. The exact link is appended HERE in code — the
 * model never writes a URL (monetization.md + LINK_DISCIPLINE) — and `link_sent`
 * is set so the same link is never delivered twice.
 */
export async function applyAccepted(
  user: UserRow,
  pendingOffer: OfferKey | null,
  signalAccepted: boolean,
  outgoing: string,
): Promise<AcceptOutcome> {
  if (!signalAccepted || !pendingOffer) return { outgoing, delivered: false };

  await affiliateRepo.upsert(user.id, pendingOffer, { link_sent: true });
  const url = buildLink(pendingOffer);
  log.info({ userId: user.id, offer: pendingOffer }, 'affiliate link delivered');
  return { outgoing: `${outgoing}\n\n${url}`, delivered: true };
}

/**
 * Record a decline so the same offer isn't repeated this session. Targets the most
 * recently-shown, not-yet-declined offer (the one the user is responding to).
 */
export async function applyDeclined(user: UserRow, signalDeclined: boolean): Promise<void> {
  if (!signalDeclined) return;
  const flags = await affiliateRepo.listByUser(user.id);
  const target = flags
    .filter((f) => f.shown && !f.declined)
    .sort((a, b) => b.updated_at.localeCompare(a.updated_at))[0];
  if (!target) return;
  await affiliateRepo.upsert(user.id, target.offer_key, { declined: true });
  log.info({ userId: user.id, offer: target.offer_key }, 'affiliate offer declined — recorded');
}
