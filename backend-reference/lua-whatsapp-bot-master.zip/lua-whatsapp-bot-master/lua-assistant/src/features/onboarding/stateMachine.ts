import type { OnboardingSignals } from '../../types/llm.js';
import type { UserRow } from '../../types/db.js';
import * as userRepo from '../../repositories/user.repository.js';
import {
  currentStep,
  nextStepAfter,
  STEP_LABEL_NL,
  STEP_ORDER,
  type OnboardingState,
  type OnboardingStep,
} from './steps.js';

const nonEmpty = (s: string | null | undefined): s is string => !!s && s.trim().length > 0;

/**
 * Reject values the model wrongly proposes as a name. The classic failure: on the
 * first turn the user just says "Hi", the model greets ("Nice to meet you!") and
 * stuffs that greeting into onboarding.name — which a plain non-empty check would
 * happily store, skipping the real name question. A name is short, has no
 * sentence punctuation/digits, and isn't a known greeting/filler.
 */
const NAME_STOPWORDS = new Set([
  'hi', 'hii', 'hello', 'hey', 'yo', 'hoi', 'hallo', 'hey there', 'hello there',
  'nice to meet you', 'good morning', 'goedemorgen', 'goedemiddag', 'thanks',
  'thank you', 'thx', 'ok', 'okay', 'oke', 'yes', 'no', 'ja', 'nee', 'help',
]);

function isPlausibleName(raw: string): boolean {
  const s = raw.trim();
  if (s.length < 2 || s.length > 40) return false;
  if (/\d/.test(s)) return false; // names have no digits
  if (/[!?.,:;@/\\()]|https?:/i.test(s)) return false; // sentence/URL punctuation
  if (s.split(/\s+/).length > 4) return false; // a name isn't a sentence
  if (NAME_STOPWORDS.has(s.toLowerCase())) return false;
  return true;
}

/** Parse an ISO yyyy-mm-dd date; return null if invalid. */
function parseISODate(s: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(`${s}T00:00:00Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

/**
 * Whether the model's proposed move date is usable. The past/future judgment is
 * DETERMINISTIC here, never left to the model — gpt-4.1-mini got it wrong in prod
 * ("August 23rd has already passed" while today was June 16, both 2026).
 *   none    — no date proposed this turn.
 *   unclear — vague ("this summer") or unparseable → ask the user to clarify.
 *   past    — a real date, but before today → reject and ask again.
 *   future  — a real date today or later → accept.
 */
export type MoveDateStatus = 'none' | 'unclear' | 'past' | 'future';

export function classifyMoveDate(o: OnboardingSignals, now: Date): MoveDateStatus {
  if (!nonEmpty(o.move_date)) return o.date_unclear ? 'unclear' : 'none';
  if (o.date_unclear) return 'unclear';
  const d = parseISODate(o.move_date);
  if (!d) return 'unclear';
  const startOfToday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  return d.getTime() >= startOfToday.getTime() ? 'future' : 'past';
}

/**
 * PURE: validate the model's extraction into a column patch. Shared by onboarding
 * (decide) and post-onboarding corrections (applyProfileCorrection). Only valid,
 * non-empty values are included; the move date must be clear and not in the past.
 */
export function extractProfilePatch(
  o: OnboardingSignals,
  now: Date,
): { patch: Partial<UserRow>; moveDateOk: boolean; moveDateStatus: MoveDateStatus } {
  const patch: Partial<UserRow> = {};
  if (nonEmpty(o.name) && isPlausibleName(o.name)) patch.name = o.name.trim();
  if (o.move_type === 'rent' || o.move_type === 'buy') patch.move_type = o.move_type;
  if (nonEmpty(o.from_address)) patch.from_address = o.from_address.trim();
  if (o.to_address != null) {
    if (o.to_address.trim().toLowerCase() === 'unknown') patch.to_address = null;
    else if (nonEmpty(o.to_address)) patch.to_address = o.to_address.trim();
  }
  if (nonEmpty(o.home_type)) patch.home_type = o.home_type.trim();
  if (nonEmpty(o.household)) patch.household = { description: o.household.trim() };

  // Only a clear, today-or-future date is persisted; past/unclear are surfaced
  // (moveDateStatus) so the caller can render the right deterministic reply.
  const moveDateStatus = classifyMoveDate(o, now);
  const moveDateOk = moveDateStatus === 'future';
  if (moveDateOk) patch.move_date = o.move_date!.trim();

  return { patch, moveDateOk, moveDateStatus };
}

export interface OnboardingDecision {
  /** Validated columns to write (incl. onboarding_step when advancing). */
  patch: Partial<UserRow>;
  nextStep: OnboardingState;
  advanced: boolean;
  justCompleted: boolean;
  paused: boolean;
  /** Deterministic verdict on the move date proposed this turn (for the reply). */
  moveDateStatus: MoveDateStatus;
}

/**
 * PURE decision logic (no DB): given the current step, the user, and the model's
 * extraction, decide what to persist and whether to advance. The backend is
 * authoritative — the model only proposes values.
 *
 * Accepts corrections: any valid field present is written, even if it isn't the
 * current step (e.g. "Actually, to Rotterdam"). Advancement, however, depends on
 * the CURRENT step's answer being provided this turn.
 */
export function decide(
  step: OnboardingStep,
  onb: OnboardingSignals | null | undefined,
  now: Date,
): OnboardingDecision {
  const o = onb ?? null;
  const idle: OnboardingDecision = {
    patch: {},
    nextStep: step,
    advanced: false,
    justCompleted: false,
    paused: false,
    moveDateStatus: 'none',
  };
  if (!o) return idle;

  // Edge case: user is no longer moving → pause the flow (flow.md).
  if (o.no_longer_moving) {
    return { patch: { onboarding_step: 'paused' }, nextStep: 'paused', advanced: false, justCompleted: false, paused: true, moveDateStatus: 'none' };
  }

  const { patch, moveDateOk, moveDateStatus } = extractProfilePatch(o, now);

  // Did the user answer THIS step? (controls advancement) — derived from the
  // validated patch so onboarding and post-onboarding corrections share one rule.
  const answered: Record<OnboardingStep, boolean> = {
    name: patch.name !== undefined,
    move_date: moveDateOk,
    move_type: patch.move_type !== undefined,
    from_address: patch.from_address !== undefined,
    to_address: 'to_address' in patch,
    home_type: patch.home_type !== undefined,
    household: patch.household !== undefined,
  };

  if (!answered[step]) {
    return { ...idle, patch, moveDateStatus };
  }

  const nextStep = nextStepAfter(step);
  patch.onboarding_step = nextStep;
  return {
    patch,
    nextStep,
    advanced: true,
    justCompleted: nextStep === 'completed',
    paused: false,
    moveDateStatus,
  };
}

export interface ApplyResult {
  user: UserRow;
  justCompleted: boolean;
  paused: boolean;
  /** Deterministic verdict on the move date proposed this turn (for the reply). */
  moveDateStatus: MoveDateStatus;
}

/** Apply the decision: validate (via decide), persist, return the fresh user. */
export async function applyOnboarding(
  user: UserRow,
  onb: OnboardingSignals | null | undefined,
  now: Date = new Date(),
): Promise<ApplyResult> {
  const step = currentStep(user.onboarding_step);
  if (step === 'completed' || step === 'paused') {
    return { user, justCompleted: false, paused: step === 'paused', moveDateStatus: 'none' };
  }

  const decision = decide(step, onb, now);
  const updated =
    Object.keys(decision.patch).length > 0 ? await userRepo.update(user.id, decision.patch) : user;

  return {
    user: updated,
    justCompleted: decision.justCompleted,
    paused: decision.paused,
    moveDateStatus: decision.moveDateStatus,
  };
}

export interface ProfileCorrectionResult {
  user: UserRow;
  /** True when the move date actually changed → caller must recompute deadlines. */
  moveDateChanged: boolean;
  paused: boolean;
}

/**
 * Apply a profile correction AFTER onboarding is complete (bug fix): the user
 * changes a previously-given detail ("actually my move date is the 16th"). The
 * LLM confirms in chat; the backend must persist it. Only fields that genuinely
 * CHANGED are written (no redundant updates), and the move-date change is flagged
 * so the caller can recompute checklist deadlines.
 */
export async function applyProfileCorrection(
  user: UserRow,
  onb: OnboardingSignals | null | undefined,
  now: Date = new Date(),
): Promise<ProfileCorrectionResult> {
  const o = onb ?? null;
  if (!o) return { user, moveDateChanged: false, paused: false };

  // "No longer moving" after onboarding → pause the checklist (flow.md).
  if (o.no_longer_moving) {
    const updated = await userRepo.update(user.id, { onboarding_step: 'paused' });
    return { user: updated, moveDateChanged: false, paused: true };
  }

  const { patch } = extractProfilePatch(o, now);
  // Keep only fields that differ from what's already stored.
  const changed: Partial<UserRow> = {};
  for (const [k, v] of Object.entries(patch) as [keyof UserRow, unknown][]) {
    if (JSON.stringify(v) !== JSON.stringify(user[k])) (changed as Record<string, unknown>)[k] = v;
  }
  if (Object.keys(changed).length === 0) return { user, moveDateChanged: false, paused: false };

  const moveDateChanged = 'move_date' in changed;
  const updated = await userRepo.update(user.id, changed);
  return { user: updated, moveDateChanged, paused: false };
}

/**
 * The per-turn onboarding directive injected into the prompt suffix. Tells the
 * model which step it's on and to extract into signals.onboarding, while leaving
 * the phrasing/tone to flow.md + SOUL.md.
 */
export function buildDirective(step: OnboardingStep): string {
  const next = nextStepAfter(step);
  const nextLabel = next === 'completed' ? 'samenvatting' : STEP_LABEL_NL[next as OnboardingStep];
  const stepNo = STEP_ORDER.indexOf(step) + 1;
  return [
    '[ONBOARDING — actief]',
    'De onboarding loopt. Stel precies ÉÉN vraag per bericht (volg de Flow hierboven).',
    `Huidige stap ${stepNo}/7: ${STEP_LABEL_NL[step]}.`,
    'Verwerk het bericht als antwoord op deze stap en vul signals.onboarding met de herkende waarde(n).',
    'Datum: gebruik "Vandaag" uit de actuele gegevens om relatieve datums op te lossen en geef move_date als ISO (jjjj-mm-dd). Als er geen jaar is gegeven, kies het eerstvolgende voorkomen.',
    'Bepaal of beweer NOOIT zelf of een datum in het verleden of de toekomst ligt en reken niet met datums — het systeem controleert dat. Herhaal alleen kort de datum die je begrijpt (bijv. "2 augustus") en vul move_date; bij een echt vage datum zet je date_unclear=true.',
    `- Duidelijk antwoord: bevestig kort indien nodig en stel daarna de volgende vraag: ${nextLabel}.`,
    step === 'name'
      ? '- Naam: de welkomstboodschap heeft zich AL voorgesteld en om de naam gevraagd. Dit bericht is hoogstwaarschijnlijk het antwoord met de naam — verwerk het als naam en vul signals.onboarding.name. Stel je NIET opnieuw voor en herhaal de begroeting/introductie niet. Alleen als het overduidelijk GEEN naam is (een vraag, of een kale begroeting zoals "hi"/"hello"/"thanks"), vraag dan kort nogmaals om de naam — zonder je opnieuw voor te stellen — en laat name null.'
      : '',
    '- Vage datum ("ergens in de zomer"): vraag om verduidelijking en zet date_unclear=true.',
    '- Datum in het verleden / correctie / "verhuist niet meer": volg de edge cases in de Flow en zet de juiste signalen (bv. no_longer_moving).',
    'Schrijf uitsluitend natuurlijke tekst in reply, geen opsommingen.',
    '[/ONBOARDING]',
  ]
    .filter(Boolean)
    .join('\n');
}
