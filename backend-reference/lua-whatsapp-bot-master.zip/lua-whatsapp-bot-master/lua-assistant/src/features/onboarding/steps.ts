// Onboarding steps (flow.md §Onboarding). Order is authoritative; the backend
// drives `users.onboarding_step` through it, so a returning user resumes where
// they left off (no restart).

export type OnboardingStep =
  | 'name'
  | 'move_date'
  | 'move_type'
  | 'from_address'
  | 'to_address'
  | 'home_type'
  | 'household';

export type OnboardingState = OnboardingStep | 'completed' | 'paused';

export const STEP_ORDER: OnboardingStep[] = [
  'name',
  'move_date',
  'move_type',
  'from_address',
  'to_address',
  'home_type',
  'household',
];

/** Short Dutch label per step, used in the LLM directive. */
export const STEP_LABEL_NL: Record<OnboardingStep, string> = {
  name: 'naam',
  move_date: 'verhuisdatum',
  move_type: 'huur of koop',
  from_address: 'huidige adres (straat, huisnummer, postcode, plaats)',
  to_address: 'nieuwe adres (of "onbekend")',
  home_type: 'type woning (appartement, huis, kamer)',
  household: 'wie verhuizen er mee (alleen, partner, kinderen, huisdieren)',
};

/** Normalise the stored step ('start' = brand-new user → first question). */
export function currentStep(stored: string): OnboardingState {
  if (stored === 'completed' || stored === 'paused') return stored;
  if ((STEP_ORDER as string[]).includes(stored)) return stored as OnboardingStep;
  return 'name';
}

/** The step after `step`, or 'completed' once the last step is answered. */
export function nextStepAfter(step: OnboardingStep): OnboardingState {
  const i = STEP_ORDER.indexOf(step);
  return i >= 0 && i < STEP_ORDER.length - 1 ? STEP_ORDER[i + 1]! : 'completed';
}

export function isOnboarding(state: OnboardingState): state is OnboardingStep {
  return state !== 'completed' && state !== 'paused';
}
