import { config } from '../../config/index.js';
import { sendText } from '../../services/bird.service.js';
import { generateReply } from '../../services/llm.service.js';
import { getRecentMessages } from '../memory/recentWindow.js';
import { getSummary, maybeUpdateSummary } from '../memory/summary.js';
import { buildPrompt } from './promptBuilder.js';
import { applyOnboarding, applyProfileCorrection, buildDirective } from '../onboarding/stateMachine.js';
import { currentStep, isOnboarding } from '../onboarding/steps.js';
import { generateChecklist, recomputeDueDates } from '../checklist/generate.js';
import { resolveAndCompleteTask, resolveAndRescheduleTask } from '../checklist/updateStatus.js';
import {
  renderTaskDone,
  renderTaskRescheduled,
  renderTaskRescheduleRejected,
} from '../../templates/checklist.js';
import { renderChecklistBlock, buildChecklistDirective, redactTaskKeys } from '../checklist/context.js';
import { crisisKeywordHit, buildCrisisPauseDirective } from '../safety/crisis.js';
import { jailbreakKeywordHit } from '../safety/jailbreak.js';
import { scanSensitive } from '../safety/sensitive.js';
import { decideSessionLanguage } from '../language/detect.js';
import {
  resolveOffer,
  buildAffiliateDirective,
  buildPendingDirective,
  findPendingOffer,
} from '../affiliate/eligibility.js';
import { isCommercial, delinkifyPartners } from '../affiliate/links.js';
import { applyOffered, applyDeclined, applyAccepted } from '../affiliate/apply.js';
import * as affiliateRepo from '../../repositories/affiliate.repository.js';
import { stopRequested } from '../reminders/optOut.js';
import { renderCrisis } from '../../templates/crisis.js';
import { renderJailbreak, renderOffTopic, renderSensitiveData } from '../../templates/deflection.js';
import { renderStopAck } from '../../templates/reminder.js';
import { renderSummary } from '../../templates/summary.js';
import { renderDateInPast } from '../../templates/date.js';
import { renderWelcome } from '../../templates/welcome.js';
import { guessLanguage } from '../../utils/language.js';
import { buildReplySchema, normalizeSignals } from '../../types/llm.js';
import type { OfferKey, TaskRow } from '../../types/db.js';
import { toPlainText } from '../../utils/plaintext.js';
import { todayInTz } from '../../utils/date.js';
import { buildTasklistUrl } from '../../utils/url.js';
import { logger } from '../../utils/logger.js';
import { setUserId } from '../../utils/requestContext.js';
import { time, inboundBreakdown, msSince } from '../../utils/timing.js';
import * as users from '../../repositories/user.repository.js';
import * as messages from '../../repositories/message.repository.js';
import * as taskRepo from '../../repositories/task.repository.js';
import * as sessionRepo from '../../repositories/session.repository.js';

const log = logger.child({ feature: 'conversation' });

export interface InboundMessage {
  messageId: string;
  phone: string;
  text: string;
}

/**
 * Send a final (already plain-text) message via Bird and persist it. Templates
 * (crisis/deflection/summary) are final as-is; LLM replies are passed through
 * toPlainText by the caller before they reach here.
 */
async function sendAndStore(
  userId: string,
  phone: string,
  text: string,
  commercial = false,
): Promise<string | null> {
  const providerMessageId = await sendText(phone, text);
  await time('db.message.insertOutbound', () =>
    messages.insert({
      userId,
      role: 'assistant',
      content: text,
      messageId: providerMessageId,
      status: 'accepted',
      commercial,
    }),
  );
  return providerMessageId;
}

/**
 * The message pipeline (plan.md §4), Day 5 shape:
 *   load user → scan+redact sensitive → store inbound (deduped) →
 *   PRE-LLM safety short-circuits (crisis keyword / sensitive / jailbreak keyword) →
 *   load state (summary + onboarding + checklist) → build cached prompt → LLM →
 *   POST-LLM safety net (crisis/jailbreak/off-topic signals) → crisis-pause resume →
 *   apply onboarding OR checklist completion → send → persist → refresh summary.
 *
 * Safety runs BEFORE normal generation; every hard guarantee is enforced here in
 * code, never left to the model.
 */
/**
 * Per-user processing chains. WhatsApp users fire several messages in quick
 * succession ("ok", "done", "what next"); Bird delivers each as its own webhook,
 * and the route handles them fire-and-forget. Without ordering, two turns for the
 * SAME user run concurrently and race on shared state — both read the task list
 * before either writes, so the completed count flip-flops, onboarding double-
 * advances, and the language window corrupts. We serialise per user: each inbound
 * is appended to that user's promise chain and runs only after the previous one
 * settles. Different users still run fully in parallel. In-memory is sufficient —
 * all inbound processing happens in this single (app) process.
 */
const userChains = new Map<string, Promise<void>>();

export function handleInbound(msg: InboundMessage): Promise<void> {
  const key = msg.phone;
  const prev = userChains.get(key) ?? Promise.resolve();
  // .catch keeps one failed turn from breaking the chain for the next message.
  const next = prev.catch(() => {}).then(() => runInbound(msg));
  userChains.set(key, next);
  // Drop the entry once this is the tail and it has settled (avoid unbounded growth).
  void next.finally(() => {
    if (userChains.get(key) === next) userChains.delete(key);
  });
  return next;
}

async function runInbound(msg: InboundMessage): Promise<void> {
  // Wrap the whole pipeline so EVERY exit path (early safety returns included)
  // emits one rich latency breakdown. `trackedMs` sums per-stage spans (parallel
  // DB calls overlap, so it can exceed wall-clock); compare it against totalMs to
  // see how much of the turn was spent where. Queryable in prod via this line.
  const startNs = process.hrtime.bigint();
  try {
    await processInbound(msg);
  } finally {
    const totalMs = msSince(startNs);
    const { trackedMs, spans, counts } = inboundBreakdown();
    log.info(
      { totalMs, trackedMs, spans, counts, messageId: msg.messageId },
      'inbound pipeline latency',
    );
  }
}

async function processInbound(msg: InboundMessage): Promise<void> {
  let user = await time('db.user.getOrCreate', () => users.getOrCreateByPhone(msg.phone));
  setUserId(user.id);

  // Sensitive data: scan the RAW text and redact BEFORE persisting, so a BSN /
  // IBAN / card / password is never written to the DB or fed back to the model.
  const sensitive = scanSensitive(msg.text);

  // Idempotency: a repeated Bird delivery must not generate a second reply.
  const { inserted } = await time('db.message.insertInbound', () =>
    messages.insert({
      userId: user.id,
      role: 'user',
      content: sensitive.hit ? sensitive.redacted : msg.text,
      messageId: msg.messageId,
    }),
  );
  if (!inserted) {
    log.info({ messageId: msg.messageId }, 'duplicate message_id — dropped');
    return;
  }

  // Track activity for the WhatsApp 24h window (best-effort; drives reminders).
  void sessionRepo.touch(user.id).catch((err) => log.error({ err }, 'session touch failed'));

  // ── "stop" opt-out (flow.md): halt reminders immediately, no persuasion ─────
  if (stopRequested(msg.text)) {
    if (!user.reminders_opt_out) user = await users.update(user.id, { reminders_opt_out: true });
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderStopAck(user.language));
    log.info({ userId: user.id, providerMessageId }, 'reminders opt-out set (stop)');
    return;
  }

  // ── Pre-LLM safety short-circuits ──────────────────────────────────────────
  // Crisis (keyword pre-filter): exact canned message, pause the flow, no LLM call.
  if (crisisKeywordHit(msg.text)) {
    user = await users.setSafetyPause(user.id, true);
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderCrisis());
    log.warn({ userId: user.id, providerMessageId, source: 'keyword' }, 'crisis protocol fired');
    return;
  }

  // Sensitive data sent: fixed notice, skip the LLM entirely so nothing is echoed.
  if (sensitive.hit) {
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderSensitiveData());
    log.info({ userId: user.id, providerMessageId }, 'sensitive data redacted — fixed reply sent');
    return;
  }

  // Jailbreak (keyword pre-filter): fixed deflection, no engagement, no LLM call.
  if (jailbreakKeywordHit(msg.text)) {
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderJailbreak());
    log.info({ userId: user.id, providerMessageId, source: 'keyword' }, 'jailbreak deflected');
    return;
  }

  // ── First contact: instant fixed welcome (NO LLM) ────────────────────────────
  // Brand-new user (DB default onboarding_step='start'). Send the client-approved
  // welcome in the heuristically-guessed language and advance to the name step, so
  // the very first reply is fast and always identical. The next message adapts
  // language via the normal detector. Runs AFTER safety filters (a crisis/jailbreak
  // first message must still route correctly).
  if (user.onboarding_step === 'start') {
    const lang = guessLanguage(msg.text);
    const parts = renderWelcome(lang); // client copy, split into 3 bubbles
    // LOCK the session language here, from the user's FIRST message. This is the
    // richest language signal we get: later onboarding answers are names, dates,
    // and addresses (e.g. "Rodger", "alexanderkade 5hs") that carry no language and
    // get misdetected as English. Seeding recent_languages=[lang] flips every later
    // turn into the "established" prompt directive (which holds the language even
    // when the user drops in a foreign word), and decideSessionLanguage then never
    // drifts — only an explicit "speak English" request can change it.
    //
    // The step-advance and the outbound-store writes run CONCURRENTLY with the
    // sends (collected in `writes`), so the user doesn't wait on DB. The welcome
    // bubbles are sent SEQUENTIALLY so WhatsApp shows them in order. We await every
    // write before returning, so the step is durably 'name' (with per-user
    // serialization, a Bird retry can't re-send the welcome) and each message is
    // recorded.
    const writes: Promise<unknown>[] = [
      time('db.user.advanceStep', () =>
        users.update(user.id, {
          onboarding_step: 'name',
          language: lang,
          recent_languages: [lang],
        }),
      ),
    ];
    const providerMessageIds: (string | null)[] = [];
    for (const [i, part] of parts.entries()) {
      // Bird/WhatsApp deliver back-to-back sends out of order. A ~1s gap between
      // welcome bubbles keeps them in sequence for the user (greeting only).
      if (i > 0) await new Promise((r) => setTimeout(r, 1000));
      const id = await sendText(msg.phone, part);
      providerMessageIds.push(id);
      writes.push(
        messages.insert({
          userId: user.id,
          role: 'assistant',
          content: part,
          messageId: id,
          status: 'accepted',
        }),
      );
    }
    await Promise.all(writes);
    log.info(
      { userId: user.id, lang, parts: parts.length, providerMessageIds },
      'welcome sent (first contact, no LLM)',
    );
    return;
  }

  // ── Load state ──────────────────────────────────────────────────────────────
  const step = currentStep(user.onboarding_step);
  const onboardingActive = isOnboarding(step);
  const completed = step === 'completed';
  const paused = user.safety_paused_at != null;

  // Timed individually (not as one group) so we can see WHICH read is slow —
  // they run in parallel, so each span overlaps the others in wall-clock time.
  const [history, summary, tasks] = await Promise.all([
    time('db.history', () => getRecentMessages(user.id, config.HISTORY_WINDOW_N)),
    time('db.summary', () => getSummary(user.id)),
    completed
      ? time('db.tasks', () => taskRepo.listByUser(user.id))
      : Promise.resolve<TaskRow[]>([]),
  ]);

  // Affiliate eligibility is decided HERE (before the LLM): an offer is allowed
  // only if the user raised the topic AND it's on their checklist, past all guards.
  // With no directive, the model cannot offer (monetization.md). Onboarding/paused
  // turns never offer.
  let eligibleOffer: OfferKey | null = null;
  let pendingOffer: OfferKey | null = null;
  if (completed && !paused) {
    eligibleOffer = (await time('affiliate.resolveOffer', () => resolveOffer(user, msg.text, tasks)))
      .offer;
    // The "ja" turn carries no trigger keyword, so resolveOffer can't see it: an
    // earlier offer may still be awaiting accept/decline. Only relevant when we're
    // NOT making a fresh offer this turn (a new trigger takes priority).
    if (!eligibleOffer) {
      pendingOffer = await time('affiliate.findPending', () => findPendingOffer(user.id));
    }
  }
  // The model writes the disclosure itself, but only on the user's FIRST-ever offer
  // AND only for a commercial (active-affiliate) partner — "Commission to confirm"
  // links are presented as a convenience with no disclosure (monetization.md).
  const includeDisclosure =
    eligibleOffer && isCommercial(eligibleOffer)
      ? !(await affiliateRepo.disclosureEverSent(user.id))
      : false;

  // ── Build prompt (dynamic suffix only; cached prefix untouched) ──────────────
  const { system, messages: promptMessages } = buildPrompt(user, history, {
    summary,
    onboardingDirective: onboardingActive && !paused ? buildDirective(step) : undefined,
    checklistBlock: completed && tasks.length > 0 && !paused ? renderChecklistBlock(tasks) : undefined,
    checklistDirective: completed && tasks.length > 0 && !paused ? buildChecklistDirective() : undefined,
    crisisPauseDirective: paused ? buildCrisisPauseDirective() : undefined,
    affiliateDirective: eligibleOffer
      ? buildAffiliateDirective(eligibleOffer, includeDisclosure)
      : pendingOffer
        ? buildPendingDirective(pendingOffer)
        : undefined,
  });

  // Ask only for the signal groups this state will act on (fewer forced output
  // tokens → lower latency). normalizeSignals coerces the result back to the full
  // shape, so every read below is safe regardless of which groups were requested.
  const replySchema = buildReplySchema({
    onboardingActive,
    completed,
    paused,
    offerEligible: eligibleOffer != null,
    offerPending: pendingOffer != null,
  });
  const { object, cachedInputTokens } = await generateReply({
    system,
    messages: promptMessages,
    schema: replySchema,
  });
  const reply = (object as { reply: string }).reply;
  const sig = normalizeSignals((object as { signals: unknown }).signals);

  // Adaptive session language: follow the user's recent-majority language and any
  // explicit switch request (client req). Decided in memory so the rest of this
  // turn sees it, but PERSISTED off the critical path — the reply being sent now
  // already baked in its language from the prior state; the stored value only
  // matters for the NEXT turn and for reminders. Mirrors maybeUpdateSummary below.
  const langUpdate = decideSessionLanguage(user, sig.detected_language, sig.requested_language);
  if (langUpdate) {
    user = { ...user, language: langUpdate.language, recent_languages: langUpdate.recent_languages };
    if (langUpdate.switched) {
      log.info({ userId: user.id, language: langUpdate.language }, 'session language updated');
    }
    void users
      .update(user.id, {
        language: langUpdate.language,
        recent_languages: langUpdate.recent_languages,
      })
      .catch((err) => log.error({ err, userId: user.id }, 'language persist failed'));
  }

  // ── Post-LLM safety net (override the reply; skip all side-effects) ──────────
  // Crisis the keyword filter missed (or still ongoing while paused).
  if (sig.crisis) {
    if (!paused) user = await users.setSafetyPause(user.id, true);
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderCrisis());
    log.warn({ userId: user.id, providerMessageId, source: 'signal' }, 'crisis protocol fired');
    return;
  }
  if (sig.jailbreak) {
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderJailbreak());
    log.info({ userId: user.id, providerMessageId, source: 'signal' }, 'jailbreak deflected');
    return;
  }
  if (sig.off_topic) {
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderOffTopic());
    log.info({ userId: user.id, providerMessageId }, 'off-topic deflected');
    return;
  }
  // Stop the keyword filter missed: opt out, fixed ack, no persuasion.
  if (sig.stop_reminders) {
    if (!user.reminders_opt_out) user = await users.update(user.id, { reminders_opt_out: true });
    const providerMessageId = await sendAndStore(user.id, msg.phone, renderStopAck(user.language));
    log.info({ userId: user.id, providerMessageId, source: 'signal' }, 'reminders opt-out set (stop)');
    return;
  }

  // ── Crisis pause: resume only on explicit OK (instructions.md) ───────────────
  if (paused) {
    if (!sig.safety.resume_ok) {
      // Stay paused: send the supportive reply, do not touch onboarding/checklist.
      const providerMessageId = await sendAndStore(
        user.id,
        msg.phone,
        delinkifyPartners(toPlainText(reply)),
      );
      log.info({ userId: user.id, providerMessageId }, 'reply sent (crisis pause held)');
      return;
    }
    user = await users.setSafetyPause(user.id, false);
    log.info({ userId: user.id }, 'crisis pause resumed by user');
  }

  // ── Normal handling ──────────────────────────────────────────────────────────
  // delinkifyPartners: strip any partner DOMAIN the model wrote (→ brand name) so
  // the only clickable link is the backend's tracked URL (appended below). Runs on
  // the model reply only; code-rendered templates + the tracked link aren't touched.
  let outgoing = delinkifyPartners(toPlainText(reply));
  let justCompleted = false;
  let commercial = false;

  if (onboardingActive) {
    // Onboarding: backend validates + persists + advances (LLM only proposes).
    const result = await time('onboarding.apply', () => applyOnboarding(user, sig.onboarding));
    user = result.user;
    justCompleted = result.justCompleted;
    if (justCompleted) {
      // Generate the checklist before the summary (which links to it). Best-effort:
      // a failure logs and still sends the summary rather than blocking the reply.
      try {
        await time('checklist.generate', () => generateChecklist(user));
      } catch (err) {
        log.error({ err, userId: user.id }, 'checklist generation failed');
      }
      outgoing = renderSummary(user); // exact template (flow.md), not LLM text
    } else if (result.moveDateStatus === 'past' && sig.onboarding.move_date) {
      // The user gave a past move date. The model is unreliable at past/future
      // arithmetic (it once called a future date "passed"), so the backend owns
      // this verdict and the exact wording — overriding whatever the model wrote.
      outgoing = renderDateInPast(sig.onboarding.move_date, todayInTz(config.TZ), user.language);
    }
  } else if (completed) {
    // All post-LLM persistence for a completed user, timed as one stage (each is a
    // small DB write; drill into the repo if this span ever dominates a turn).
    await time('pipeline.completedApply', async () => {
      // Per-task deadline change ("change the deadline for task X to the 16th").
      // This is a SINGLE task's due_date — not the moving date. Defensive guard: if
      // the user is rescheduling a task, strip move_date from the correction so a
      // date the model mis-routed into move_date can never shift the whole plan.
      const reschedKey = sig.checklist.task_reschedule_key?.trim();
      const wantsReschedule = !!reschedKey && !!sig.checklist.task_new_due_date?.trim();
      const onboardingForCorrection = wantsReschedule
        ? { ...sig.onboarding, move_date: null }
        : sig.onboarding;

      // Post-onboarding profile correction (e.g. "actually my move date is the 16th").
      // The LLM confirms in chat; the backend must persist it (and re-date the list).
      const corr = await applyProfileCorrection(user, onboardingForCorrection);
      user = corr.user;
      if (corr.moveDateChanged) {
        try {
          await recomputeDueDates(user);
        } catch (err) {
          log.error({ err, userId: user.id }, 'due-date recompute failed');
        }
      }

      // WhatsApp completion: the backend resolves WHICH task (the model only
      // detects intent + an optional explicit key) and code-renders the
      // confirmation, so the task we name is always the task we actually marked.
      const completion = await resolveAndCompleteTask(
        user.id,
        tasks,
        sig.checklist.task_completed,
        sig.checklist.task_done_key,
      );
      if (completion) {
        log.info(
          { userId: user.id, taskKey: completion.done.task_key, next: completion.next?.task_key ?? null },
          'task marked done via whatsapp',
        );
        outgoing = renderTaskDone(completion.done.title, completion.next?.title ?? null, user.language);
      } else if (wantsReschedule) {
        // Change ONE task's deadline (only when this turn isn't a completion). The
        // backend validates the key + date and writes a single due_date; on success
        // OR a clear rejection it code-renders the reply, so the confirmation always
        // matches what actually changed. An unknown key leaves the model's reply.
        const today = todayInTz(config.TZ);
        const resched = await resolveAndRescheduleTask(
          user.id,
          tasks,
          reschedKey,
          sig.checklist.task_new_due_date,
          today,
        );
        if (resched?.ok) {
          outgoing = renderTaskRescheduled(resched.task.title, resched.newDueDate, user.language);
        } else if (resched && !resched.ok && resched.reason !== 'unknown') {
          outgoing = renderTaskRescheduleRejected(
            resched.task!.title,
            resched.reason,
            today,
            user.language,
          );
        }
      }

      // Affiliate (backend disposes). Priority: if the user ACCEPTED a pending
      // offer, deliver the partner link (appended in code; the model never writes
      // a URL). Otherwise record a decline and, on a non-completion turn, honour a
      // fresh eligible offer (disclosure + 1-in-5 marking).
      const accept = await applyAccepted(
        user,
        pendingOffer,
        sig.affiliate.user_accepted,
        outgoing,
      );
      outgoing = accept.outgoing;
      if (accept.delivered) {
        commercial = true;
      } else {
        await applyDeclined(user, sig.affiliate.user_declined);
        if (!completion) {
          const aff = await applyOffered(user, eligibleOffer, sig.affiliate.offered, outgoing);
          outgoing = aff.outgoing;
          commercial = aff.commercial;
        }
      }

      // Dashboard/checklist link: the user asked where their task list is. The
      // backend appends the EXACT tasklist URL — the unguessable token must never
      // be typed (and possibly mangled) by the model. This is a normal, clickable
      // link (not a partner domain), so delinkifyPartners leaves it untouched.
      if (sig.checklist.wants_dashboard) {
        outgoing = `${outgoing}\n\n${buildTasklistUrl(user.tasklist_token)}`;
        log.info({ userId: user.id }, 'dashboard link delivered');
      }
    });
  }

  // Backend guarantee: an internal task_key must never reach the user — if the
  // model echoed one, swap it for the readable title before sending.
  if (completed && tasks.length > 0) outgoing = redactTaskKeys(outgoing, tasks);

  const providerMessageId = await sendAndStore(user.id, msg.phone, outgoing, commercial);
  log.info(
    { userId: user.id, step: user.onboarding_step, justCompleted, commercial, providerMessageId, cachedInputTokens },
    'reply queued',
  );

  // Rolling summary on cadence — best-effort, never blocks the reply path.
  void maybeUpdateSummary(user.id).catch((err) => log.error({ err }, 'summary update failed'));
}
