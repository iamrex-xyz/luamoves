import type { ModelMessage } from 'ai';
import { config } from '../../config/index.js';
import { prompts } from '../../config/prompts.js';
import type { MessageRow, UserRow } from '../../types/db.js';
import { languageName, normalizeLanguageCode } from '../../utils/language.js';

/**
 * Tiered, prefix-stable prompt assembly (plan.md §6).
 *
 *   [CACHED PREFIX — static, identical every turn]
 *     SOUL.md + safety rules (instructions.md) + facts (knowledge.md)
 *   [DYNAMIC SUFFIX — changes per turn]
 *     conversation history → per-turn state block → new user message
 *
 * The static prefix is built ONCE at module load and never mutated at runtime,
 * so the model's automatic prompt caching reuses it across turns. Anything that
 * changes per turn lives in the message tail, never in the system prompt.
 *
 * Day 3 keeps the dynamic state minimal. flow.md (onboarding), the rolling
 * summary, and the affiliate directive are layered in on later days.
 */
/**
 * Output-language directive — defined in CODE (never in the client's spec files),
 * and placed LAST in the dynamic suffix so it OVERRIDES any default-language hint
 * in the spec (e.g. SOUL.md's "Nederlands standaard"). Three modes:
 *
 *   1. FORCED   (REPLY_LANGUAGE set) — dev override; always reply in it.
 *   2. ESTABLISHED (recent_languages non-empty) — reply in the backend-decided
 *      session language; honour an explicit switch request this turn.
 *   3. DETECT   (first contact, nothing established yet) — reply in the user's own
 *      message language; no Dutch default.
 *
 * Every mode demands a SINGLE-LANGUAGE reply (never a mix) and asks the model to
 * report detected_language / requested_language so the backend can dispose.
 * Governs ONLY the conversational reply text; persona, rules, and code-rendered
 * templates are unaffected.
 */
export function buildLanguageDirective(user: UserRow): string {
  const forced = config.REPLY_LANGUAGE;
  if (forced) {
    const name = normalizeLanguageCode(forced) ? languageName(forced) : forced;
    return [
      '[OUTPUT LANGUAGE — IMPORTANT]',
      `Write your "reply" to the user ENTIRELY in ${name}, even though the instructions above may be in another language.`,
      'Never mix languages in one reply. This changes only the output language — keep your persona, tone, rules, and meaning unchanged.',
      '[/OUTPUT LANGUAGE]',
    ].join('\n');
  }

  const reportLine =
    'Always set signals.detected_language to the ISO 639-1 code of the language the user wrote THIS message in, ' +
    'and signals.requested_language only if they explicitly ask to switch languages (else null).';

  if ((user.recent_languages ?? []).length > 0) {
    const name = languageName(user.language);
    return [
      '[OUTPUT LANGUAGE — IMPORTANT]',
      `Write your ENTIRE "reply" in ${name} (${user.language}) — every sentence, no mixing in words from another language.`,
      `Keep using ${name} even if the user drops in a stray word or sentence in another language.`,
      'EXCEPTION: if in THIS message the user explicitly asks to switch languages (e.g. "reply in English"), ' +
        'write your reply fully in that requested language instead.',
      reportLine,
      'This changes only the output language; persona, tone, and rules stay the same.',
      '[/OUTPUT LANGUAGE]',
    ].join('\n');
  }

  return [
    '[OUTPUT LANGUAGE — IMPORTANT]',
    'Detect the language of the user\'s message and write your ENTIRE reply in that same language — never mix languages.',
    'Do NOT default to Dutch: a short greeting like "Hi" or "Hello how are you" is English, so reply in English.',
    reportLine,
    'This changes only the output language; persona, tone, and rules stay the same.',
    '[/OUTPUT LANGUAGE]',
  ].join('\n');
}

/**
 * Code-defined hard rule (not in the client spec): stops the model inventing
 * partner links. Real LLMs will happily emit plausible-but-fake URLs (e.g. a
 * moving-company site that doesn't exist) — the backend owns every link, so the
 * model must never produce one on its own. Placed last in the cached prefix and
 * reinforced inside the [AANBOD] directive (eligibility.ts).
 */
const LINK_DISCIPLINE: string = [
  '[LINKS & COMMERCIËLE AANBIEDINGEN — HARDE REGELS (gaan boven alles hierboven)]',
  'Je kent GEEN partner-URLs, domeinen of websites. Schrijf, verzin, gok of "herinner" NOOIT zelf een URL, webadres of bedrijfs-/websitenaam.',
  'Deel een link ALLEEN als het systeem je deze beurt de EXACTE link geeft in een [AANBOD]-blok — gebruik dan die link letterlijk en geen andere. Geen [AANBOD]-blok = geen link en geen commercieel aanbod.',
  'De partner- en triggertabellen in de monetization-sectie zijn achtergrond voor de backend; ze zijn GEEN toestemming om zelf een aanbod te doen, een bedrijf te noemen of een link te maken.',
  'Heb je geen aangeleverde link, zeg dan dat je de link stuurt en stop — vervang die nooit door een website waarvan je dénkt dat die bestaat.',
  '[/LINKS & COMMERCIËLE AANBIEDINGEN]',
].join('\n');

const STATIC_PREFIX: string = [
  prompts.files['SOUL.md'],
  prompts.files['instructions.md'],
  prompts.files['knowledge.md'],
  prompts.files['monetization.md'],
  LINK_DISCIPLINE,
].join('\n\n---\n\n');

/** Today's date in the configured timezone, as YYYY-MM-DD. */
function todayInTz(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: config.TZ }).format(new Date());
}

/** Per-turn snapshot of authoritative state (rendered into the tail). */
function buildStateBlock(user: UserRow): string {
  // Today's date is DYNAMIC → belongs in the suffix, never the cached prefix.
  // Without it the model guesses the year for relative dates ("12th Jun").
  const lines: string[] = ['[ACTUELE GEGEVENS]', `Vandaag (today): ${todayInTz()}`];
  if (user.name) lines.push(`Naam: ${user.name}`);
  // Only state the language once it's actually been established from the user's
  // own messages. Emitting the 'nl' default here would falsely assert Dutch on a
  // brand-new user and bias the very first reply (the output-language directive
  // below owns the language decision instead).
  if ((user.recent_languages ?? []).length > 0) lines.push(`Taal: ${user.language}`);
  if (user.move_date) lines.push(`Verhuisdatum: ${user.move_date}`);
  if (user.move_type) lines.push(`Type: ${user.move_type}`);
  if (user.from_address) lines.push(`Huidig adres: ${user.from_address}`);
  if (user.to_address) lines.push(`Nieuw adres: ${user.to_address}`);
  lines.push('[/ACTUELE GEGEVENS]');
  return lines.join('\n');
}

export interface BuiltPrompt {
  system: string;
  messages: ModelMessage[];
}

export interface PromptOptions {
  /** Rolling summary text to include (plan.md §7), if any. */
  summary?: string | null;
  /** Onboarding directive — when present, flow.md is included too (Tier 2). */
  onboardingDirective?: string;
  /** Rendered [CHECKLIST] block (post-onboarding); shown with the directive below. */
  checklistBlock?: string;
  /** Checklist directive — how to use the checklist + propose task_done_key. */
  checklistDirective?: string;
  /** Crisis-pause directive — present only while the flow is paused (plan.md §14). */
  crisisPauseDirective?: string;
  /** Affiliate directive — present only when the backend deems an offer eligible. */
  affiliateDirective?: string;
}

/**
 * @param user    the authoritative user row (for the state block)
 * @param history recent messages, oldest → newest, INCLUDING the new inbound
 *                message as the final entry.
 * @param opts    dynamic-suffix extras (summary, onboarding directive).
 *
 * Everything dynamic goes into a preamble prepended to the final user message,
 * so the cached system prefix and message history stay byte-stable for caching.
 */
export function buildPrompt(
  user: UserRow,
  history: MessageRow[],
  opts: PromptOptions = {},
): BuiltPrompt {
  const messages: ModelMessage[] = history.map((m) => ({
    role: m.role,
    content: m.content,
  }));

  const preamble: string[] = [];
  // Tier 2: flow.md only while onboarding is active.
  if (opts.onboardingDirective) {
    preamble.push(prompts.files['flow.md']);
    preamble.push(opts.onboardingDirective);
  }
  // Post-onboarding: the live checklist + how to use it.
  if (opts.checklistBlock) preamble.push(opts.checklistBlock);
  if (opts.checklistDirective) preamble.push(opts.checklistDirective);
  // Affiliate offer is allowed only when the backend says so (eligibility gated).
  if (opts.affiliateDirective) preamble.push(opts.affiliateDirective);
  preamble.push(buildStateBlock(user));
  if (opts.summary) {
    preamble.push(`[SAMENVATTING — eerdere context]\n${opts.summary}\n[/SAMENVATTING]`);
  }
  // Crisis pause governs behaviour → keep it late (strong), just before the
  // output-language directive (which only governs language).
  if (opts.crisisPauseDirective) preamble.push(opts.crisisPauseDirective);
  // Language directive LAST so it has the strongest influence on output language.
  preamble.push(buildLanguageDirective(user));

  const last = messages[messages.length - 1];
  if (last && last.role === 'user') {
    last.content = `${preamble.join('\n\n')}\n\n${last.content as string}`;
  }

  return { system: STATIC_PREFIX, messages };
}
