import * as messageRepo from '../../repositories/message.repository.js';
import type { MessageRow } from '../../types/db.js';

/**
 * Recent-window memory (plan.md §7, layer 3): the last N raw messages verbatim,
 * oldest → newest, for immediate conversational coherence.
 */
export function getRecentMessages(userId: string, n: number): Promise<MessageRow[]> {
  return messageRepo.getRecent(userId, n);
}
