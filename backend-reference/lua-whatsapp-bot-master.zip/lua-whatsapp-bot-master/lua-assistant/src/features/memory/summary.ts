import { config } from '../../config/index.js';
import { summarize } from '../../services/llm.service.js';
import * as messageRepo from '../../repositories/message.repository.js';
import * as summaryRepo from '../../repositories/summary.repository.js';
import { logger } from '../../utils/logger.js';

const log = logger.child({ feature: 'memory/summary' });

/** Current rolling summary text for a user (plan.md §7, layer 2), or null. */
export async function getSummary(userId: string): Promise<string | null> {
  const row = await summaryRepo.get(userId);
  return row?.summary ?? null;
}

const SYSTEM = [
  'Je vat WhatsApp-gesprekken samen voor een Nederlandse verhuisassistent.',
  'Vat ALLEEN nuance en context samen: toon, stress, voorkeuren, losse opmerkingen.',
  'Herhaal GEEN feiten die al in het profiel staan (naam, verhuisdatum, adressen, huur/koop, type woning, huishouden).',
  'Schrijf bondig (max ~120 woorden), in het Nederlands, in de derde persoon.',
].join(' ');

/**
 * Regenerate the rolling summary on cadence (every SUMMARY_EVERY_N messages),
 * over the turns that have scrolled out of the recent window. Best-effort:
 * failures are logged, never thrown into the message path.
 */
export async function maybeUpdateSummary(userId: string): Promise<void> {
  const total = await messageRepo.countByUser(userId);
  if (total < config.SUMMARY_EVERY_N || total % config.SUMMARY_EVERY_N !== 0) return;

  // Summarise everything except the most recent window (those stay verbatim).
  const recent = await messageRepo.getRecent(userId, 200);
  const older = recent.slice(0, Math.max(0, recent.length - config.HISTORY_WINDOW_N));
  if (older.length === 0) return;

  const previous = (await summaryRepo.get(userId))?.summary;
  const transcript = older.map((m) => `${m.role}: ${m.content}`).join('\n');
  const prompt = `${previous ? `Eerdere samenvatting:\n${previous}\n\n` : ''}Gesprek:\n${transcript}`;

  const summary = await summarize(SYSTEM, prompt);
  const upTo = older[older.length - 1]?.created_at ?? new Date().toISOString();
  await summaryRepo.upsert(userId, summary, upTo);
  log.info({ userId, messages: older.length }, 'rolling summary updated');
}
