import type { TaskRow } from '../../types/db.js';

/**
 * Renders the CHECKLIST block + directive injected into the prompt's dynamic
 * suffix once onboarding is complete. Mirrors onboarding's buildDirective: the
 * backend states the facts and the rules; the model writes the natural-language
 * reply and proposes a task_done_key the backend then validates.
 *
 * task_key is shown so the model can echo it back deterministically; it isn't
 * secret. Everything here is per-turn → lives in the tail, never the cached prefix.
 */
/** How many upcoming pending tasks to surface in the prompt (token budget). */
const MAX_PROMPT_TASKS = 15;
/** How many completed tasks to list (so the model can answer "which are done?"). */
const MAX_DONE_TASKS = 12;

/**
 * Render the prompt's checklist block. With the full master list (~45 tasks) we
 * don't dump everything every turn, but we DO give the model complete, accurate
 * ground truth so it never has to guess: explicit counts (done · open · total),
 * the completed tasks (capped), and the next upcoming PENDING tasks by due date.
 * Pending tasks carry their task_key so the model can propose a completion; done
 * tasks don't (no key needed, and keys must never reach the user). Full list lives
 * on the web page.
 */
export function renderChecklistBlock(tasks: TaskRow[]): string {
  const done = tasks.filter((t) => t.status === 'completed');
  const pending = tasks
    .filter((t) => t.status === 'pending')
    .sort((a, b) => (a.due_date ?? '9999').localeCompare(b.due_date ?? '9999'));

  const shownPending = pending.slice(0, MAX_PROMPT_TASKS);
  const pendingLines = shownPending.map((t) => {
    const due = t.due_date ? `, deadline ${t.due_date}` : '';
    return `- [${t.task_key}] ${t.title}${due}`;
  });
  const morePending = pending.length - shownPending.length;

  const shownDone = done.slice(0, MAX_DONE_TASKS);
  const doneLines = shownDone.map((t) => `- ${t.title}`);
  const moreDone = done.length - shownDone.length;

  // The "current" task: nearest-due pending — the one a bare "done" refers to and
  // the one the daily reminder names. Surfaced so the model never has to guess it.
  const current = pending[0];

  return [
    `[CHECKLIST — ${done.length} afgerond · ${pending.length} open · ${tasks.length} totaal]`,
    current ? `Huidige taak: ${current.title}` : '',
    'Afgeronde taken:',
    ...(doneLines.length ? doneLines : ['- (nog geen)']),
    moreDone > 0 ? `(+${moreDone} meer afgerond)` : '',
    'Eerstvolgende open taken:',
    ...pendingLines,
    morePending > 0 ? `(+${morePending} meer open taken op de checklist)` : '',
    '[/CHECKLIST]',
  ]
    .filter(Boolean)
    .join('\n');
}

/**
 * Backend guarantee against task_key leaks: replace any internal task_key the
 * model echoed into its reply with the human-readable title (or strips it). The
 * key is shown in the prompt only so the model can propose completions — it must
 * never reach the user (it did: "renthuisartstandartsenapotheek_informeren").
 */
export function redactTaskKeys(text: string, tasks: TaskRow[]): string {
  let out = text;
  for (const t of tasks) {
    if (!t.task_key) continue;
    out = out.split(`[${t.task_key}]`).join(t.title).split(t.task_key).join(t.title);
  }
  return out;
}

export function buildChecklistDirective(): string {
  return [
    '[CHECKLIST — gebruik]',
    'De onboarding is afgerond; de checklist hierboven is de actuele stand.',
    'Aantallen en taken: gebruik UITSLUITEND de cijfers (afgerond · open · totaal) en de taken uit het',
    'CHECKLIST-blok hierboven. Verzin NOOIT zelf aantallen en tel niet uit je geheugen — als de gebruiker',
    'vraagt hoeveel/welke taken klaar of open zijn, lees dat exact uit het blok.',
    'task_key is INTERN: toon de key NOOIT aan de gebruiker (bijv. niet "renthuis..._informeren"). Noem altijd',
    'de leesbare titel. Gebruik de key alleen in signals.checklist.task_done_key.',
    'Afronden van een taak: zegt de gebruiker dat iets klaar is ("done", "klaar", "gedaan", "geregeld"),',
    'zet dan signals.checklist.task_completed op true. Noemt de gebruiker EXPLICIET wélke taak, zet dan ook',
    'signals.checklist.task_done_key op de EXACTE task_key tussen [ ] van die taak. Bij een algemeen "klaar"',
    'zonder specifieke taak: laat task_done_key null — de backend vinkt dan de "Huidige taak" af. Verzin nooit',
    'een key. De backend kiest de taak, boekt hem af én schrijft zelf de bevestiging; jouw reply-tekst voor zo’n',
    'afvink-bericht wordt vervangen, dus houd het simpel.',
    'Wees proactief volgens de Flow: na een afgeronde taak of bij een naderende deadline (3–5 dagen)',
    'mag je kort de logische volgende stap voorstellen. Geen lange lijstjes, geen ongevraagde verkoop.',
    'Wijziging: wil de gebruiker een eerder gegeven gegeven aanpassen (verhuisdatum, adres, naam, huur/koop),',
    'zet dan de NIEUWE waarde in signals.onboarding.<veld> (datum als ISO jjjj-mm-dd). Anders laat je die velden null.',
    'Deadline van ÉÉN taak verzetten: vraagt de gebruiker om de deadline/datum van een SPECIFIEKE taak te wijzigen',
    '(bijv. "verzet de deadline van X naar 16 augustus"), zet dan signals.checklist.task_reschedule_key op de EXACTE',
    'task_key van die taak en signals.checklist.task_new_due_date op de nieuwe datum (ISO jjjj-mm-dd). Dit is de',
    'deadline van die ene taak — zet zo’n datum NOOIT in onboarding.move_date (de verhuisdatum) en verschuif niet',
    'het hele plan. De backend wijzigt alleen die taak en schrijft zelf de bevestiging; houd je reply-tekst kort.',
    'Dashboard/takenlijst: vraagt de gebruiker waar zijn dashboard, checklist of takenlijst is, of vraagt hij om de',
    'link daarnaartoe, bevestig dan kort (bijv. "Hier is je checklist:") en zet signals.checklist.wants_dashboard=true.',
    'Schrijf de URL NOOIT zelf — het systeem voegt de juiste link toe aan jouw bericht.',
    '[/CHECKLIST]',
  ].join('\n');
}
