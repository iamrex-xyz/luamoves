import { config } from '../../config/index.js';
import type { TaskTemplateRow, UserRow } from '../../types/db.js';
import * as taskRepo from '../../repositories/task.repository.js';
import type { NewTask } from '../../repositories/task.repository.js';
import { addDays, todayInTz } from '../../utils/date.js';
import { normalizeLanguageCode } from '../../utils/language.js';
import { logger } from '../../utils/logger.js';

const log = logger.child({ feature: 'checklist/generate' });

export interface HouseholdFlags {
  children: boolean;
  pets: boolean;
}

// Keyword heuristics over the free-text household description. The master list
// only gates on kinderen/huisdieren that we can derive; everything else applies
// to everyone (per the Day 7 decision). en + nl terms.
const CHILDREN_TERMS = ['child', 'children', 'kid', 'kids', 'son', 'daughter', 'baby',
  'kind', 'kinderen', 'kindje', 'zoon', 'dochter', 'baby\'s'];
const PETS_TERMS = ['pet', 'pets', 'dog', 'cat', 'cats', 'dogs',
  'huisdier', 'huisdieren', 'hond', 'honden', 'kat', 'katten', 'poes'];

/**
 * Map each master-list phase (fase 1..7) to a due-date offset in days relative to
 * move_date. The client's list has no day offsets, so we derive sensible deadlines
 * from the phase: early-prep phases land well before the move, phase 6 is the move
 * day, phase 7 is settling-in just after. Keeps the reminder engine date-based.
 */
export const PHASE_OFFSET_DAYS: Record<number, number> = {
  1: -45, 2: -30, 3: -21, 4: -10, 5: -5, 6: 0, 7: 7,
};

/** Derive children/pets flags from the household free-text (pure). */
export function deriveHousehold(household: UserRow['household']): HouseholdFlags {
  const description =
    household && typeof household === 'object' && 'description' in household
      ? String((household as { description: unknown }).description ?? '')
      : '';
  const text = ` ${description.toLowerCase()} `;
  const has = (terms: string[]): boolean =>
    terms.some((t) => new RegExp(`\\b${escapeRegExp(t)}\\b`).test(text));
  return { children: has(CHILDREN_TERMS), pets: has(PETS_TERMS) };
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** True when a template's condition holds for this user (pure). */
function conditionApplies(condition: string, hh: HouseholdFlags): boolean {
  switch (condition) {
    case 'kinderen':
      return hh.children;
    case 'huisdieren':
      return hh.pets;
    // 'altijd' and the situational conditions (verbouwing/hoog/parkeren) are
    // shown to everyone — we can't derive them, and completeness was chosen.
    default:
      return true;
  }
}

/**
 * Due date for a phase = move_date + the phase's offset, CLAMPED so it's never
 * before `today`. Without the clamp, a near-term move (e.g. 6 days out) pushes
 * early-phase tasks (-45/-30 days) into the past — tasks would show last-month
 * deadlines. Clamping makes those "due now" instead. Null if no move date.
 */
export function computeDueDate(
  phaseOrder: number,
  moveDate: string | null,
  today: string,
): string | null {
  if (!moveDate) return null;
  const raw = addDays(moveDate, PHASE_OFFSET_DAYS[phaseOrder] ?? 0);
  return raw < today ? today : raw; // ISO yyyy-mm-dd compares lexicographically
}

export function dueDateFor(
  template: TaskTemplateRow,
  moveDate: string | null,
  today: string,
): string | null {
  return computeDueDate(template.phase_order, moveDate, today);
}

/**
 * The task title in the user's locked session language. English users get
 * `title_en` (master list 0011); Dutch (and anything without an English title)
 * fall back to the Dutch `title`. Resolved once here at creation, so reminders
 * (template messages, no LLM) and the tasklist page read a single stored title.
 */
function titleFor(template: TaskTemplateRow, language: string | null | undefined): string {
  return normalizeLanguageCode(language) === 'en' && template.title_en
    ? template.title_en
    : template.title;
}

/**
 * PURE: choose the tasks for a user from the master list and compute due dates.
 * No DB. Filters by move type + condition; carries the rich fields (phase,
 * category, explanation, tip) through for the web page. Titles are localised to
 * the user's session language.
 */
export function selectTasks(user: UserRow, templates: TaskTemplateRow[], today: string): NewTask[] {
  const hh = deriveHousehold(user.household);
  return templates
    .filter((t) => t.move_type === user.move_type && conditionApplies(t.condition, hh))
    .map((t) => ({
      user_id: user.id,
      task_key: t.task_key,
      title: titleFor(t, user.language),
      due_date: dueDateFor(t, user.move_date, today),
      affiliate_trigger: t.affiliate_trigger,
      phase_order: t.phase_order,
      phase_name: t.phase_name,
      category: t.category,
      explanation: t.explanation,
      tip: t.tip,
      sort_order: t.sort_order,
    }));
}

/**
 * Generate (and persist) the personalised checklist after onboarding completes.
 * Idempotent: insertMany ignores tasks that already exist, so a completed task is
 * never reset. Returns the number of newly-created tasks.
 */
export async function generateChecklist(user: UserRow): Promise<number> {
  const templates = await taskRepo.listTemplates();
  const tasks = selectTasks(user, templates, todayInTz(config.TZ));
  const created = await taskRepo.insertMany(tasks);
  log.info(
    { userId: user.id, candidates: tasks.length, created, moveType: user.move_type },
    'checklist generated',
  );
  return created;
}

/**
 * Recompute every task's due date from its phase + the user's CURRENT move date
 * (called after a move-date correction), in ONE atomic DB call. The date rule is
 * applied server-side by the `recompute_due_dates` RPC (migrations/0008), which
 * MIRRORS computeDueDate above — so a 40-task re-date is a single round-trip
 * (~30ms) instead of one UPDATE per task (~8s on cloud Postgres). Only rows whose
 * date actually changed are written; returns that count.
 */
export async function recomputeDueDates(user: UserRow): Promise<number> {
  const updated = await taskRepo.recomputeDueDates(user.id, config.TZ);
  log.info({ userId: user.id, updated, moveDate: user.move_date }, 'due dates recomputed');
  return updated;
}
