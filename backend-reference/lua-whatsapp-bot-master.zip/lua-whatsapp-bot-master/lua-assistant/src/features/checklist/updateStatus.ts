import type { CompletedVia, TaskRow, TaskStatus } from '../../types/db.js';
import * as taskRepo from '../../repositories/task.repository.js';
import { isISODate } from '../../utils/date.js';
import { logger } from '../../utils/logger.js';

const log = logger.child({ feature: 'checklist/updateStatus' });

/**
 * The single shared task-status mutation, used by BOTH completion paths:
 *   - WhatsApp ("done"/"sorted") → via='whatsapp' (this file, resolveAndCompleteTask)
 *   - Web checkbox (Day 7)       → via='web'
 *
 * Scoped by userId in the repository, so neither path can touch another user's
 * task. Returns the updated row, or null when no such task exists for the user
 * (an invalid/hallucinated key, or someone else's task).
 */
export async function updateTaskStatus(
  userId: string,
  taskKey: string,
  status: TaskStatus,
  via: CompletedVia | null,
): Promise<TaskRow | null> {
  const updated = await taskRepo.updateStatus(userId, taskKey, status, via);
  if (!updated) {
    log.warn({ userId, taskKey, status }, 'task status update matched no row');
    return null;
  }
  log.info({ userId, taskKey, status, via }, 'task status updated');
  return updated;
}

/**
 * Web completion (task-list page): toggle a task by its id, scoped to the user
 * who owns the tasklist token. Same single source of truth as the WhatsApp path,
 * just keyed by id instead of task_key. Returns null if the task isn't theirs.
 */
export async function updateTaskStatusById(
  userId: string,
  taskId: string,
  status: TaskStatus,
): Promise<TaskRow | null> {
  const updated = await taskRepo.updateStatusById(userId, taskId, status, 'web');
  if (!updated) {
    log.warn({ userId, taskId, status }, 'web task update matched no row');
    return null;
  }
  log.info({ userId, taskId, status, via: 'web' }, 'task status updated');
  return updated;
}

/** Pending tasks, nearest deadline first — the order reminders + the prompt use. */
function pendingByDueDate(tasks: TaskRow[]): TaskRow[] {
  return tasks
    .filter((t) => t.status === 'pending')
    .sort((a, b) => (a.due_date ?? '9999').localeCompare(b.due_date ?? '9999'));
}

/** The "current" task a bare "done" refers to: the nearest-due pending task. */
export function activeTask(tasks: TaskRow[]): TaskRow | null {
  return pendingByDueDate(tasks)[0] ?? null;
}

export interface CompletionTarget {
  /** The task to mark done (backend-resolved, never blindly the model's guess). */
  target: TaskRow;
  /** The next pending task after this one (nearest due), for the confirmation. */
  next: TaskRow | null;
}

/**
 * PURE: pick which task a "done" completes — the core of "LLM proposes, backend
 * disposes". The model only detects intent (`taskCompleted`) and, IF the user
 * explicitly named a task, its key (`taskDoneKey`). The BACKEND chooses:
 *
 *   - an explicitly-named key that is still PENDING → that task;
 *   - otherwise (generic "done", or a stale/already-done/unknown key) → the
 *     ACTIVE task (nearest-due pending) — the one the reminder named.
 *
 * Returns null when there's no completion intent or nothing is left pending.
 */
export function selectCompletionTarget(
  tasks: TaskRow[],
  taskCompleted: boolean,
  taskDoneKey: string | null | undefined,
): CompletionTarget | null {
  if (!taskCompleted) return null;

  const pending = pendingByDueDate(tasks);
  if (pending.length === 0) return null; // nothing left to complete

  const key = taskDoneKey?.trim();
  const named = key ? pending.find((t) => t.task_key === key) : undefined;
  const target = named ?? pending[0]!; // explicit pending task, else active task
  const next = pending.find((t) => t.task_key !== target.task_key) ?? null;
  return { target, next };
}

export interface CompletionResult {
  /** The task actually marked done. */
  done: TaskRow;
  /** The next pending task after this one (nearest due), for the confirmation. */
  next: TaskRow | null;
}

/**
 * Resolve a WhatsApp "done" (via {@link selectCompletionTarget}) and persist it.
 * Fixes the model marking the wrong task (it once re-acked an already-done task,
 * and once completed a task the user never mentioned). Returns null when there's
 * no completion intent or nothing is left pending.
 */
export async function resolveAndCompleteTask(
  userId: string,
  tasks: TaskRow[],
  taskCompleted: boolean,
  taskDoneKey: string | null | undefined,
): Promise<CompletionResult | null> {
  const choice = selectCompletionTarget(tasks, taskCompleted, taskDoneKey);
  if (!choice) return null;

  const key = taskDoneKey?.trim();
  if (key && key !== choice.target.task_key) {
    log.info(
      { userId, proposedKey: key, resolvedKey: choice.target.task_key },
      'completion key not pending — resolved to active task instead',
    );
  }

  const done = await updateTaskStatus(userId, choice.target.task_key, 'completed', 'whatsapp');
  if (!done) return null;
  return { done, next: choice.next };
}

/**
 * Outcome of a per-task deadline change. The backend OWNS this — the model only
 * proposes the task_key + new date; we validate both before touching a single row.
 *   ok          → the task's due_date was updated to `newDueDate`.
 *   'past'      → a real date but before today → reject, ask again (no write).
 *   'unclear'   → not a parseable ISO date → reject, ask again (no write).
 *   'unknown'   → no PENDING task matches the key → no write; leave the model's
 *                 own reply to handle it (don't override with a false confirmation).
 *   null        → no reschedule intent this turn (nothing to do).
 */
export type RescheduleResult =
  | { ok: true; task: TaskRow; newDueDate: string }
  | { ok: false; reason: 'past' | 'unclear' | 'unknown'; task: TaskRow | null };

/**
 * Reschedule ONE task's deadline. Mirrors resolveAndCompleteTask: the model names
 * the task (exact task_key) and the new date; the backend validates the key against
 * the user's OWN pending tasks and the date (must parse + not be in the past), then
 * updates only that task's due_date. Never touches move_date or any other task —
 * fixes the bug where "change the deadline for task X" shifted the whole moving plan.
 */
export async function resolveAndRescheduleTask(
  userId: string,
  tasks: TaskRow[],
  taskKey: string | null | undefined,
  newDueDate: string | null | undefined,
  todayISO: string,
): Promise<RescheduleResult | null> {
  const key = taskKey?.trim();
  const date = newDueDate?.trim();
  if (!key || !date) return null; // no reschedule intent this turn

  const target = tasks.find((t) => t.task_key === key && t.status === 'pending');
  if (!target) {
    log.warn({ userId, taskKey: key }, 'reschedule: no pending task matched key');
    return { ok: false, reason: 'unknown', task: null };
  }
  if (!isISODate(date)) return { ok: false, reason: 'unclear', task: target };
  // ISO yyyy-mm-dd strings compare lexicographically — same as chronologically.
  if (date < todayISO) return { ok: false, reason: 'past', task: target };

  await taskRepo.updateDueDate(target.id, date);
  log.info({ userId, taskKey: key, newDueDate: date }, 'task deadline rescheduled');
  return { ok: true, task: target, newDueDate: date };
}
