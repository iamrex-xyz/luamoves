import { config } from '../../config/index.js';
import type { UserRow } from '../../types/db.js';
import { normalizeLanguageCode } from '../../utils/language.js';

/** The session-language change to apply this turn (null when nothing changed). */
export interface SessionLanguageUpdate {
  /** New session language (ISO 639-1) — what to reply in / fall back to. */
  language: string;
  /** Single-element lock marker `[language]` (a non-empty array means "locked"). */
  recent_languages: string[];
  /** True when the visible reply language actually changed (worth logging). */
  switched: boolean;
}

/**
 * Decide the session language AFTER each turn — "detect once, then LOCK; never
 * drift" (client requirement). A PURE function: it computes the change but does
 * NOT touch the DB, so the caller can apply it in memory immediately and persist
 * it off the reply's critical path (the stored value only matters for the NEXT
 * turn + reminders, never for the reply being sent now).
 *
 * `recent_languages` is now a one-element LOCK MARKER, not a rolling window:
 * empty = not yet locked; `[code]` = locked to that language. The model reports
 * two things about the CURRENT message:
 *   - detected:  the language the user actually wrote in this turn;
 *   - requested: a non-null code ONLY when the user EXPLICITLY asks to switch
 *                ("reply in English").
 *
 * Rules, in order:
 *   1. Explicit request → ALWAYS honour it (even from a locked session) and
 *      re-lock to the requested language.
 *   2. Already locked (recent non-empty) → return null. Detection can NEVER drift
 *      an established session; a stray English name/address won't flip the reply.
 *   3. Not yet locked → lock to the detected language. In practice the welcome
 *      step seeds the lock from the user's first message, so this branch is a
 *      safety net for rows that predate that seeding.
 *
 * Returns null when nothing should change (forced override, locked session, or an
 * ambiguous unlocked turn with no detectable language).
 */
export function decideSessionLanguage(
  user: UserRow,
  detected: string | null | undefined,
  requested: string | null | undefined,
): SessionLanguageUpdate | null {
  if (config.REPLY_LANGUAGE) return null;

  // Tolerate a row written before the language columns existed (→ undefined).
  const locked = (user.recent_languages ?? []).length > 0;

  const reqCode = normalizeLanguageCode(requested);
  if (reqCode) {
    // Explicit "switch to X": always honour it and re-lock to it. No-op only when
    // it matches the language we're already locked to.
    if (reqCode === user.language && locked) return null;
    return { language: reqCode, recent_languages: [reqCode], switched: reqCode !== user.language };
  }

  // Locked → never drift from per-message detection.
  if (locked) return null;

  // Not yet locked: establish the lock from this first detection.
  const detCode = normalizeLanguageCode(detected);
  if (!detCode) return null; // ambiguous turn — stay unlocked, try again next turn

  return { language: detCode, recent_languages: [detCode], switched: detCode !== user.language };
}
