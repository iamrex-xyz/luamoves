import { Worker, type Job } from 'bullmq';
import { config } from '../../config/index.js';
import { sendText, sendTemplate } from '../../services/bird.service.js';
import { renderDailyUpdate } from '../../templates/reminder.js';
import { buildTasklistUrl } from '../../utils/url.js';
import { todayInTz } from '../../utils/date.js';
import { logger } from '../../utils/logger.js';
import * as userRepo from '../../repositories/user.repository.js';
import * as taskRepo from '../../repositories/task.repository.js';
import * as sessionRepo from '../../repositories/session.repository.js';
import * as reminderRepo from '../../repositories/reminder.repository.js';
import * as messages from '../../repositories/message.repository.js';
import { runScan } from './scheduler.js';
import { connection, DAILY_KEY, REMINDER_QUEUE, SCAN_JOB, SEND_JOB, type SendJobData } from './queue.js';

const log = logger.child({ feature: 'reminders/worker' });

/** True if the user has been active within the WhatsApp 24h session window. */
function withinSessionWindow(lastActivityAt: string | undefined): boolean {
  if (!lastActivityAt) return false;
  const elapsedMs = Date.now() - Date.parse(lastActivityAt);
  return elapsedMs <= config.SESSION_WINDOW_HOURS * 3_600_000;
}

/**
 * Send one user's daily reminder, applying every guard (plan.md §12):
 *   opt-out → skip · task no longer pending → skip · already sent today → skip ·
 *   inside 24h window → normal text, outside → approved template.
 */
export async function processSend(data: SendJobData): Promise<void> {
  const user = await userRepo.getById(data.userId);
  if (!user) return;
  if (user.reminders_opt_out) {
    log.info({ userId: user.id }, 'reminder skipped — user opted out');
    return;
  }

  // Re-check the task is still pending (the user may have completed it meanwhile).
  const task = await taskRepo.getByUserAndKey(user.id, data.taskKey);
  if (!task || task.status !== 'pending') {
    log.info({ userId: user.id, taskKey: data.taskKey }, 'reminder skipped — task not pending');
    return;
  }

  const today = todayInTz(config.TZ);
  const testMode = config.REMINDER_TEST_MODE;

  // Max-1/day guard, fast path: if we already sent today, stop. Skipped in test
  // mode so the reminder re-fires on every scan.
  const last = await reminderRepo.getLast(user.id, DAILY_KEY);
  if (!testMode && last) {
    const lastDay = new Intl.DateTimeFormat('en-CA', { timeZone: config.TZ }).format(
      new Date(last.last_reminder_at),
    );
    if (lastDay === today) {
      log.info({ userId: user.id }, 'reminder skipped — already sent today');
      return;
    }
  }

  const session = await sessionRepo.get(user.id);
  const inWindow = withinSessionWindow(session?.last_activity_at);
  // Template path is used out-of-window, and is FORCED in test mode so the
  // approved template itself is exercised (works in-window too).
  const useTemplate = !inWindow || testMode;

  // The template path needs an approved template configured. Bail BEFORE claiming
  // so a future day (once a template exists) can still retry.
  if (useTemplate && !config.WHATSAPP_TEMPLATE_PROJECT_ID) {
    log.warn({ userId: user.id }, 'reminder not sent — template path but no template configured');
    return;
  }

  // ATOMICALLY claim today's slot BEFORE sending. Only one caller wins, so
  // overlapping scans or a BullMQ retry after a partial failure can't resend the
  // same reminder (the prod bug: the same reminder went out 2–3× because the old
  // check-then-send left a race window). A retry after this point sees the slot
  // taken and no-ops — we trade a rare lost reminder for never spamming. Skipped
  // in test mode (the whole point is to re-fire).
  if (!testMode) {
    const claimed = await reminderRepo.claimDaily(user.id, DAILY_KEY, last?.last_reminder_at ?? null);
    if (!claimed) {
      log.info({ userId: user.id }, 'reminder skipped — daily slot already claimed (race)');
      return;
    }
  }

  // `content` is what we store in message history; it must match what was sent.
  // Both paths use the same daily-update copy so the reminder reads identically
  // in- and out-of-window: in-window we send it as free text, out-of-window via
  // the approved Bird template (which mirrors the same wording).
  let content: string;
  let providerMessageId: string | null;
  const checklistUrl = buildTasklistUrl(user.tasklist_token);
  if (!useTemplate) {
    content = renderDailyUpdate(user.name ?? '', task.title, checklistUrl, user.language);
    providerMessageId = await sendText(user.phone, content);
  } else {
    // Outside 24h → approved template with named placeholders (name/task/
    // checklist_url). Skips (returns null) if no template configured.
    content = renderDailyUpdate(user.name ?? '', task.title, checklistUrl, user.language);
    providerMessageId = await sendTemplate(
      user.phone,
      [
        { key: 'name', value: user.name ?? '' },
        { key: 'task', value: task.title },
        { key: 'checklist_url', value: checklistUrl },
      ],
      user.language,
    );
    if (providerMessageId === null) {
      log.warn({ userId: user.id }, 'reminder not sent — template send returned null');
      return;
    }
  }

  await messages.insert({
    userId: user.id,
    role: 'assistant',
    content,
    messageId: providerMessageId,
    status: 'accepted',
  });
  log.info(
    { userId: user.id, taskKey: task.task_key, inWindow, useTemplate, testMode, providerMessageId },
    'reminder sent',
  );
}

/** Start the BullMQ worker that processes scan + send jobs. */
export function startReminderWorker(): Worker {
  const worker = new Worker(
    REMINDER_QUEUE,
    async (job: Job) => {
      if (job.name === SCAN_JOB) return runScan();
      if (job.name === SEND_JOB) return processSend(job.data as SendJobData);
      log.warn({ name: job.name }, 'unknown reminder job — ignored');
    },
    { connection },
  );

  worker.on('failed', (job, err) =>
    log.error({ jobId: job?.id, name: job?.name, attempts: job?.attemptsMade, err }, 'reminder job failed'),
  );
  worker.on('completed', (job) => log.debug({ jobId: job.id, name: job.name }, 'reminder job completed'));
  return worker;
}
