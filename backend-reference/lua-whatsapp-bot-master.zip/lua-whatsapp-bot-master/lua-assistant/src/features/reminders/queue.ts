import { Queue } from 'bullmq';
import { Redis } from 'ioredis';
import { config } from '../../config/index.js';

/**
 * BullMQ reminder queue (plan.md §12). Redis is used ONLY by this subsystem — the
 * webhook path runs without it. A shared ioredis connection is reused by the queue
 * and the worker; `maxRetriesPerRequest: null` is required by BullMQ blocking ops.
 */
export const REMINDER_QUEUE = 'reminders';

/** Job names on the queue. */
export const SCAN_JOB = 'scan';
export const SEND_JOB = 'send';

/** Fixed reminder_log key for the daily proactive reminder. */
export const DAILY_KEY = 'daily';

export interface SendJobData {
  userId: string;
  taskKey: string;
  title: string;
  dueDate: string | null;
}

export const connection = new Redis(config.REDIS_URL, { maxRetriesPerRequest: null });

export const reminderQueue = new Queue(REMINDER_QUEUE, { connection });
