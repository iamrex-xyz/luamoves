/**
 * "stop" detection (flow.md §Push notifications): if the user says stop / no more
 * messages, halt reminders immediately — no persuasion, no follow-up question.
 * Backed by a keyword pre-filter (here) plus the model's stop_reminders signal.
 */
const STOP_PHRASES = [
  'no more messages', 'stop messages', 'stop sending', 'stop reminders', 'unsubscribe',
  'geen berichten meer', 'geen herinneringen', 'stop met berichten', 'hou op met berichten',
  'stuur geen berichten', 'afmelden',
];

/** True if the message is a clear opt-out (standalone "stop" or a stop phrase). */
export function stopRequested(text: string): boolean {
  const t = text.trim().toLowerCase();
  if (t === 'stop' || t === 'stop.' || t === 'stop!') return true;
  return STOP_PHRASES.some((p) => t.includes(p));
}
