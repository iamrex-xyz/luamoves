import { config } from '../../config/index.js';
import { todayInTz } from '../../utils/date.js';
import { logger } from '../../utils/logger.js';
import * as reminderRepo from '../../repositories/reminder.repository.js';
import { reminderQueue, SCAN_JOB, SEND_JOB, type SendJobData } from './queue.js';

const log = logger.child({ feature: 'reminders/scheduler' });

/**
 * Register the daily repeatable scan (plan.md §12). Cron + timezone come from
 * config (default 08:00 Europe/Amsterdam). BullMQ dedupes identical repeat
 * options, so calling this on every boot is safe (no duplicate schedulers).
 */
export async function registerDailyScan(): Promise<void> {
  // Clear any previously-registered repeatable scans before adding the current
  // one, so a stale pattern from an earlier boot (e.g. a fast test cron, or the
  // 08:00 prod schedule) never lingers in Redis alongside the active cron. Safe
  // for a single worker; the add below re-registers the current REMINDER_CRON.
  for (const job of await reminderQueue.getRepeatableJobs()) {
    await reminderQueue.removeRepeatableByKey(job.key);
  }
  if (config.REMINDER_TEST_MODE) {
    log.warn(
      { cron: config.REMINDER_CRON, phone: config.REMINDER_TEST_PHONE ?? '<all users>' },
      'REMINDER_TEST_MODE on — fast cron, once-per-day guards bypassed, template forced',
    );
  }

  await reminderQueue.add(
    SCAN_JOB,
    {},
    {
      repeat: { pattern: config.REMINDER_CRON, tz: config.TZ },
      removeOnComplete: true,
      removeOnFail: 50,
    },
  );
  log.info({ cron: config.REMINDER_CRON, tz: config.TZ }, 'daily reminder scan registered');
}

/** Enqueue a scan immediately (manual trigger for testing). */
export async function enqueueScanNow(): Promise<void> {
  await reminderQueue.add(SCAN_JOB, {}, { removeOnComplete: true, removeOnFail: 50 });
}

/**
 * The scan body: find every active user with a pending task and enqueue ONE
 * send-job per user for their NEXT pending task (nearest due_date). No due-date
 * window — the reminder follows the user's checklist. The deterministic jobId
 * `reminder:<userId>:<date>` makes the enqueue idempotent → max one reminder/day
 * even across restarts or overlap. Test mode can scope the scan to a single phone.
 */
export async function runScan(): Promise<number> {
  const today = todayInTz(config.TZ);

  const candidates = await reminderRepo.findNextPendingCandidates(
    config.REMINDER_TEST_MODE ? config.REMINDER_TEST_PHONE : undefined,
  );

  let enqueued = 0;
  for (const { user, task } of candidates) {
    const data: SendJobData = {
      userId: user.id,
      taskKey: task.task_key,
      title: task.title,
      dueDate: task.due_date,
    };
    await reminderQueue.add(SEND_JOB, data, {
      // Test mode: a unique jobId per scan so every scan fires (no daily dedupe).
      // Prod: deterministic jobId `reminder:<user>:<date>` → max one reminder/day.
      jobId: config.REMINDER_TEST_MODE
        ? `reminder-test:${user.id}:${Date.now()}`
        : `reminder:${user.id}:${today}`,
      attempts: 4,
      backoff: { type: 'exponential', delay: 60_000 },
      removeOnComplete: true,
      removeOnFail: false,
    });
    enqueued += 1;
  }
  log.info(
    { candidates: candidates.length, enqueued, testMode: config.REMINDER_TEST_MODE },
    'reminder scan complete',
  );
  return enqueued;
}
