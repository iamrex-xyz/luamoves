/**
 * Crisis pre-filter (plan.md §14, instructions.md §Crisis protocol).
 *
 * Layer 1 of 2: a fast keyword scan that runs BEFORE the LLM, so an obvious
 * crisis disclosure is met with the exact canned message without spending (or
 * risking) a model call. Layer 2 is signals.crisis from the model, which catches
 * phrasings the keywords miss — handled in the orchestrator.
 *
 * Intentionally high-recall: false positives just send a supportive, safe message
 * and pause; the cost of a miss is far higher. en + nl phrases.
 */
const CRISIS_PHRASES: string[] = [
  // self-harm / suicide (en)
  'suicide', 'suicidal', 'kill myself', 'killing myself', 'end my life', 'ending my life',
  'want to die', 'wanna die', 'better off dead', 'self-harm', 'self harm', 'hurt myself',
  'harm myself', 'cut myself',
  // self-harm / suicide (nl)
  'zelfmoord', 'zelfdoding', 'mezelf van het leven', 'uit het leven stappen',
  'maak er een eind aan', 'er een eind aan maken', 'wil dood', 'niet meer leven',
  'mezelf pijn doen', 'mezelf iets aandoen',
  // domestic violence / abuse (en)
  'domestic violence', 'being abused', 'he hits me', 'she hits me', 'they hit me',
  'beats me', 'afraid to go home', 'scared to go home', 'not safe at home', "i'm not safe",
  // domestic violence / abuse (nl)
  'huiselijk geweld', 'mishandeld', 'mishandeling', 'hij slaat me', 'ze slaat me',
  'word geslagen', 'word mishandeld', 'niet veilig thuis', 'bang om naar huis',
  // acute homelessness (en/nl)
  'nowhere to sleep', 'nowhere to go', 'sleeping on the street', 'i am homeless',
  "i'm homeless", 'made homeless', 'dakloos', 'op straat slapen', 'geen dak boven',
];

/** True if the inbound text matches any crisis phrase (case-insensitive). */
export function crisisKeywordHit(text: string): boolean {
  const t = text.toLowerCase();
  return CRISIS_PHRASES.some((p) => t.includes(p));
}

/**
 * Directive injected while the flow is crisis-paused (users.safety_paused_at set).
 * The model replies supportively and does NOT push moving questions; it sets
 * signals.safety.resume_ok ONLY when the user clearly wants to continue. The
 * backend owns the actual resume (clears the pause), per instructions.md.
 */
export function buildCrisisPauseDirective(): string {
  return [
    '[CRISIS — gepauzeerd]',
    'Het gesprek staat op pauze na een crisissignaal. Reageer rustig en steunend.',
    'Stel GEEN verhuisvragen en ga niet door met de checklist totdat de gebruiker dat zelf vraagt.',
    'Zet signals.safety.resume_ok ALLEEN op true als de gebruiker expliciet aangeeft door te willen',
    'met de verhuizing. Anders false.',
    '[/CRISIS]',
  ].join('\n');
}
