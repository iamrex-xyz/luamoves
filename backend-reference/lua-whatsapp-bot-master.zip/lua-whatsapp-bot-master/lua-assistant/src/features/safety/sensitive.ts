/**
 * Sensitive-data scan + redaction (plan.md §14, instructions.md §Scope).
 *
 * Lua must never request, store, or echo sensitive data (BSN, bank/IBAN, card
 * numbers, passwords/PINs). We scan the RAW inbound BEFORE it is persisted and
 * replace any detected value with a placeholder, so the secret is never written
 * to the DB or fed back into the model. The orchestrator then short-circuits with
 * a fixed "please don't share" reply (no LLM call → no echo).
 *
 * Tuned to detect actual VALUES the user sent (not bare mentions), so normal
 * conversation isn't disrupted: BSN via the elfproef checksum, cards via Luhn,
 * IBANs by shape, and secrets that follow a password/PIN keyword.
 */
const REDACTED = '[gevoelige gegevens verwijderd]';

/** Dutch BSN 11-check (elfproef): weights 9..2 then -1, sum % 11 === 0. */
export function isValidBsn(digits: string): boolean {
  if (!/^\d{9}$/.test(digits)) return false;
  const weights = [9, 8, 7, 6, 5, 4, 3, 2, -1];
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += Number(digits[i]) * weights[i]!;
  return sum % 11 === 0;
}

/** Luhn check for card-like numbers (reduces false positives on digit runs). */
export function passesLuhn(digits: string): boolean {
  let sum = 0;
  let dbl = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (dbl) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    dbl = !dbl;
  }
  return sum % 10 === 0;
}

export interface SensitiveScan {
  /** True if any sensitive value was detected (and redacted). */
  hit: boolean;
  /** The inbound text with detected values replaced by a placeholder. */
  redacted: string;
}

/**
 * Scan + redact in one pass. Order matters: longer/structured patterns (IBAN,
 * card) before bare digit runs (BSN), so we don't half-redact a larger token.
 */
export function scanSensitive(text: string): SensitiveScan {
  let hit = false;
  const mark = (): string => {
    hit = true;
    return REDACTED;
  };
  let out = text;

  // IBAN: 2 country letters + 2 check digits + 11–30 alphanumerics.
  out = out.replace(/\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b/gi, mark);

  // Card-like: 13–19 digits, optionally grouped by spaces/dashes; Luhn-validated.
  out = out.replace(/\b(?:\d[ -]?){12,18}\d\b/g, (m) => {
    const digits = m.replace(/\D/g, '');
    return digits.length >= 13 && digits.length <= 19 && passesLuhn(digits) ? mark() : m;
  });

  // BSN: a standalone 9-digit number passing the elfproef.
  out = out.replace(/\b\d{9}\b/g, (m) => (isValidBsn(m) ? mark() : m));

  // Secret following a password/PIN keyword, allowing one filler ("is"/":"/"=").
  // Only fires when the value contains a digit, so "my pin is important" — no
  // digit — isn't treated as a leak.
  out = out.replace(
    /\b(wachtwoord|password|pincode|pin\s?code|pin|cvv|cvc)\b[^\S\n]*(?:is|=|:|->)?[^\S\n]*([^\s]*\d[^\s]*)/gi,
    (_m, kw: string) => `${kw}: ${mark()}`,
  );

  return { hit, redacted: out };
}
