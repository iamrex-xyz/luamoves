/**
 * Jailbreak pre-filter (instructions.md §Jailbreak / manipulation).
 *
 * A light keyword net for the classic injection openers. Primary detection is
 * signals.jailbreak from the model (the orchestrator overrides the reply with the
 * fixed deflection on either). Lower-stakes than crisis, so this stays narrow to
 * avoid deflecting legitimate messages. en + nl.
 */
const JAILBREAK_PHRASES: string[] = [
  'ignore previous instructions', 'ignore all previous', 'ignore your instructions',
  'disregard previous', 'disregard your instructions', 'forget your instructions',
  'forget previous instructions', 'you are now', 'pretend you are', 'pretend to be',
  'act as', 'act like you are', 'system prompt', 'developer mode', 'jailbreak',
  'roleplay as', 'from now on you are',
  // nl
  'negeer vorige instructies', 'negeer alle vorige', 'negeer je instructies',
  'vergeet je instructies', 'vergeet vorige instructies', 'je bent nu',
  'doe alsof je', 'gedraag je als', 'systeemprompt', 'ontwikkelaarsmodus',
];

export function jailbreakKeywordHit(text: string): boolean {
  const t = text.toLowerCase();
  return JAILBREAK_PHRASES.some((p) => t.includes(p));
}
