/**
 * Crisis message — the EXACT text from instructions.md (§Crisis protocol),
 * code-rendered so it can never vary or be reshaped by the model (plan.md §2/§14).
 * Already final plain text (markdown bold dropped for WhatsApp); do NOT run it
 * through the plain-text formatter. English here matches the current English spec
 * files; swap when the client delivers the Dutch wording.
 */
export const CRISIS_MESSAGE = `I hear that things are hard right now. I'm a moving assistant and not the right support for this, but there are people who can help:

113 Suicide Prevention — call 113 or 0800-0113 (free, 24/7)
Veilig Thuis (domestic violence) — 0800-2000

Would you like me to pause the moving questions for now?`;

export function renderCrisis(): string {
  return CRISIS_MESSAGE;
}
