import type { TaskRow } from '../types/db.js';
import { normalizeLanguageCode } from '../utils/language.js';

/**
 * Proactive reminder copy — code-rendered (deterministic, no LLM call in the
 * worker). Mirrors the flow.md proactive style ("In 4 days you need to …").
 *
 * Localised to the user's stored session language (users.language). We ship the
 * two languages the spec covers — Dutch and English — and fall back to English
 * for any other code. (The out-of-window WhatsApp template is a separate,
 * provider-approved asset and isn't localised here.)
 */

/** Supported reminder languages; everything else falls back to 'en'. */
type ReminderLang = 'nl' | 'en';
function pickLang(language: string | null | undefined): ReminderLang {
  return normalizeLanguageCode(language) === 'nl' ? 'nl' : 'en';
}

/** Whole days from `fromISO` (a yyyy-mm-dd date) until `dueISO`, in UTC. */
export function daysUntil(dueISO: string, fromISO: string): number {
  const due = Date.parse(`${dueISO}T00:00:00Z`);
  const from = Date.parse(`${fromISO}T00:00:00Z`);
  return Math.round((due - from) / 86_400_000);
}

/**
 * Fixed acknowledgement when the user opts out ("stop"). No persuasion, no
 * follow-up question (flow.md §Push notifications). Code-rendered, final text.
 */
export function renderStopAck(language?: string | null): string {
  if (pickLang(language) === 'nl') {
    return 'Oké, ik stuur je geen herinneringen meer. Je kunt me altijd een bericht sturen als je hulp nodig hebt bij je verhuizing.';
  }
  return "Okay, I won't send you any more reminders. You can still message me anytime if you need help with your move.";
}

/** Lead-time phrase ("In 4 days" / "Over 4 dagen"), per language. */
function leadTime(days: number | null, lang: ReminderLang): string {
  if (lang === 'nl') {
    return days === null
      ? 'Binnenkort'
      : days <= 0
        ? 'Nu'
        : days === 1
          ? 'Morgen'
          : `Over ${days} dagen`;
  }
  return days === null ? 'Coming up' : days <= 0 ? 'Due now' : days === 1 ? 'Tomorrow' : `In ${days} days`;
}

/**
 * Plain-text mirror of the approved Bird daily-update templates
 * (`lua_daily_update_en` / `lua_daily_update_nl`), used for the out-of-window
 * daily reminder. Bird substitutes the placeholders on its side (we only pass the
 * values); we render the same copy here so our message history reflects what the
 * user actually received. Bird remains the source of truth for the wording — keep
 * this in sync if the client edits a template.
 */
export function renderDailyUpdate(
  name: string,
  task: string,
  checklistUrl: string,
  language?: string | null,
): string {
  if (pickLang(language) === 'nl') {
    return `Goedemorgen ${name}! Ik wil je graag een update geven over de status van je verhuizing.

Vandaag op je to do lijst: ${task}.

Je kunt je takenlijst hier vinden: ${checklistUrl}

stuur gerust een bericht als je hulp nodig hebt.`;
  }
  return `Good morning ${name}! I'd like to give you an update on the status of your move.

Today on your to-do list: ${task}.

You can find your task list here: ${checklistUrl}

Feel free to send a message if you need any help.`;
}

export function renderReminder(task: TaskRow, todayISO: string, language?: string | null): string {
  const lang = pickLang(language);
  const days = task.due_date ? daysUntil(task.due_date, todayISO) : null;
  const when = leadTime(days, lang);
  if (lang === 'nl') {
    return `${when}: ${task.title}.\n\nAntwoord "klaar" als het gelukt is, of stel me een vraag. Antwoord "stop" om deze herinneringen te pauzeren.`;
  }
  return `${when}: ${task.title}.\n\nReply "done" once it's sorted, or ask me anything. Reply "stop" to pause these reminders.`;
}
