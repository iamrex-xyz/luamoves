import { normalizeLanguageCode } from '../utils/language.js';

/**
 * Task-completion confirmation — code-rendered so the task we name is ALWAYS the
 * task the backend actually marked done (the model's free text used to drift,
 * confirming a different task than was completed). Localised NL/EN; Dutch default.
 * Names the next pending task (nearest due) when there is one, per the Flow's
 * "confirm + suggest the logical next step" style.
 */
export function renderTaskDone(
  doneTitle: string,
  nextTitle: string | null,
  language?: string | null,
): string {
  if (normalizeLanguageCode(language) === 'en') {
    const base = `Done — I've checked off "${doneTitle}". ✅`;
    return nextTitle
      ? `${base}\n\nNext up: "${nextTitle}". Let me know if you'd like help with it.`
      : `${base}\n\nThat was your last open task — nicely done!`;
  }
  const base = `Top — ik heb "${doneTitle}" afgevinkt. ✅`;
  return nextTitle
    ? `${base}\n\nVolgende stap: "${nextTitle}". Laat het weten als je hier hulp bij wilt.`
    : `${base}\n\nDat was je laatste openstaande taak — goed bezig!`;
}

/**
 * Per-task deadline-change confirmation — code-rendered (like renderTaskDone) so
 * the task we name and the date we confirm are exactly what the backend wrote, and
 * ONLY that one task changed (never the moving date). Localised NL/EN; Dutch default.
 */
export function renderTaskRescheduled(
  title: string,
  newDueDate: string,
  language?: string | null,
): string {
  if (normalizeLanguageCode(language) === 'en') {
    return `Done — I've moved the deadline for "${title}" to ${newDueDate}. ✅\n\nNothing else changed.`;
  }
  return `Top — ik heb de deadline van "${title}" verzet naar ${newDueDate}. ✅\n\nVerder is er niets gewijzigd.`;
}

/**
 * Rejected deadline change (date in the past or unparseable). Deterministic, so the
 * user gets a clear re-ask instead of a model reply that "confirms" a change that
 * didn't happen. Localised NL/EN; Dutch default.
 */
export function renderTaskRescheduleRejected(
  title: string,
  reason: 'past' | 'unclear',
  todayISO: string,
  language?: string | null,
): string {
  if (normalizeLanguageCode(language) === 'en') {
    return reason === 'past'
      ? `That date has already passed — today is ${todayISO}. What new deadline would you like for "${title}"?`
      : `I didn't catch a clear date for "${title}". What deadline would you like (e.g. 2026-08-02)?`;
  }
  return reason === 'past'
    ? `Die datum is al geweest — vandaag is ${todayISO}. Welke nieuwe deadline wil je voor "${title}"?`
    : `Ik begreep geen duidelijke datum voor "${title}". Welke deadline wil je (bijv. 2026-08-02)?`;
}
