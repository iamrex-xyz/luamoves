import { normalizeLanguageCode } from '../utils/language.js';

/**
 * Code-rendered "that date has already passed" reply (flow.md §Date in the past).
 * The past/future judgment is made deterministically in the backend (the LLM got
 * it wrong: "August 23rd has already passed" while today was June 16, both 2026),
 * so this exact wording — not the model's prose — is what the user sees. Localised
 * to the user's session language (Dutch + English, English fallback).
 */
export function renderDateInPast(
  pastDateISO: string,
  todayISO: string,
  language?: string | null,
): string {
  if (normalizeLanguageCode(language) === 'nl') {
    return `Die datum (${pastDateISO}) is al geweest — vandaag is ${todayISO}. Op welke datum ga je verhuizen?`;
  }
  return `That date (${pastDateISO}) has already passed — today is ${todayISO}. What date are you moving?`;
}
