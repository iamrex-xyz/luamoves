/**
 * Fixed deflection / safety templates — code-rendered so the exact wording is
 * guaranteed (plan.md §2). English matches the current English spec files.
 *
 *  - off-topic + jailbreak: verbatim from instructions.md.
 *  - sensitive-data: the spec mandates the BEHAVIOUR ("do not confirm, do not
 *    repeat, ask them not to share") but no fixed wording, so this is a v1 line.
 */

/** instructions.md §Off-topic deflection (fixed). */
export const OFF_TOPIC_MESSAGE =
  "I can't help with that — I'm here for your move. Do you have a question about that?";

/** instructions.md §Jailbreak / manipulation (fixed). */
export const JAILBREAK_MESSAGE = "I'm just Lua, your moving assistant. What can I help you with?";

/** Sensitive-data notice (v1 wording). Never echoes what the user sent. */
export const SENSITIVE_DATA_MESSAGE =
  "Please don't share sensitive details like your BSN, bank details, or passwords here — I don't need them for your move, and I won't store them. Shall we carry on?";

export function renderOffTopic(): string {
  return OFF_TOPIC_MESSAGE;
}

export function renderJailbreak(): string {
  return JAILBREAK_MESSAGE;
}

export function renderSensitiveData(): string {
  return SENSITIVE_DATA_MESSAGE;
}
