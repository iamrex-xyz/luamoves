import type { UserRow } from '../types/db.js';
import { buildTasklistUrl } from '../utils/url.js';
import { normalizeLanguageCode } from '../utils/language.js';

/**
 * Onboarding summary — client-approved copy, localised to the user's session
 * language (NL + EN; Dutch-first default). Code-rendered from columns, never
 * LLM-generated, so it's NOT covered by the model's single-language guarantee —
 * hence we localise it explicitly here. Already final: do NOT run it through the
 * plain-text formatter.
 */
export function renderSummary(user: UserRow): string {
  const url = buildTasklistUrl(user.tasklist_token);
  const name = user.name ?? '';
  const date = user.move_date ?? '';
  const from = user.from_address ?? '';
  const home = user.home_type ?? '';
  const household = renderHousehold(user.household);

  // Dutch is the default; only switch to English when the session language is en.
  if (normalizeLanguageCode(user.language) !== 'en') {
    const type = user.move_type === 'buy' ? 'koop' : user.move_type === 'rent' ? 'huur' : '';
    const to = user.to_address ?? 'onbekend';
    return `Oké, ik weet voorlopig genoeg om je te helpen!

Je verhuizing in het kort:
Naam: ${name}
Verhuisdatum: ${date}
Type: ${type}
Van: ${from}
Naar: ${to}
Woningtype: ${home}
Huishouden: ${household}

Je gepersonaliseerde takenlijst staat klaar: ${url}

Ik stuur je elke dag een kort overzicht van wat er die week speelt.

Heb je nu nog vragen?`;
  }

  const type = user.move_type === 'buy' ? 'Purchase' : user.move_type === 'rent' ? 'Rental' : '';
  const to = user.to_address ?? 'unknown';
  return `Okay, I know enough for now to help you!

Your move at a glance:
Name: ${name}
Moving date: ${date}
Type: ${type}
From: ${from}
To: ${to}
Home type: ${home}
Household: ${household}

Your personalized checklist is ready: ${url}

I'll send you a short daily overview of what's coming up that week.

Any questions right now?`;
}

function renderHousehold(household: UserRow['household']): string {
  if (!household) return '';
  if (typeof household === 'object' && 'description' in household) {
    return String((household as { description: unknown }).description ?? '');
  }
  return '';
}
