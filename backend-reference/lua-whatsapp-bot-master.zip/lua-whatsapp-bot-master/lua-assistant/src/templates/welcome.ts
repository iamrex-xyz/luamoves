import { normalizeLanguageCode } from '../utils/language.js';

/**
 * First-contact welcome — client-approved EXACT copy (NL + EN). Sent on the very
 * first message with NO LLM call, so the first reply is instant and always
 * identical. Delivered as THREE separate WhatsApp messages (client request, for
 * readability); the last one asks for the name (onboarding step 1). Language is
 * the fast heuristic guess; the next message adapts.
 */
const WELCOME_NL: readonly string[] = [
  'Hi! Wat leuk dat je gaat verhuizen! Ik ben Lua, je slimme verhuisassistent. ' +
    'Ik ga je helpen met het regelen van alles wat komt kijken bij je verhuizing.',
  'Als je me wat gegevens deelt, dan kan ik starten met het maken van een ' +
    'gepersonaliseerde takenlijst voor jouw situatie.',
  'Verder zal ik je dagelijks op de hoogte houden van de openstaande taken, ' +
    'zodat we samen niks vergeten. Laten we beginnen! Wat is je naam?',
];

const WELCOME_EN: readonly string[] = [
  "Hi! How exciting that you're moving! I'm Lua, your smart moving assistant. " +
    "I'll help you arrange everything involved in your move.",
  'If you share some details with me, I can start creating a personalized ' +
    'checklist for your situation.',
  "I'll also keep you updated daily on your outstanding tasks, so together we " +
    "don't forget anything. Let's get started! What's your name?",
];

/** The welcome as an ordered list of messages, one per WhatsApp bubble. */
export function renderWelcome(language?: string | null): readonly string[] {
  return normalizeLanguageCode(language) === 'en' ? WELCOME_EN : WELCOME_NL;
}
