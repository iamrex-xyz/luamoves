import { config } from './config/index.js';
import { logger } from './utils/logger.js';
import { installHttpAgent } from './utils/httpAgent.js';
import { connection } from './features/reminders/queue.js';
import { registerDailyScan } from './features/reminders/scheduler.js';
import { startReminderWorker } from './features/reminders/worker.js';

/**
 * Reminder worker process (plan.md §12/§17). Runs separately from the webhook API
 * (its own container), sharing the codebase. Registers the daily repeatable scan
 * and processes scan + send jobs off the BullMQ queue.
 */
async function main(): Promise<void> {
  // Warm, reusable connections for outbound calls (Bird/Supabase) from the worker.
  installHttpAgent();

  logger.info({ tz: config.TZ, cron: config.REMINDER_CRON, redis: config.REDIS_URL }, 'reminder worker starting');

  await registerDailyScan();
  const worker = startReminderWorker();

  const shutdown = async (signal: string): Promise<void> => {
    logger.info({ signal }, 'reminder worker shutting down');
    await worker.close();
    await connection.quit();
    process.exit(0);
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

main().catch((err) => {
  logger.error({ err }, 'reminder worker failed to start');
  process.exit(1);
});
