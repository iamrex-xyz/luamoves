import { createOpenRouter } from '@openrouter/ai-sdk-provider';
import { generateObject, generateText, type ModelMessage } from 'ai';
import type { z } from 'zod';
import { config } from '../config/index.js';
import { logger } from '../utils/logger.js';
import { msSince, noteSpan } from '../utils/timing.js';

const log = logger.child({ svc: 'llm' });

/**
 * Thin LLM layer (Vercel AI SDK + OpenRouter). All retries/timeouts and token
 * logging are centralised here; callers just pass system + messages + schema.
 */
const openrouter = createOpenRouter({ apiKey: config.OPENROUTER_API_KEY ?? '' });

/**
 * OpenRouter provider-routing preferences (latency optimisation), built from env.
 * `sort` steers OpenRouter to the fastest upstream; `order` optionally pins
 * preferred providers. `allow_fallbacks` stays true so a preferred/sorted
 * provider being unavailable never blocks a reply. Undefined → default routing.
 */
function providerRouting():
  | { sort?: 'price' | 'throughput' | 'latency'; order?: string[]; allow_fallbacks: boolean }
  | undefined {
  const sort = config.OPENROUTER_PROVIDER_SORT;
  const order = config.OPENROUTER_PROVIDER_ORDER;
  if (!sort && (!order || order.length === 0)) return undefined;
  return {
    ...(sort ? { sort } : {}),
    ...(order && order.length ? { order } : {}),
    allow_fallbacks: true,
  };
}

export interface GenerateReplyArgs<S extends z.ZodTypeAny> {
  system: string;
  messages: ModelMessage[];
  schema: S;
}

export interface GenerateReplyResult<S extends z.ZodTypeAny> {
  object: z.infer<S>;
  cachedInputTokens: number;
}

/**
 * Generate a structured reply with the MAIN_MODEL. The schema forces the model
 * to return valid JSON matching our contract. Logs token usage incl. cached
 * prompt tokens (plan.md §6 — verify prefix caching is working).
 */
export async function generateReply<S extends z.ZodTypeAny>(
  args: GenerateReplyArgs<S>,
): Promise<GenerateReplyResult<S>> {
  if (!config.OPENROUTER_API_KEY) {
    throw new Error('OpenRouter is not configured: set OPENROUTER_API_KEY in .env');
  }

  // Anthropic prompt caching (Claude models via OpenRouter) is opt-in: unlike
  // OpenAI's automatic cache, Claude only caches a prefix marked with an explicit
  // cache_control breakpoint. We carry the static system prompt (SOUL.md + config,
  // the large stable prefix) as a system MESSAGE so we can attach the breakpoint —
  // the `system` string param can't hold one. OpenRouter reads
  // providerOptions.openrouter.cacheControl and emits the Anthropic cache_control
  // block. The conversation history stays AFTER it (volatile, uncached), so repeat
  // turns within the 5-min TTL re-read the prefix at ~0.1x instead of re-billing it.
  // (No-op on non-Anthropic models — they ignore the breakpoint.)
  const cachedMessages: ModelMessage[] = [
    {
      role: 'system',
      content: args.system,
      providerOptions: { openrouter: { cacheControl: { type: 'ephemeral' } } },
    },
    ...args.messages,
  ];

  const startNs = process.hrtime.bigint();
  const { object, usage, providerMetadata } = await generateObject({
    // usage.include → OpenRouter returns detailed token accounting, incl.
    // cached prompt tokens, so we can verify prefix caching (plan.md §6).
    model: openrouter.chat(config.MAIN_MODEL, {
      usage: { include: true },
      provider: providerRouting(),
      // Keep reasoning effort low (default 'minimal') so a reasoning model doesn't
      // burn the whole output budget on thinking and return no JSON. Ignored by
      // non-reasoning models, so this stays correct for any MAIN_MODEL.
      reasoning: { effort: config.REASONING_EFFORT },
    }),
    messages: cachedMessages,
    schema: args.schema,
    // Cap output (reasoning + JSON combined). Env-tunable headroom: enough for a
    // reasoning model to think AND emit the full object, while bounding latency/cost.
    maxOutputTokens: config.MAX_OUTPUT_TOKENS,
    maxRetries: 2,
  });
  const durationMs = msSince(startNs);
  noteSpan('llm.generateReply', durationMs);

  const cachedInputTokens = usage.cachedInputTokens ?? 0;
  const inputTokens = usage.inputTokens ?? 0;
  log.info(
    {
      model: config.MAIN_MODEL,
      durationMs,
      inputTokens,
      outputTokens: usage.outputTokens,
      cachedInputTokens,
      // Share of the prompt served from cache — if ~0 on every turn, prefix
      // caching isn't firing and we're re-billing/re-processing the whole prefix.
      cacheHitRatio: inputTokens > 0 ? Math.round((cachedInputTokens / inputTokens) * 100) / 100 : 0,
      // ms-per-output-token: isolates model speed from prompt size; a spike here
      // with normal token counts points at a slow OpenRouter upstream or a retry.
      msPerOutputToken: usage.outputTokens ? Math.round((durationMs / usage.outputTokens) * 10) / 10 : null,
      // Surface raw provider metadata in debug so we can confirm the cache path.
      providerMetadata,
    },
    'llm reply generated',
  );

  return { object: object as z.infer<S>, cachedInputTokens };
}

/**
 * Cheap, non-structured text generation with the SUMMARY_MODEL — used for the
 * rolling conversation summary (plan.md §7).
 */
export async function summarize(system: string, prompt: string): Promise<string> {
  if (!config.OPENROUTER_API_KEY) {
    throw new Error('OpenRouter is not configured: set OPENROUTER_API_KEY in .env');
  }
  const startNs = process.hrtime.bigint();
  const { text, usage } = await generateText({
    model: openrouter.chat(config.SUMMARY_MODEL, {
      usage: { include: true },
      provider: providerRouting(),
      // Same low-reasoning guard as the main reply, so a reasoning SUMMARY_MODEL
      // can't spend its whole budget thinking and return empty text.
      reasoning: { effort: config.REASONING_EFFORT },
    }),
    system,
    prompt,
    maxOutputTokens: config.MAX_OUTPUT_TOKENS,
    maxRetries: 2,
  });
  const durationMs = msSince(startNs);
  noteSpan('llm.summarize', durationMs);
  log.info(
    {
      model: config.SUMMARY_MODEL,
      durationMs,
      inputTokens: usage.inputTokens,
      outputTokens: usage.outputTokens,
    },
    'summary generated',
  );
  return text.trim();
}
