import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { config } from '../config/index.js';

/**
 * Single Supabase client (service-role). Created lazily so the app can still
 * boot / serve /health without DB credentials; the first actual use throws a
 * clear error if SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY are missing.
 *
 * Service role bypasses RLS — never expose this client to the public surface.
 */
let client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (client) return client;

  if (!config.SUPABASE_URL || !config.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error(
      'Supabase is not configured: set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env',
    );
  }

  client = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return client;
}
