import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { config } from '../config/index.js';
import { logger } from '../utils/logger.js';
import { normalizeLanguageCode } from '../utils/language.js';
import { msSince, noteSpan } from '../utils/timing.js';

const log = logger.child({ svc: 'bird' });

/**
 * Error codes that mean the request never left this process — DNS resolution
 * failed before any connection was made. These are SAFE to retry because Bird
 * never received the request, so there's no risk of sending a WhatsApp message
 * twice. (We deliberately do NOT retry post-connection errors like ECONNRESET,
 * which could mean Bird already got the message.) EAI_AGAIN is the transient
 * resolver timeout we saw from Docker's embedded DNS.
 */
const RETRYABLE_DNS_CODES = new Set(['EAI_AGAIN', 'ENOTFOUND']);

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

/**
 * fetch() with a small retry on transient DNS failures only. Undici wraps the
 * underlying cause, so the DNS code lives at `err.cause.code`. Non-DNS errors and
 * HTTP error statuses (fetch doesn't throw on those) pass straight through.
 */
async function fetchWithDnsRetry(
  url: string,
  init: RequestInit,
  label: string,
  maxAttempts = 3,
): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fetch(url, init);
    } catch (err) {
      lastErr = err;
      const code = (err as { cause?: { code?: string } })?.cause?.code ?? '';
      if (!RETRYABLE_DNS_CODES.has(code) || attempt === maxAttempts) break;
      const delayMs = 200 * attempt;
      log.warn({ label, attempt, code, delayMs }, 'Bird DNS lookup failed — retrying');
      await sleep(delayMs);
    }
  }
  throw lastErr;
}

/** A resolved Bird template reference (projectId + version + locale). */
interface TemplateRef {
  projectId: string;
  version: string;
  locale: string;
}

/**
 * Pick the approved template for the user's language. Dutch users get the Dutch
 * template when it's configured; everyone else (and Dutch as a fallback) gets the
 * default/English template. Returns null if no usable template is configured.
 */
function resolveTemplate(language: string | null | undefined): TemplateRef | null {
  if (normalizeLanguageCode(language) === 'nl') {
    if (config.WHATSAPP_TEMPLATE_NL_PROJECT_ID && config.WHATSAPP_TEMPLATE_NL_VERSION) {
      return {
        projectId: config.WHATSAPP_TEMPLATE_NL_PROJECT_ID,
        version: config.WHATSAPP_TEMPLATE_NL_VERSION,
        locale: config.WHATSAPP_TEMPLATE_NL_LOCALE,
      };
    }
    log.warn('Dutch template not configured — falling back to default/English template');
  }
  if (config.WHATSAPP_TEMPLATE_PROJECT_ID && config.WHATSAPP_TEMPLATE_VERSION) {
    return {
      projectId: config.WHATSAPP_TEMPLATE_PROJECT_ID,
      version: config.WHATSAPP_TEMPLATE_VERSION,
      locale: config.WHATSAPP_TEMPLATE_LOCALE,
    };
  }
  return null;
}

/**
 * Send a plain-text WhatsApp message via the Bird Channels API.
 *
 *   POST {base}/workspaces/{workspaceId}/channels/{channelId}/messages
 *   Authorization: AccessKey <key>
 *   { receiver: { contacts: [{ identifierValue }] },
 *     body: { type: 'text', text: { text } } }
 *
 * Bird returns 202 (Accepted) on success — that means "queued", NOT delivered.
 * The actual delivery result arrives later via `whatsapp.outbound` status
 * webhooks, keyed by the returned message id. Throws on missing config / non-2xx.
 *
 * @returns the Bird message id (used to correlate later status webhooks), or
 *          null if the response body didn't include one.
 */
export async function sendText(phone: string, text: string): Promise<string | null> {
  const { BIRD_API_KEY, BIRD_WORKSPACE_ID, BIRD_CHANNEL_ID, BIRD_API_BASE_URL } = config;
  if (!BIRD_API_KEY || !BIRD_WORKSPACE_ID || !BIRD_CHANNEL_ID) {
    throw new Error(
      'Bird is not configured: set BIRD_API_KEY, BIRD_WORKSPACE_ID, BIRD_CHANNEL_ID in .env',
    );
  }

  const url = `${BIRD_API_BASE_URL}/workspaces/${BIRD_WORKSPACE_ID}/channels/${BIRD_CHANNEL_ID}/messages`;
  const startNs = process.hrtime.bigint();
  const res = await fetchWithDnsRetry(
    url,
    {
      method: 'POST',
      headers: {
        Authorization: `AccessKey ${BIRD_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        receiver: { contacts: [{ identifierValue: phone }] },
        body: { type: 'text', text: { text } },
      }),
    },
    'sendText',
  );
  const durationMs = msSince(startNs);
  noteSpan('bird.sendText', durationMs, res.ok);

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    log.error({ status: res.status, durationMs, detail }, 'Bird sendText failed');
    throw new Error(`Bird sendText failed: ${res.status}`);
  }

  const data = (await res.json().catch(() => null)) as { id?: string } | null;
  const messageId = data?.id ?? null;
  // 202 = accepted/queued, not delivered — final result comes via status webhook.
  log.info({ status: res.status, durationMs, messageId }, 'queued WhatsApp message');
  log.debug({ phone }, 'outbound recipient');
  return messageId;
}

/**
 * One substituted placeholder in an approved template. `key` is the placeholder
 * name as it appears in the template (e.g. `name`, `task`, `checklist_url` for
 * `lua_daily_update_en`). Bird matches named placeholders by key; omit `key` only
 * for a positional template.
 */
export interface TemplateParam {
  key?: string;
  value: string;
}

/**
 * Send an approved WhatsApp TEMPLATE message (HSM) — required to re-engage a user
 * outside the 24h session window (plan.md §12/§15). Until a template projectId is
 * configured we skip and log, so the reminder path degrades gracefully.
 *
 * Bird references WhatsApp templates by their Touchpoints `projectId` (NOT by
 * name), plus `version` (the channel-template resource id) and `locale`. Named
 * placeholders are sent as `{ type, key, value }`, matching the template's keyed
 * variables. The template is chosen by the user's `language` (Dutch → the Dutch
 * template, otherwise English); both share the placeholders {{name}} {{task}}
 * {{checklist_url}}.
 *
 * @returns the Bird message id, or null if skipped (no template configured) / no id.
 */
export async function sendTemplate(
  phone: string,
  params: TemplateParam[] = [],
  language?: string | null,
): Promise<string | null> {
  const { BIRD_API_KEY, BIRD_WORKSPACE_ID, BIRD_CHANNEL_ID, BIRD_API_BASE_URL } = config;
  const template = resolveTemplate(language);
  if (!template) {
    log.warn(
      { phone: '<redacted>' },
      'no WhatsApp template configured (projectId/version) — skipping out-of-window send',
    );
    return null;
  }
  if (!BIRD_API_KEY || !BIRD_WORKSPACE_ID || !BIRD_CHANNEL_ID) {
    throw new Error('Bird is not configured: set BIRD_API_KEY, BIRD_WORKSPACE_ID, BIRD_CHANNEL_ID');
  }

  const url = `${BIRD_API_BASE_URL}/workspaces/${BIRD_WORKSPACE_ID}/channels/${BIRD_CHANNEL_ID}/messages`;
  const res = await fetchWithDnsRetry(
    url,
    {
      method: 'POST',
      headers: { Authorization: `AccessKey ${BIRD_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        receiver: { contacts: [{ identifierValue: phone }] },
        template: {
          projectId: template.projectId,
          version: template.version,
          locale: template.locale,
          parameters: params.map((p) => ({
            type: 'string',
            ...(p.key ? { key: p.key } : {}),
            value: p.value,
          })),
        },
      }),
    },
    'sendTemplate',
  );

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    log.error(
      { status: res.status, detail, projectId: template.projectId, locale: template.locale },
      'Bird sendTemplate failed',
    );
    throw new Error(`Bird sendTemplate failed: ${res.status}`);
  }
  const data = (await res.json().catch(() => null)) as { id?: string } | null;
  const messageId = data?.id ?? null;
  log.info(
    { status: res.status, messageId, projectId: template.projectId, locale: template.locale },
    'queued WhatsApp template',
  );
  return messageId;
}

/**
 * Verify a Bird webhook signature (MessageBird scheme).
 *
 * signed payload = `${timestamp}\n${url}\n` + SHA256(rawBody)   (body hash is BINARY)
 * signature      = base64( HMAC_SHA256(signingKey, signed payload) )
 *
 * `url` must match exactly what Bird signed (the configured webhook URL).
 * Returns false (fail-closed) if the signing key is unset or anything is off.
 */
export function verifyWebhookSignature(args: {
  signatureHeader: string | undefined;
  timestampHeader: string | undefined;
  url: string;
  rawBody: Buffer;
}): boolean {
  const { signatureHeader, timestampHeader, url, rawBody } = args;
  const signingKey = config.BIRD_WEBHOOK_SIGNING_KEY;

  if (!signingKey) {
    log.warn('BIRD_WEBHOOK_SIGNING_KEY not set — rejecting webhook (fail-closed)');
    return false;
  }
  if (!signatureHeader || !timestampHeader) return false;

  // SHA256 of the raw body as binary bytes (not hex).
  const bodyHash = createHash('sha256').update(rawBody).digest();
  const signedPayload = Buffer.concat([
    Buffer.from(`${timestampHeader}\n${url}\n`, 'utf8'),
    bodyHash,
  ]);

  const expected = createHmac('sha256', signingKey).update(signedPayload).digest();

  let provided: Buffer;
  try {
    provided = Buffer.from(signatureHeader, 'base64');
  } catch {
    return false;
  }

  if (provided.length !== expected.length) {
    log.debug({ url }, 'webhook signature length mismatch');
    return false;
  }
  return timingSafeEqual(expected, provided);
}
