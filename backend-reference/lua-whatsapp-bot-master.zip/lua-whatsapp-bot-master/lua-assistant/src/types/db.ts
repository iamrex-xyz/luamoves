// Row shapes for the tables we read/write directly. Kept minimal and grown
// per day as features land. Mirrors migrations/0001_init.sql (plan.md §8).

export type MessageRole = 'user' | 'assistant';

export interface UserRow {
  id: string;
  phone: string;
  name: string | null;
  move_date: string | null;
  move_type: 'rent' | 'buy' | null;
  from_address: string | null;
  to_address: string | null;
  home_type: string | null;
  household: Record<string, unknown> | null;
  notice_given: boolean;
  /** Current session language (ISO 639-1). The language reminders fall back to. */
  language: string;
  /** @deprecated 0007 lock model superseded by adaptive detection (0009). Unused. */
  language_locked: boolean;
  /** Rolling window of recently detected languages, oldest → newest (0009). The
   *  session language is the majority of this window. */
  recent_languages: string[];
  onboarding_step: string;
  tasklist_token: string;
  /** Crisis-pause marker (migrations/0004): null = flow active, else paused since. */
  safety_paused_at: string | null;
  /** "stop" opt-out (migrations/0005): true = no more proactive reminders. */
  reminders_opt_out: boolean;
  created_at: string;
  updated_at: string;
}

export type TaskStatus = 'pending' | 'completed' | 'snoozed';
export type CompletedVia = 'whatsapp' | 'web';

export interface TaskRow {
  id: string;
  user_id: string;
  task_key: string;
  title: string;
  status: TaskStatus;
  due_date: string | null;
  affiliate_trigger: string | null;
  completed_via: CompletedVia | null;
  // Denormalised from the master list (migrations/0006) for the web page.
  phase_order: number | null;
  phase_name: string | null;
  category: string | null;
  explanation: string | null;
  tip: string | null;
  sort_order: number | null;
  created_at: string;
  updated_at: string;
}

/**
 * A seed row from the client's master task list (task_templates, migrations/0006).
 * The list is phase-based (no day offsets); due dates are derived from phase_order
 * in code. `condition` is the Dutch gating value (altijd / kinderen / huisdieren /
 * verbouwing / hoog / parkeren), evaluated in features/checklist/generate.ts.
 */
export interface TaskTemplateRow {
  task_key: string;
  move_type: 'rent' | 'buy';
  phase_order: number;
  phase_name: string;
  category: string;
  title: string;
  /** English title (0011). Null falls back to the Dutch `title`. */
  title_en: string | null;
  explanation: string | null;
  tip: string | null;
  condition: string;
  affiliate_trigger: string | null;
  sort_order: number;
}

export interface MessageRow {
  id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  message_id: string | null;
  created_at: string;
}

/**
 * Offer keys (monetization.md). Match task_templates.affiliate_trigger
 * (0003/0006/0012). `moving_boxes` and `contract_cancellation` are "Commission to
 * confirm" partners — no disclosure, presented as a convenience (links.ts §commercial).
 */
export type OfferKey =
  | 'energy'
  | 'internet'
  | 'insurance'
  | 'moving_company'
  | 'moving_boxes'
  | 'cleaning'
  | 'renovation'
  | 'mortgage'
  | 'lock'
  | 'contract_cancellation';

export interface AffiliateFlagRow {
  user_id: string;
  offer_key: string;
  shown: boolean;
  declined: boolean;
  disclosure_sent: boolean;
  /** The partner link was actually delivered (accept turn). Blocks re-sending. */
  link_sent: boolean;
  updated_at: string;
}

export interface ReminderLogRow {
  user_id: string;
  reminder_key: string;
  last_reminder_at: string;
}

export interface SessionMetadataRow {
  user_id: string;
  last_activity_at: string;
}
