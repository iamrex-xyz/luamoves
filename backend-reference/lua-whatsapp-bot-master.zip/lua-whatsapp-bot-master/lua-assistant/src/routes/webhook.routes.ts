import { Router, type Request, type Response } from 'express';
import { config } from '../config/index.js';
import { verifyWebhookSignature } from '../services/bird.service.js';
import { handleInbound } from '../features/conversation/orchestrator.js';
import { logger } from '../utils/logger.js';
import * as messages from '../repositories/message.repository.js';

export const webhookRouter: Router = Router();

const log = logger.child({ route: 'webhook' });

interface ParsedInbound {
  messageId: string;
  phone: string;
  text: string;
  /** ms since epoch when the USER sent it on WhatsApp (meta.extraInformation.timestamp). */
  userSentAtMs: number | null;
  /** ms since epoch when Bird received it (payload.createdAt). */
  birdReceivedAtMs: number | null;
}

/** Parse an ISO-8601 timestamp string to epoch ms (null if missing/invalid). */
function isoToMs(v: unknown): number | null {
  if (typeof v !== 'string') return null;
  const t = Date.parse(v);
  return Number.isNaN(t) ? null : t;
}

/** Parse an epoch timestamp (Bird sends WhatsApp's as a seconds string) to ms. */
function epochToMs(v: unknown): number | null {
  if (v == null) return null;
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n < 1e12 ? Math.round(n * 1000) : n; // seconds → ms
}

/**
 * Extract a usable inbound text message from a Bird webhook body. Handles both
 * the event envelope ({ event, payload }) and a bare message object. Returns
 * null for anything that isn't an incoming text (status updates, etc.).
 */
function parseInbound(body: unknown): ParsedInbound | null {
  if (!body || typeof body !== 'object') return null;
  const b = body as Record<string, any>;
  const event: string = b.event ?? b.type ?? '';
  const msg = (b.payload as Record<string, any>) ?? b;

  const isIncoming = msg?.direction === 'incoming' || /inbound/i.test(event);
  const messageId = msg?.id;
  const phone = msg?.sender?.contact?.identifierValue;
  const text = msg?.body?.text?.text;

  if (!isIncoming) return null;
  if (typeof messageId !== 'string' || typeof phone !== 'string') return null;
  if (msg?.body?.type !== 'text' || typeof text !== 'string') return null;

  return {
    messageId,
    phone,
    text,
    userSentAtMs: epochToMs(msg?.meta?.extraInformation?.timestamp),
    birdReceivedAtMs: isoToMs(msg?.createdAt),
  };
}

interface ParsedStatus {
  messageId: string;
  status: string;
  reason: string | null;
  /** ms since epoch the outbound message was created at Bird (payload.createdAt). */
  birdCreatedAtMs: number | null;
  /** ms since epoch this status occurred (payload.lastStatusAt). */
  statusAtMs: number | null;
}

/** Delivery statuses that mean the message did NOT reach the user. */
const FAILED_STATUSES = new Set(['sending_failed', 'delivery_failed', 'skipped', 'deleted']);

/**
 * Extract an outbound delivery-status update (whatsapp.outbound). Returns null
 * for anything else.
 */
function parseStatus(body: unknown): ParsedStatus | null {
  if (!body || typeof body !== 'object') return null;
  const b = body as Record<string, any>;
  const event: string = b.event ?? '';
  const msg = (b.payload as Record<string, any>) ?? b;

  const isStatus = /outbound/i.test(event) || msg?.direction === 'outgoing';
  if (!isStatus) return null;
  if (typeof msg?.id !== 'string' || typeof msg?.status !== 'string') return null;

  return {
    messageId: msg.id,
    status: msg.status,
    reason: msg.reason || null,
    birdCreatedAtMs: isoToMs(msg?.createdAt),
    statusAtMs: isoToMs(msg?.lastStatusAt),
  };
}

/** Reconstruct the exact URL Bird signed (pinned via env when behind a proxy). */
function signedUrl(req: Request): string {
  if (config.BIRD_WEBHOOK_URL) return config.BIRD_WEBHOOK_URL;
  const proto = ((req.headers['x-forwarded-proto'] as string) ?? req.protocol).split(',')[0];
  const host = (req.headers['x-forwarded-host'] as string) ?? req.headers.host;
  return `${proto}://${host}${req.originalUrl}`;
}

webhookRouter.post('/webhook', (req: Request & { rawBody?: Buffer }, res: Response) => {
  // 1. Verify the Bird signature against the raw body (fail-closed → 401).
  const valid = verifyWebhookSignature({
    signatureHeader: req.header('messagebird-signature'),
    timestampHeader: req.header('messagebird-request-timestamp'),
    url: signedUrl(req),
    rawBody: req.rawBody ?? Buffer.alloc(0),
  });
  if (!valid) {
    log.warn({ url: signedUrl(req) }, 'rejected webhook: invalid signature');
    return res.status(401).json({ error: 'invalid_signature' });
  }

  // 2. ACK immediately — Bird retries on slow/non-200 responses.
  res.status(200).json({ ok: true });

  // 3. Process after the ACK; never let processing throw into the response.
  const inbound = parseInbound(req.body);
  if (inbound) {
    const now = Date.now();
    // userToUsMs: WhatsApp send time → us (full inbound leg; ±1s, seconds-precision).
    // birdToUsMs: Bird received → us (ms-precise). Their difference ≈ WhatsApp→Bird.
    const userToUsMs =
      inbound.userSentAtMs != null ? Math.max(0, now - inbound.userSentAtMs) : null;
    const birdToUsMs =
      inbound.birdReceivedAtMs != null ? Math.max(0, now - inbound.birdReceivedAtMs) : null;
    // info stays PII-free; full content only at debug.
    log.info(
      { messageId: inbound.messageId, textLength: inbound.text.length, userToUsMs, birdToUsMs },
      'inbound WhatsApp message received',
    );
    log.debug({ phone: inbound.phone, text: inbound.text }, 'inbound message content');
    void handleInbound(inbound).catch((err) => log.error({ err }, 'inbound processing failed'));
    return;
  }

  // Outbound delivery-status update (sent/delivered/failed/...).
  const status = parseStatus(req.body);
  if (status) {
    void handleStatusUpdate(status).catch((err) => log.error({ err }, 'status update failed'));
  }
});

/** Persist an outbound delivery status; log failures loudly. */
async function handleStatusUpdate(s: ParsedStatus): Promise<void> {
  const matched = await messages.updateStatusByProviderId(s.messageId, s.status, s.reason);
  const failed = FAILED_STATUSES.has(s.status);
  // deliveryMs comes straight from Bird's own payload timestamps (status time −
  // message-created time), so it's reliable regardless of whether our DB row was
  // found. For status='delivered' this is the Bird→WhatsApp→device leg — the true
  // "reached the user" number. Filter on status='delivered' in Grafana.
  const deliveryMs =
    s.birdCreatedAtMs != null && s.statusAtMs != null
      ? Math.max(0, s.statusAtMs - s.birdCreatedAtMs)
      : null;
  const fields = {
    providerMessageId: s.messageId,
    status: s.status,
    reason: s.reason,
    matched,
    deliveryMs,
  };
  if (failed) {
    log.error(fields, 'WhatsApp delivery FAILED');
  } else {
    log.info(fields, 'WhatsApp delivery status');
  }
}
