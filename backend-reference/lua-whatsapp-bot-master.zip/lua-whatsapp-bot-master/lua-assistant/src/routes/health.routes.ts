import { Router, type Request, type Response } from 'express';
import { promptVersionShort } from '../config/prompts.js';

export const healthRouter: Router = Router();

/**
 * GET /health — liveness + config-version probe.
 * Returns the loaded prompt config version so we can confirm which behaviour
 * spec a running instance is serving (cache-busting / deploy verification).
 */
healthRouter.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    configVersion: promptVersionShort,
    uptime: Math.round(process.uptime()),
  });
});
