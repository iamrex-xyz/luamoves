import { Router, type Request, type RequestHandler, type Response } from 'express';
import { renderTasklistPage } from '../web/tasklistPage.js';
import { buildTasklistView } from '../web/tasklistView.js';
import { updateTaskStatusById } from '../features/checklist/updateStatus.js';
import { logger } from '../utils/logger.js';
import * as users from '../repositories/user.repository.js';
import * as taskRepo from '../repositories/task.repository.js';

export const tasklistRouter: Router = Router();
const log = logger.child({ route: 'tasklist' });

/** Forward async handler rejections to Express's error handler (Express 4). */
const wrap =
  (fn: (req: Request, res: Response) => Promise<void>): RequestHandler =>
  (req, res, next) =>
    fn(req, res).catch(next);

/**
 * JSON task-list (plan.md §13) — consumed by the Lovable frontend. Token in the
 * URL is the only auth. Returns the structured view (user + progress + phases).
 */
tasklistRouter.get(
  '/api/tasklist/:token',
  wrap(async (req, res) => {
    const user = await users.getByTasklistToken(String(req.params.token));
    if (!user) {
      res.status(404).json({ error: 'not_found' });
      return;
    }
    const tasks = await taskRepo.listByUser(user.id);
    res.json(buildTasklistView(user, tasks));
  }),
);

/**
 * Server-rendered fallback page (also handy for quick checks). The Lovable app is
 * the primary UI; this stays as a no-framework fallback at the same token.
 */
tasklistRouter.get(
  '/tasklist/:token',
  wrap(async (req, res) => {
    const user = await users.getByTasklistToken(String(req.params.token));
    if (!user) {
      res.status(404).type('html').send('<h1>Checklist niet gevonden</h1>');
      return;
    }
    const tasks = await taskRepo.listByUser(user.id);
    res.type('html').send(renderTasklistPage(user, tasks));
  }),
);

/**
 * Write-back (plan.md §13). Token-scoped: the body carries the same tasklist
 * token; we resolve the owning user and update only THEIR task, via the shared
 * updateTaskStatus path (completed_via='web'). Never trusts the task id alone.
 */
tasklistRouter.patch(
  '/api/tasks/:id',
  wrap(async (req, res) => {
    const { token, status } = (req.body ?? {}) as { token?: string; status?: string };
    if (status !== 'completed' && status !== 'pending') {
      res.status(400).json({ error: 'invalid_status' });
      return;
    }
    if (!token) {
      res.status(401).json({ error: 'missing_token' });
      return;
    }
    const user = await users.getByTasklistToken(token);
    if (!user) {
      res.status(403).json({ error: 'invalid_token' });
      return;
    }

    const updated = await updateTaskStatusById(user.id, String(req.params.id), status);
    if (!updated) {
      res.status(404).json({ error: 'task_not_found' });
      return;
    }
    log.info({ userId: user.id, taskId: updated.id, status, via: 'web' }, 'task updated via web');
    res.json({ ok: true, status: updated.status });
  }),
);
