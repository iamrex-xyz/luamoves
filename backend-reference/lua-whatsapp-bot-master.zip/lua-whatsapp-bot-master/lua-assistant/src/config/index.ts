import { config as loadDotenv } from 'dotenv';
import { z } from 'zod';

// Load .env into process.env (no-op in production where env is injected).
loadDotenv();

/**
 * Environment schema — the single source of truth for configuration.
 *
 * Rules honoured here (see CLAUDE.md / plan.md):
 *  - Models are NEVER hard-coded: they come from MAIN_MODEL / SUMMARY_MODEL.
 *  - Boot fails fast and loud if a required var is missing or malformed.
 *
 * NOTE: secrets (OpenRouter / Supabase / Bird) are NOT required at boot yet —
 * Day 1 only needs the service to start and serve /health. They are marked
 * optional now and will be tightened to required on the day each integration
 * lands (Day 2 Bird/Supabase, Day 3 LLM). This keeps the scaffold runnable.
 */
const envSchema = z.object({
  // Runtime
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  LOG_LEVEL: z
    .enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent'])
    .default('info'),
  // Log output format. Defaults to pretty in dev / json otherwise. Set
  // LOG_FORMAT=json to emit machine-readable JSON (required for Loki parsing).
  LOG_FORMAT: z.enum(['json', 'pretty']).optional(),
  TZ: z.string().default('Europe/Amsterdam'),

  // LLM (OpenRouter) — required from Day 3 onward.
  OPENROUTER_API_KEY: z.string().min(1).optional(),
  MAIN_MODEL: z.string().min(1).default('openai/gpt-4.1-mini'),
  SUMMARY_MODEL: z.string().min(1).default('openai/gpt-4.1-nano'),
  // OpenRouter provider routing (latency optimisation). Sort upstream providers
  // by 'throughput' (fastest tokens/s — best for total time), 'latency' (lowest
  // time-to-first-token), or 'price'. Unset → OpenRouter's default routing.
  OPENROUTER_PROVIDER_SORT: z.enum(['price', 'throughput', 'latency']).optional(),
  // Optional comma-separated provider slugs to prefer in order (e.g. "OpenAI,Azure").
  // Fallbacks stay enabled, so a preferred provider being down never blocks a reply.
  OPENROUTER_PROVIDER_ORDER: z
    .string()
    .optional()
    .transform((s) =>
      s
        ? s
            .split(',')
            .map((x) => x.trim())
            .filter(Boolean)
        : undefined,
    ),
  // Reasoning effort for reasoning-capable models (GPT-5, o-series, etc.), passed
  // straight to OpenRouter. Default 'minimal' keeps latency/cost down and — crucially —
  // stops a reasoning model from spending the whole output budget on thinking and
  // returning no JSON (the NoObjectGeneratedError we hit on gpt-5-nano). NON-reasoning
  // models ignore this, so it's safe for ANY MAIN_MODEL/SUMMARY_MODEL. 'none' disables
  // thinking entirely; raise to 'low'/'medium' if a model needs more deliberation.
  REASONING_EFFORT: z
    .enum(['xhigh', 'high', 'medium', 'low', 'minimal', 'none'])
    .default('minimal'),
  // Hard cap on generated tokens per reply (reasoning + visible output COMBINED).
  // 4000 gives reasoning models headroom to think AND still emit the full JSON, while
  // keeping WhatsApp replies bounded. Non-reasoning models rarely approach it.
  MAX_OUTPUT_TOKENS: z.coerce.number().int().positive().default(4000),

  // Supabase (client-provided) — required from Day 2 onward.
  SUPABASE_URL: z.string().url().optional(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1).optional(),

  // Bird (WhatsApp) — required from Day 2 onward.
  BIRD_API_KEY: z.string().min(1).optional(),
  BIRD_WORKSPACE_ID: z.string().min(1).optional(),
  BIRD_CHANNEL_ID: z.string().min(1).optional(),
  BIRD_WEBHOOK_SIGNING_KEY: z.string().min(1).optional(),
  // Bird API base (override only for testing/mocks).
  BIRD_API_BASE_URL: z.string().url().default('https://api.bird.com'),
  // Exact public URL Bird signs the webhook against. Optional: if unset we
  // reconstruct it from forwarded headers. Pin it when behind a proxy/tunnel
  // (e.g. ngrok) to make signature verification deterministic.
  BIRD_WEBHOOK_URL: z.string().url().optional(),

  // Reminders (Redis) — required from Day 6 onward.
  REDIS_URL: z.string().min(1).default('redis://redis:6379'),
  // Daily scan cron (Europe/Amsterdam via TZ). Default 08:00.
  REMINDER_CRON: z.string().min(1).default('0 8 * * *'),
  // TEMPORARY TEST MODE (default OFF — production behaviour is unchanged unless
  // explicitly enabled). When 'true', the reminder scan bypasses the once-per-day
  // guards so it re-fires every scan, and forces the approved template path. Pair
  // it with a fast REMINDER_CRON (e.g. "*/3 * * * *"). Set REMINDER_TEST_PHONE to a
  // single E.164 number to fire ONLY for that user and avoid messaging anyone else.
  REMINDER_TEST_MODE: z
    .enum(['true', 'false'])
    .default('false')
    .transform((v) => v === 'true'),
  REMINDER_TEST_PHONE: z.string().min(1).optional(),
  // WhatsApp 24h session window; outside it, re-engage via an approved template.
  SESSION_WINDOW_HOURS: z.coerce.number().int().positive().default(24),
  // Approved re-engagement template (client-provided). Bird references WhatsApp
  // templates by their Touchpoints *projectId* (NOT by name), plus a version and
  // locale. Unset projectId → out-of-window reminders are logged + skipped.
  //   - PROJECT_ID: the template project's UUID (Touchpoints "projects" id).
  //   - VERSION: the channel-template *resource* UUID (the project's
  //     `activeResourceId`). NOTE: Bird rejects "latest" with
  //     "Invalid value for channelTemplateID" — it must be a real resource id.
  //     Update this whenever the template is re-versioned/re-approved.
  //   - LOCALE: which language version to send (active template is en-only;
  //     the Dutch one, `Daily Update NL`, is still a draft in Bird).
  //   - NAME: cosmetic, for logs only.
  // Current active template `lua_daily_update_en`: projectId
  //   a4dad75c-7463-4459-8fe0-ef5d7b425d00, resource c4c38480-…-dafa92d92ece,
  //   locale en, placeholders {{name}} {{task}} {{checklist_url}}.
  // Default/English template (used for English + any non-Dutch user).
  WHATSAPP_TEMPLATE_PROJECT_ID: z.string().min(1).optional(),
  WHATSAPP_TEMPLATE_VERSION: z.string().min(1).optional(),
  WHATSAPP_TEMPLATE_LOCALE: z.string().min(1).default('en'),
  WHATSAPP_TEMPLATE_NAME: z.string().min(1).optional(),
  // Dutch template (used when the user's session language is Dutch). Falls back
  // to the default/English template above if these are unset. Active template
  // `lua_daily_update_nl`: projectId 464ca6b7-…-ae7af2d3f71c,
  // resource bcaee818-…-433ddd4e5bd1, locale nl, same placeholders.
  WHATSAPP_TEMPLATE_NL_PROJECT_ID: z.string().min(1).optional(),
  WHATSAPP_TEMPLATE_NL_VERSION: z.string().min(1).optional(),
  WHATSAPP_TEMPLATE_NL_LOCALE: z.string().min(1).default('nl'),

  // Affiliate (plan.md §11) — at the client's instruction, partner names + URLs
  // now live directly in code (src/features/affiliate/links.ts), not in env. The
  // disclosure wording lives in monetization.md (in the prompt) and is rendered by
  // the model in the user's language. No AFFILIATE_* env vars are read anymore.

  // Optional FORCED reply language (dev override). When set (e.g. 'en'/'nl'), Lua
  // always replies in it and language auto-detection is skipped. Leave EMPTY for
  // production behaviour: detect the user's language on first contact and lock it
  // (users.language). Affects only free-form LLM text, never fixed templates.
  REPLY_LANGUAGE: z.string().min(1).optional(),

  // Web / links
  PUBLIC_BASE_URL: z.string().url().default('http://localhost:3000'),
  // Tasklist link sent in the WhatsApp summary. `{token}` is substituted. Set
  // this to the LOVABLE frontend URL (e.g. https://app.lovable.app/tasklist?token={token}).
  // When unset, we fall back to our own server-rendered page (PUBLIC_BASE_URL).
  FRONTEND_TASKLIST_URL: z.string().optional(),
  // CORS allow-list for the browser frontend (Lovable). '*' or a comma-separated
  // list of origins (e.g. https://app.lovable.app,https://lua.nl). Token-based
  // auth means '*' is acceptable, but lock it to the Lovable origin for prod.
  CORS_ORIGINS: z.string().default('*'),

  // Tunables
  HISTORY_WINDOW_N: z.coerce.number().int().positive().default(10),
  SUMMARY_EVERY_N: z.coerce.number().int().positive().default(20),
  // HTTP keep-alive (seconds): how long idle TLS connections to OpenRouter/Bird/
  // Supabase are kept warm for reuse. undici's default is ~4s, so human-paced
  // turns pay a fresh handshake each time; 60s keeps them warm between messages.
  HTTP_KEEPALIVE_TIMEOUT_S: z.coerce.number().int().positive().default(60),
});

export type AppConfig = z.infer<typeof envSchema>;

function loadConfig(): AppConfig {
  // Treat empty-string env vars (e.g. `OPENROUTER_API_KEY=` in a stub .env) as
  // "not provided", so optional fields stay optional and defaults still apply.
  const cleaned: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined && value !== '') cleaned[key] = value;
  }

  const parsed = envSchema.safeParse(cleaned);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `  - ${i.path.join('.') || '(root)'}: ${i.message}`)
      .join('\n');
    // Fail fast — do not start a server with invalid configuration.
    // eslint-disable-next-line no-console
    console.error(`\n[config] Invalid environment configuration:\n${issues}\n`);
    process.exit(1);
  }
  return parsed.data;
}

export const config: AppConfig = loadConfig();
