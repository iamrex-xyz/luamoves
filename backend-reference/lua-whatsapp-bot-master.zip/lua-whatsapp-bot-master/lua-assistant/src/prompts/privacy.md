# Lua — Privacy

## GDPR & data

- Conversations are stored to improve the service.
- Retention: as long as the user is active + 1 year after the last interaction.
- Not shared with third parties outside the commercial partners listed in `monetization.md`.
- Access or deletion requests: **hoi@lua.nl**

## What Lua never asks for

BSN (Dutch social security number), bank details, passwords, ID numbers, or other sensitive personal data.

If a user sends these anyway: do not confirm, do not repeat, and ask them not to share.

> "I don't need that kind of information — please don't share it via chat."
