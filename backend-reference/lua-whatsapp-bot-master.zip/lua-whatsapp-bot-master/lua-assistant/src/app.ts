import express, { type Application, type NextFunction, type Request, type Response } from 'express';
import { healthRouter } from './routes/health.routes.js';
import { webhookRouter } from './routes/webhook.routes.js';
import { tasklistRouter } from './routes/tasklist.routes.js';
import { cors } from './utils/cors.js';
import { httpLogger } from './utils/httpLogger.js';
import { logger } from './utils/logger.js';

/**
 * Build the Express application: middleware + mounted routes + error handler.
 * Kept free of side effects (no server start, no port binding) so it can be
 * imported by tests. Booting lives in index.ts.
 */
export function createApp(): Application {
  const app = express();

  // Correlation id + per-request access log — first, so everything downstream
  // (incl. async webhook processing) runs within the request context.
  app.use(httpLogger);

  // CORS for the browser frontend (Lovable) calling our /api/* endpoints.
  app.use(cors);

  // JSON body parsing. We retain the raw body so the Bird webhook (Day 2) can
  // verify its HMAC signature against the exact received bytes.
  app.use(
    express.json({
      verify: (req: Request & { rawBody?: Buffer }, _res, buf) => {
        req.rawBody = buf;
      },
    }),
  );

  // Routes
  app.use(healthRouter);
  app.use(webhookRouter);
  app.use(tasklistRouter);

  // 404 fallback
  app.use((_req: Request, res: Response) => {
    res.status(404).json({ error: 'not_found' });
  });

  // Centralised error handler — must keep the 4-arg signature for Express.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
    logger.error({ err, path: req.path }, 'unhandled request error');
    res.status(500).json({ error: 'internal_error' });
  });

  return app;
}
