import { getSupabase } from '../services/supabase.service.js';
import type {
  CompletedVia,
  TaskRow,
  TaskStatus,
  TaskTemplateRow,
} from '../types/db.js';

const TABLE = 'checklist_tasks';
const TEMPLATES_TABLE = 'task_templates';

/** All seed templates (migrations/0003). Filtering happens in TS, not SQL. */
export async function listTemplates(): Promise<TaskTemplateRow[]> {
  const { data, error } = await getSupabase().from(TEMPLATES_TABLE).select('*');
  if (error) throw error;
  return (data as TaskTemplateRow[]) ?? [];
}

/** A user's checklist, ordered by the master-list sequence (phase then sort_order). */
export async function listByUser(userId: string): Promise<TaskRow[]> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .order('sort_order', { ascending: true, nullsFirst: false })
    .order('task_key', { ascending: true });
  if (error) throw error;
  return (data as TaskRow[]) ?? [];
}

export async function getByUserAndKey(
  userId: string,
  taskKey: string,
): Promise<TaskRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .eq('task_key', taskKey)
    .maybeSingle();
  if (error) throw error;
  return (data as TaskRow | null) ?? null;
}

export interface NewTask {
  user_id: string;
  task_key: string;
  title: string;
  due_date: string | null;
  affiliate_trigger: string | null;
  phase_order: number;
  phase_name: string;
  category: string;
  explanation: string | null;
  tip: string | null;
  sort_order: number;
}

/**
 * Insert generated tasks, idempotently. `ignoreDuplicates` on (user_id, task_key)
 * means re-running generation never overwrites an existing task — crucially, it
 * never resets a task the user already completed.
 */
export async function insertMany(rows: NewTask[]): Promise<number> {
  if (rows.length === 0) return 0;
  const { data, error } = await getSupabase()
    .from(TABLE)
    .upsert(rows, { onConflict: 'user_id,task_key', ignoreDuplicates: true })
    .select('id');
  if (error) throw error;
  return data?.length ?? 0;
}

/**
 * Update a task's status. `completed_via` is set only when completing; clearing a
 * completion (e.g. back to pending) nulls it. Scoped by user_id so a token/path
 * can never touch another user's task. Returns the updated row, or null if no
 * matching task exists for this user.
 */
export async function updateStatus(
  userId: string,
  taskKey: string,
  status: TaskStatus,
  via: CompletedVia | null,
): Promise<TaskRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .update({ status, completed_via: status === 'completed' ? via : null })
    .eq('user_id', userId)
    .eq('task_key', taskKey)
    .select('*')
    .maybeSingle();
  if (error) throw error;
  return (data as TaskRow | null) ?? null;
}

/** Set a task's due date (used when recomputing after a move-date change). */
export async function updateDueDate(taskId: string, dueDate: string | null): Promise<void> {
  const { error } = await getSupabase()
    .from(TABLE)
    .update({ due_date: dueDate })
    .eq('id', taskId);
  if (error) throw error;
}

/**
 * Recompute ALL of a user's task due dates from their current move_date in a
 * single atomic DB call (migrations/0008 `recompute_due_dates`). Replaces the
 * previous per-task UPDATE loop (one round-trip each → ~8s on 40+ tasks).
 *
 * The date rule lives in the SQL function and MIRRORS PHASE_OFFSET_DAYS in
 * features/checklist/generate.ts — keep both in sync. `tz` resolves "today" for
 * the clamp. Returns the count of rows whose date changed.
 */
export async function recomputeDueDates(userId: string, tz: string): Promise<number> {
  const { data, error } = await getSupabase().rpc('recompute_due_dates', {
    p_user_id: userId,
    p_tz: tz,
  });
  if (error) throw error;
  return typeof data === 'number' ? data : 0;
}

/** Update by task id, scoped to the owning user (the web/token path). */
export async function updateStatusById(
  userId: string,
  taskId: string,
  status: TaskStatus,
  via: CompletedVia | null,
): Promise<TaskRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .update({ status, completed_via: status === 'completed' ? via : null })
    .eq('user_id', userId)
    .eq('id', taskId)
    .select('*')
    .maybeSingle();
  if (error) throw error;
  return (data as TaskRow | null) ?? null;
}
