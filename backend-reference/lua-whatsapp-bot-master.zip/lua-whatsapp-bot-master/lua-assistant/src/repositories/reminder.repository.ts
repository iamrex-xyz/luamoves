import { getSupabase } from '../services/supabase.service.js';
import type { ReminderLogRow, TaskRow, UserRow } from '../types/db.js';

const TABLE = 'reminder_log';
const TASKS = 'checklist_tasks';

/** One user + their most-urgent task that's due inside the reminder window. */
export interface ReminderCandidate {
  user: UserRow;
  task: TaskRow;
}

/**
 * Find every active (non-opted-out) user with at least one pending task, and
 * return ONE candidate per user: their NEXT pending task — the one with the
 * nearest due_date (undated tasks rank last). This drives the daily reminder —
 * each user is nudged about the first thing still on their checklist, with no
 * due-date window. When `phone` is given (test mode), restricts to that single
 * user so a test never messages anyone else.
 */
export async function findNextPendingCandidates(phone?: string): Promise<ReminderCandidate[]> {
  let query = getSupabase()
    .from(TASKS)
    .select('*, users!inner(*)')
    .eq('status', 'pending')
    .eq('users.reminders_opt_out', false)
    // Order by due_date, then sort_order as the tiebreaker so that when several
    // tasks share a due_date (common — whole phases land on the same day) we pick
    // the SAME "next" task the conversation shows (checklist order). Without the
    // sort_order tiebreak Postgres returns an arbitrary tied row, so the reminder
    // and the in-chat next-task suggestion could disagree.
    .order('due_date', { ascending: true, nullsFirst: false })
    .order('sort_order', { ascending: true, nullsFirst: false })
    .order('task_key', { ascending: true });
  if (phone) query = query.eq('users.phone', phone);

  const { data, error } = await query;
  if (error) throw error;

  // Group by user, keeping the first (nearest due_date) pending task per user.
  const byUser = new Map<string, ReminderCandidate>();
  for (const row of (data as Array<TaskRow & { users: UserRow }>) ?? []) {
    const { users: user, ...task } = row;
    if (!byUser.has(user.id)) byUser.set(user.id, { user, task: task as TaskRow });
  }
  return [...byUser.values()];
}

export async function getLast(userId: string, reminderKey: string): Promise<ReminderLogRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .eq('reminder_key', reminderKey)
    .maybeSingle();
  if (error) throw error;
  return (data as ReminderLogRow | null) ?? null;
}

/** Record that a reminder was sent now (max-1/day is also enforced by jobId). */
export async function record(userId: string, reminderKey: string): Promise<void> {
  const { error } = await getSupabase()
    .from(TABLE)
    .upsert(
      { user_id: userId, reminder_key: reminderKey, last_reminder_at: new Date().toISOString() },
      { onConflict: 'user_id,reminder_key' },
    );
  if (error) throw error;
}

/**
 * ATOMICALLY claim today's reminder slot for a user — returns true only to the
 * ONE caller that wins it, false to everyone else (already claimed today). This is
 * the real "max 1 reminder/day" guarantee: the previous check-then-send had a race
 * window where concurrent jobs (overlapping scans, BullMQ retries after a partial
 * failure) all passed the read before any wrote, firing the same reminder 2–3×.
 *
 * `expectedLastAt` is the caller's last-seen value (from getLast). The claim is an
 * optimistic compare-and-set: it only succeeds if the row is still unchanged, so a
 * concurrent winner makes the loser's write match zero rows. When there's no row
 * yet, an insert-if-absent decides the single winner. Call AFTER a same-day check
 * via getLast; this closes the concurrency gap that check leaves open.
 */
export async function claimDaily(
  userId: string,
  reminderKey: string,
  expectedLastAt: string | null,
): Promise<boolean> {
  const sb = getSupabase();
  const nowISO = new Date().toISOString();

  if (expectedLastAt === null) {
    // No row yet → the row we manage to insert is the claim; a concurrent insert
    // hits the unique constraint and is ignored (we get zero rows back → we lost).
    const { data, error } = await sb
      .from(TABLE)
      .upsert(
        { user_id: userId, reminder_key: reminderKey, last_reminder_at: nowISO },
        { onConflict: 'user_id,reminder_key', ignoreDuplicates: true },
      )
      .select();
    if (error) throw error;
    return (data?.length ?? 0) > 0;
  }

  // Row exists → compare-and-set: only the caller whose expectedLastAt still
  // matches the stored value updates a row; the other matches nothing.
  const { data, error } = await sb
    .from(TABLE)
    .update({ last_reminder_at: nowISO })
    .eq('user_id', userId)
    .eq('reminder_key', reminderKey)
    .eq('last_reminder_at', expectedLastAt)
    .select();
  if (error) throw error;
  return (data?.length ?? 0) > 0;
}
