import { getSupabase } from '../services/supabase.service.js';
import type { AffiliateFlagRow } from '../types/db.js';

const TABLE = 'affiliate_flags';

export async function get(userId: string, offerKey: string): Promise<AffiliateFlagRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .eq('offer_key', offerKey)
    .maybeSingle();
  if (error) throw error;
  return (data as AffiliateFlagRow | null) ?? null;
}

/** All offer flags for a user (used to find the last shown offer on a decline). */
export async function listByUser(userId: string): Promise<AffiliateFlagRow[]> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId);
  if (error) throw error;
  return (data as AffiliateFlagRow[]) ?? [];
}

/** Has this user EVER received the one-time disclosure (across any offer)? */
export async function disclosureEverSent(userId: string): Promise<boolean> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('user_id')
    .eq('user_id', userId)
    .eq('disclosure_sent', true)
    .limit(1);
  if (error) throw error;
  return (data?.length ?? 0) > 0;
}

/** Upsert a single offer's flags (patch is merged onto any existing row). */
export async function upsert(
  userId: string,
  offerKey: string,
  patch: Partial<Omit<AffiliateFlagRow, 'user_id' | 'offer_key' | 'updated_at'>>,
): Promise<void> {
  const { error } = await getSupabase()
    .from(TABLE)
    .upsert(
      { user_id: userId, offer_key: offerKey, ...patch },
      { onConflict: 'user_id,offer_key' },
    );
  if (error) throw error;
}
