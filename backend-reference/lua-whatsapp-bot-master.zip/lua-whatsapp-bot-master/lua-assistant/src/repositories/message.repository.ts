import { getSupabase } from '../services/supabase.service.js';
import type { MessageRole, MessageRow } from '../types/db.js';

const TABLE = 'messages';

export interface InsertMessageInput {
  userId: string;
  role: MessageRole;
  content: string;
  /** Provider message id (Bird): inbound id for dedupe, or our outbound id. */
  messageId?: string | null;
  /** Initial delivery status for outbound messages (e.g. 'accepted'). */
  status?: string | null;
  /** Mark this assistant message as a commercial offer (1-in-5 guard input). */
  commercial?: boolean;
}

export interface InsertResult {
  /** false when an inbound message_id already existed (idempotent drop). */
  inserted: boolean;
  row: MessageRow | null;
}

/**
 * Insert a message. Inbound messages carry a unique `message_id`; if it already
 * exists we treat the insert as a no-op (`inserted: false`) so the webhook can
 * drop duplicates silently. Outbound (no message_id) always inserts.
 */
export async function insert(input: InsertMessageInput): Promise<InsertResult> {
  const sb = getSupabase();
  const record = {
    user_id: input.userId,
    role: input.role,
    content: input.content,
    message_id: input.messageId ?? null,
    status: input.status ?? null,
    commercial: input.commercial ?? false,
  };

  if (record.message_id) {
    // Dedupe on the unique message_id; ignoreDuplicates → empty data on conflict.
    const { data, error } = await sb
      .from(TABLE)
      .upsert(record, { onConflict: 'message_id', ignoreDuplicates: true })
      .select('*');
    if (error) throw error;
    const row = (data?.[0] as MessageRow | undefined) ?? null;
    return { inserted: row !== null, row };
  }

  const { data, error } = await sb.from(TABLE).insert(record).select('*').single();
  if (error) throw error;
  return { inserted: true, row: data as MessageRow };
}

/**
 * Update the delivery status of an outbound message by its Bird message id.
 * Returns true if a row matched (false = status arrived before our insert, or
 * for a message we didn't record — caller decides how to log).
 */
export async function updateStatusByProviderId(
  messageId: string,
  status: string,
  reason: string | null,
): Promise<boolean> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .update({ status, status_reason: reason ?? null, status_updated_at: new Date().toISOString() })
    .eq('message_id', messageId)
    .select('id');
  if (error) throw error;
  return (data?.length ?? 0) > 0;
}

/** Total number of stored messages for a user (used for summary cadence). */
export async function countByUser(userId: string): Promise<number> {
  const { count, error } = await getSupabase()
    .from(TABLE)
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId);
  if (error) throw error;
  return count ?? 0;
}

/**
 * Count commercial (offer) messages among the user's most recent N assistant
 * messages — the input to the 1-in-5 affiliate guard (monetization.md §Frequency).
 */
export async function countRecentCommercial(userId: string, n: number): Promise<number> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('commercial')
    .eq('user_id', userId)
    .eq('role', 'assistant')
    .order('created_at', { ascending: false })
    .limit(n);
  if (error) throw error;
  return ((data as Array<{ commercial: boolean }>) ?? []).filter((m) => m.commercial).length;
}

/** Last N messages for a user, returned oldest → newest for prompt assembly. */
export async function getRecent(userId: string, n: number): Promise<MessageRow[]> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(n);
  if (error) throw error;
  return ((data as MessageRow[]) ?? []).reverse();
}
