import { getSupabase } from '../services/supabase.service.js';
import type { SessionMetadataRow } from '../types/db.js';

const TABLE = 'session_metadata';

export async function get(userId: string): Promise<SessionMetadataRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return (data as SessionMetadataRow | null) ?? null;
}

/** Stamp last activity = now (called on each inbound → drives the 24h window). */
export async function touch(userId: string): Promise<void> {
  const { error } = await getSupabase()
    .from(TABLE)
    .upsert(
      { user_id: userId, last_activity_at: new Date().toISOString() },
      { onConflict: 'user_id' },
    );
  if (error) throw error;
}
