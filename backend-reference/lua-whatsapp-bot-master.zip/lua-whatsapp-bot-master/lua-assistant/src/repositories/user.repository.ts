import { randomBytes } from 'node:crypto';
import { getSupabase } from '../services/supabase.service.js';
import type { UserRow } from '../types/db.js';

const TABLE = 'users';

/** Unguessable, URL-safe token for the public task-list page. */
function newTasklistToken(): string {
  return randomBytes(24).toString('base64url');
}

export async function getById(id: string): Promise<UserRow | null> {
  const { data, error } = await getSupabase().from(TABLE).select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return (data as UserRow | null) ?? null;
}

/** Look up a user by their public tasklist token (the web page's only key). */
export async function getByTasklistToken(token: string): Promise<UserRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('tasklist_token', token)
    .maybeSingle();
  if (error) throw error;
  return (data as UserRow | null) ?? null;
}

export async function getByPhone(phone: string): Promise<UserRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('phone', phone)
    .maybeSingle();
  if (error) throw error;
  return (data as UserRow | null) ?? null;
}

export async function createFromPhone(phone: string): Promise<UserRow> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .insert({ phone, tasklist_token: newTasklistToken() })
    .select('*')
    .single();
  if (error) throw error;
  return data as UserRow;
}

/**
 * Get the user for a phone number, creating the row on first contact — in a
 * SINGLE round-trip via the get_or_create_user SQL function (migrations/0010).
 * The function does an atomic upsert: it inserts a new row, or on conflict returns
 * the existing one unchanged (it never overwrites tasklist_token). This halves the
 * first-message latency (was lookup-miss + insert) and is race-safe by construction
 * — no read-then-write window. The generated token is used only if a row is
 * actually inserted.
 */
export async function getOrCreateByPhone(phone: string): Promise<UserRow> {
  const { data, error } = await getSupabase().rpc('get_or_create_user', {
    p_phone: phone,
    p_token: newTasklistToken(),
  });
  if (error) throw error;
  // `returns users` yields the row object; tolerate an array shape across versions.
  const row = (Array.isArray(data) ? data[0] : data) as UserRow | null;
  if (!row) throw new Error('get_or_create_user returned no row');
  return row;
}

export async function update(id: string, patch: Partial<UserRow>): Promise<UserRow> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .update(patch)
    .eq('id', id)
    .select('*')
    .single();
  if (error) throw error;
  return data as UserRow;
}

/**
 * Set or clear the crisis pause (migrations/0004). `paused=true` stamps now;
 * `false` clears it. Returns the fresh user so the caller stays in sync.
 */
export async function setSafetyPause(id: string, paused: boolean): Promise<UserRow> {
  return update(id, { safety_paused_at: paused ? new Date().toISOString() : null });
}
