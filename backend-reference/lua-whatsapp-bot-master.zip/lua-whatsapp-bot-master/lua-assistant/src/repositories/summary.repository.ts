import { getSupabase } from '../services/supabase.service.js';

const TABLE = 'conversation_summaries';

export interface SummaryRow {
  user_id: string;
  summary: string;
  summarized_up_to: string | null;
  updated_at: string;
}

export async function get(userId: string): Promise<SummaryRow | null> {
  const { data, error } = await getSupabase()
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return (data as SummaryRow | null) ?? null;
}

export async function upsert(
  userId: string,
  summary: string,
  summarizedUpTo: string,
): Promise<void> {
  const { error } = await getSupabase()
    .from(TABLE)
    .upsert(
      { user_id: userId, summary, summarized_up_to: summarizedUpTo },
      { onConflict: 'user_id' },
    );
  if (error) throw error;
}
