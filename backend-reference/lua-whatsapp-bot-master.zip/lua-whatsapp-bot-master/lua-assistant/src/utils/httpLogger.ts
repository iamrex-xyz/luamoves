import type { NextFunction, Request, Response } from 'express';
import { logger } from './logger.js';
import { newReqId, runWithContext } from './requestContext.js';

/**
 * Per-request access log + correlation id.
 *
 * - Assigns a `reqId` (honouring an inbound `x-request-id`) and echoes it back.
 * - Runs the rest of the request inside the request context, so every log line
 *   it triggers (incl. async webhook processing) carries the same `reqId`.
 * - Emits one structured line per request on completion (method/path/status/ms).
 */
export function httpLogger(req: Request, res: Response, next: NextFunction): void {
  const reqId = (req.headers['x-request-id'] as string) || newReqId();
  res.setHeader('x-request-id', reqId);

  const start = process.hrtime.bigint();
  // reqId captured in the closure — `finish` listeners don't reliably inherit
  // the async context, so we pass it explicitly here.
  res.on('finish', () => {
    const durationMs = Math.round(Number(process.hrtime.bigint() - start) / 1e6);
    logger.info(
      { reqId, method: req.method, path: req.path, status: res.statusCode, durationMs },
      'request',
    );
  });

  runWithContext({ reqId }, () => next());
}
