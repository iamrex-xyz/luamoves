import pino, { type Logger } from 'pino';
import { config } from '../config/index.js';
import { getContext } from './requestContext.js';

// Pretty in dev, JSON otherwise — overridable with LOG_FORMAT (json|pretty).
// JSON output is what lets Loki/Grafana parse fields (level, msg, reqId, ...).
const usePretty =
  config.LOG_FORMAT === 'pretty' ||
  (config.LOG_FORMAT !== 'json' && config.NODE_ENV !== 'production');

/**
 * Error serializer with full detail: standard stack/message plus the fields
 * that actually matter for our failures — AI SDK (statusCode/url/responseBody)
 * and Supabase/Postgres (code/details/hint). responseBody is truncated.
 */
function errSerializer(err: unknown): unknown {
  if (!(err instanceof Error)) return err;
  const base = pino.stdSerializers.err(err) as unknown as Record<string, unknown>;
  const e = err as unknown as Record<string, unknown>;
  if (e.statusCode != null) base.statusCode = e.statusCode;
  if (e.url) base.url = e.url;
  if (e.responseBody) base.responseBody = String(e.responseBody).slice(0, 1000);
  if (e.code != null) base.code = e.code;
  if (e.details) base.details = e.details;
  if (e.hint) base.hint = e.hint;
  return base;
}

export const logger: Logger = pino({
  level: config.LOG_LEVEL,
  base: { service: 'lua-assistant' },
  // Word-level ("info"/"error") instead of pino's numeric code, for clean queries.
  formatters: { level: (label) => ({ level: label }) },
  serializers: { err: errSerializer },
  // Never log secrets, regardless of where they appear in a log object.
  redact: {
    paths: [
      'authorization',
      'req.headers.authorization',
      'headers.authorization',
      'apiKey',
      'signingKey',
      'password',
      'token',
      '*.authorization',
      '*.apiKey',
      '*.signingKey',
      '*.password',
      '*.token',
    ],
    censor: '[redacted]',
  },
  // Auto-attach the per-request context (reqId/userId) to every log line.
  mixin() {
    const ctx = getContext();
    if (!ctx) return {};
    return ctx.userId ? { reqId: ctx.reqId, userId: ctx.userId } : { reqId: ctx.reqId };
  },
  ...(usePretty
    ? {
        transport: {
          target: 'pino-pretty',
          options: { colorize: true, translateTime: 'SYS:HH:MM:ss', ignore: 'pid,hostname' },
        },
      }
    : {}),
});

/**
 * Create a child logger bound to a context (e.g. a feature). The per-request
 * reqId/userId are still injected automatically via the mixin above.
 */
export function childLogger(bindings: Record<string, unknown>): Logger {
  return logger.child(bindings);
}
