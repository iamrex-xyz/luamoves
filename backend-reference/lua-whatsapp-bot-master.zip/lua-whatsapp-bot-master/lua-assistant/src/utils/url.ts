/** URL helpers. */

import { config } from '../config/index.js';

/**
 * Collapse an accidentally doubled scheme, e.g. "https://https://example.com" →
 * "https://example.com". This happens when a base-URL env var already includes
 * the scheme but a template prepends "https://" again (the checklist link bug).
 * Leaves a correct single-scheme URL untouched.
 */
export function fixDoubledScheme(url: string): string {
  return url.replace(/^(https?:\/\/)(?:https?:\/\/)+/i, '$1');
}

/**
 * The user's personal tasklist URL. Uses the configured frontend URL (Lovable)
 * when set, otherwise falls back to our own server-rendered page. Shared by the
 * onboarding summary and the daily reminder template so the link is always built
 * the same way (and always run through fixDoubledScheme).
 */
export function buildTasklistUrl(token: string): string {
  return fixDoubledScheme(
    config.FRONTEND_TASKLIST_URL
      ? config.FRONTEND_TASKLIST_URL.replace('{token}', token)
      : `${config.PUBLIC_BASE_URL}/tasklist/${token}`,
  );
}
