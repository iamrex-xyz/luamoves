import type { Request, RequestHandler, Response } from 'express';
import { config } from '../config/index.js';

/**
 * Minimal CORS for the browser frontend (Lovable) → backend API. The frontend is
 * served from a different origin, so the browser needs these headers to call our
 * /api/* endpoints. Auth is the unguessable tasklist token (no cookies), so '*'
 * is acceptable; CORS_ORIGINS can pin it to the Lovable origin for production.
 *
 * Handles the preflight OPTIONS that a PATCH + JSON request triggers.
 */
const allowList = config.CORS_ORIGINS.split(',').map((o) => o.trim()).filter(Boolean);
const allowAll = config.CORS_ORIGINS.trim() === '*';

export const cors: RequestHandler = (req: Request, res: Response, next) => {
  const origin = req.headers.origin;
  if (allowAll) {
    res.setHeader('Access-Control-Allow-Origin', '*');
  } else if (origin && allowList.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,PATCH,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,ngrok-skip-browser-warning');
  res.setHeader('Access-Control-Max-Age', '86400');

  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }
  next();
};
