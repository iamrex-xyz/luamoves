import { logger } from './logger.js';
import { getSpans, recordSpan } from './requestContext.js';

const log = logger.child({ util: 'timing' });

/** Round to one decimal — enough precision for ms without log noise. */
function round1(ms: number): number {
  return Math.round(ms * 10) / 10;
}

/** Elapsed ms (one decimal) since an hrtime.bigint() mark. */
export function msSince(startNs: bigint): number {
  return round1(Number(process.hrtime.bigint() - startNs) / 1e6);
}

export interface TimeOptions {
  /** Extra structured fields to attach to the span log line (e.g. tokens, rows). */
  meta?: Record<string, unknown>;
  /** Level for the per-span line on success (default 'debug'). The breakdown
   *  summary is always 'info', so prod can stay at info and still see totals. */
  level?: 'debug' | 'info';
}

/**
 * Time an async operation. Emits one structured `span` line
 * ({ span, durationMs, ok }) — queryable in Loki/Grafana — and records the span
 * into the current request context so `inboundBreakdown()` can summarise it.
 *
 * Use at any boundary you want to measure (DB query, external API, a pipeline
 * stage). Recording happens regardless of log level, so the breakdown summary
 * is complete even when per-span debug lines are filtered out in production.
 */
export async function time<T>(
  span: string,
  fn: () => Promise<T>,
  opts: TimeOptions = {},
): Promise<T> {
  const startNs = process.hrtime.bigint();
  try {
    const result = await fn();
    const durationMs = msSince(startNs);
    recordSpan({ span, durationMs, ok: true });
    log[opts.level ?? 'debug']({ span, durationMs, ok: true, ...opts.meta }, 'span');
    return result;
  } catch (err) {
    const durationMs = msSince(startNs);
    recordSpan({ span, durationMs, ok: false });
    log.warn({ span, durationMs, ok: false, err, ...opts.meta }, 'span failed');
    throw err;
  }
}

/** Manually record a span you timed yourself (e.g. inside a service that already
 *  logs its own rich line and just wants the breakdown to include it). */
export function noteSpan(span: string, durationMs: number, ok = true): void {
  recordSpan({ span, durationMs: round1(durationMs), ok });
}

export interface Breakdown {
  /** Sum of all recorded span durations (NOT wall-clock — parallel spans overlap). */
  trackedMs: number;
  /** Per-span total ms (summed if a span ran more than once). */
  spans: Record<string, number>;
  /** Per-span call count (only included for spans that ran more than once). */
  counts: Record<string, number>;
}

/**
 * Aggregate the spans recorded on the current request into a compact breakdown,
 * suitable for a single summary log line. `trackedMs` overcounts parallel work
 * (spans inside a Promise.all overlap), so compare individual spans against the
 * wall-clock total to spot the real bottleneck.
 */
export function inboundBreakdown(): Breakdown {
  const spans: Record<string, number> = {};
  const counts: Record<string, number> = {};
  for (const s of getSpans()) {
    spans[s.span] = round1((spans[s.span] ?? 0) + s.durationMs);
    counts[s.span] = (counts[s.span] ?? 0) + 1;
  }
  const trackedMs = round1(Object.values(spans).reduce((a, b) => a + b, 0));
  const repeated: Record<string, number> = {};
  for (const [k, v] of Object.entries(counts)) if (v > 1) repeated[k] = v;
  return { trackedMs, spans, counts: repeated };
}
