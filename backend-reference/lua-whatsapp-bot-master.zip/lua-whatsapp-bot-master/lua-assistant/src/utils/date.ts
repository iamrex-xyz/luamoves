/** Small date helpers shared across features. All arithmetic is UTC-based on
 *  yyyy-mm-dd strings, so it's free of local-time/DST drift. */

/** Today's date in the given IANA timezone, as yyyy-mm-dd. */
export function todayInTz(tz: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date());
}

/** Add `offsetDays` to an ISO yyyy-mm-dd date, returning ISO yyyy-mm-dd (UTC). */
export function addDays(isoDate: string, offsetDays: number): string {
  const d = new Date(`${isoDate}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

/** True if `s` is a real calendar date in strict ISO yyyy-mm-dd form. */
export function isISODate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}
