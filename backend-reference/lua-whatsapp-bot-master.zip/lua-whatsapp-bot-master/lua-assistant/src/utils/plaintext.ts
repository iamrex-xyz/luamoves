/**
 * Convert (possibly markdown-y) text into clean plain text for WhatsApp.
 *
 * WhatsApp messages are plain text — markdown is not rendered, so leaking it
 * looks broken. This strips the common constructs an LLM might emit while
 * preserving the readable content and line structure.
 *
 * Deliberately conservative: it removes markup, never the words.
 */
export function toPlainText(input: string): string {
  let text = input.replace(/\r\n/g, '\n');

  // Fenced code blocks ``` ``` → keep inner content, drop the fences.
  text = text.replace(/```[a-zA-Z0-9]*\n?([\s\S]*?)```/g, (_m, code: string) => code.trim());

  // Images ![alt](url) → alt text.
  text = text.replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1');
  // Links [text](url) → text.
  text = text.replace(/\[([^\]]+)\]\([^)]*\)/g, '$1');

  // Headings: drop leading #'s.
  text = text.replace(/^\s{0,3}#{1,6}\s+/gm, '');

  // Blockquotes: drop leading '>'.
  text = text.replace(/^\s{0,3}>\s?/gm, '');

  // Bold/italic/strikethrough emphasis markers: **x** __x__ *x* _x_ ~~x~~.
  text = text.replace(/(\*\*|__)(.*?)\1/g, '$2');
  text = text.replace(/(\*|_)(.*?)\1/g, '$2');
  text = text.replace(/~~(.*?)~~/g, '$1');

  // Inline code `x` → x.
  text = text.replace(/`([^`]+)`/g, '$1');

  // Bullet list markers (-, *, +) → "• "; keep the item text.
  text = text.replace(/^\s{0,3}[-*+]\s+/gm, '• ');

  // Ordered list markers "1." stay as-is (they read fine), just normalise space.

  // Horizontal rules (---, ***, ___) on their own line → remove.
  text = text.replace(/^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/gm, '');

  // Collapse 3+ blank lines to a single blank line; trim trailing spaces.
  text = text.replace(/[ \t]+$/gm, '');
  text = text.replace(/\n{3,}/g, '\n\n');

  return text.trim();
}
