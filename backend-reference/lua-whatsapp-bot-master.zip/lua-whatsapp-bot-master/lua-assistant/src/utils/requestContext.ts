import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';

/**
 * Per-request context propagated via AsyncLocalStorage, so every log line
 * emitted while handling one inbound message automatically carries the same
 * `reqId` (and `userId` once known) — without threading a logger through every
 * function. The logger reads this via its `mixin` (see logger.ts).
 */
/** One timed operation recorded during a request (see utils/timing.ts). */
export interface SpanRecord {
  span: string;
  durationMs: number;
  ok: boolean;
}

export interface RequestContext {
  reqId: string;
  userId?: string;
  /** Latency spans accumulated while handling this request (for the breakdown). */
  spans?: SpanRecord[];
}

const storage = new AsyncLocalStorage<RequestContext>();

export function newReqId(): string {
  return randomUUID();
}

/** Run `fn` within a context; everything it (a)synchronously triggers inherits it. */
export function runWithContext<T>(ctx: RequestContext, fn: () => T): T {
  return storage.run(ctx, fn);
}

export function getContext(): RequestContext | undefined {
  return storage.getStore();
}

/** Attach the resolved userId to the current context (no-op if outside one). */
export function setUserId(userId: string): void {
  const ctx = storage.getStore();
  if (ctx) ctx.userId = userId;
}

/** Record a timed span on the current context (no-op if outside one). */
export function recordSpan(record: SpanRecord): void {
  const ctx = storage.getStore();
  if (!ctx) return;
  (ctx.spans ??= []).push(record);
}

/** All spans recorded so far on the current request (empty if outside one). */
export function getSpans(): SpanRecord[] {
  return storage.getStore()?.spans ?? [];
}
