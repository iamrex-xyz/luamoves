/** Language helpers for session-language detection + locking. */

/**
 * Fast, LLM-free language guess for the VERY FIRST message, so we can send the
 * fixed welcome instantly in the right language. Distinctive Dutch vs English
 * markers (greetings + common function words); whichever scores higher wins, ties
 * and unknowns default to Dutch (Dutch-first product). It only needs to be roughly
 * right: from the user's NEXT message the adaptive detector takes over and
 * corrects any wrong guess. Ambiguous tokens ("hey", "is") are in neither list.
 */
const NL_MARKERS = new Set([
  'hoi', 'hallo', 'hé', 'hey', 'haai', 'goedemorgen', 'goedemiddag', 'goedenavond',
  'ik', 'je', 'jij', 'mijn', 'naam', 'wat', 'hoe', 'ben', 'het', 'een', 'de', 'en',
  'ga', 'gaan', 'verhuizen', 'verhuis', 'hulp', 'alsjeblieft', 'dank', 'bedankt',
  'ja', 'nee', 'graag', 'even', 'wil', 'kan', 'met', 'voor', 'niet',
]);
const EN_MARKERS = new Set([
  'hi', 'hello', 'hiya', 'my', 'name', 'what', 'how', 'am', 'im', "i'm", 'the',
  'you', 'your', 'moving', 'move', 'help', 'please', 'thanks', 'thank', 'yes',
  'no', 'good', 'morning', 'want', 'can', 'with', 'for', 'not', "what's", 'are',
]);

export function guessLanguage(text: string): 'nl' | 'en' {
  const tokens = text.toLowerCase().match(/[a-zà-ÿ']+/g) ?? [];
  let nl = 0;
  let en = 0;
  for (const t of tokens) {
    if (NL_MARKERS.has(t)) nl += 1;
    if (EN_MARKERS.has(t)) en += 1;
  }
  return en > nl ? 'en' : 'nl';
}

/**
 * Normalise an LLM-proposed language code to a clean ISO 639-1 (2-letter) code,
 * or null if it isn't a plausible code. Guards against the model returning a full
 * name ("Dutch"), a locale ("nl-NL"), or junk.
 */
export function normalizeLanguageCode(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const code = raw.trim().toLowerCase().slice(0, 2);
  return /^[a-z]{2}$/.test(code) ? code : null;
}

/**
 * The language used MOST across a rolling window of recently detected codes
 * (oldest → newest). Ties are broken by recency — the language seen most recently
 * among the tied winners wins, so the conversation drifts toward the user's
 * current language rather than sticking to a stale one. Returns null for an empty
 * window. Junk codes are ignored (already normalised on the way in).
 */
export function majorityLanguage(codes: string[]): string | null {
  if (codes.length === 0) return null;
  const counts = new Map<string, number>();
  for (const c of codes) counts.set(c, (counts.get(c) ?? 0) + 1);
  let best: string | null = null;
  let bestCount = 0;
  // Walk newest → oldest so that, on a tie, the more recent language is chosen
  // (it's encountered first with the strict `>` comparison).
  for (let i = codes.length - 1; i >= 0; i--) {
    const c = codes[i];
    if (c === undefined) continue;
    const n = counts.get(c) ?? 0;
    if (n > bestCount) {
      best = c;
      bestCount = n;
    }
  }
  return best;
}

/**
 * Human-readable English name for a language code (e.g. "nl" → "Dutch"), used in
 * the prompt directive. Falls back to the raw code if the runtime can't resolve it.
 */
export function languageName(code: string): string {
  try {
    const dn = new Intl.DisplayNames(['en'], { type: 'language' });
    return dn.of(code) ?? code;
  } catch {
    return code;
  }
}
