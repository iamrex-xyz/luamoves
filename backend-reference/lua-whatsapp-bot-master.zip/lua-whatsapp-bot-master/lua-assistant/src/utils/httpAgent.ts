import { Agent, setGlobalDispatcher } from 'undici';
import { config } from '../config/index.js';
import { logger } from './logger.js';

const log = logger.child({ util: 'httpAgent' });

/**
 * Install a process-wide keep-alive connection pool for ALL outbound fetch()
 * calls — OpenRouter, Bird, and Supabase all go through Node's global fetch
 * (undici), so one global dispatcher covers every external hop.
 *
 * Why: undici's default `keepAliveTimeout` is ~4s, so sockets are closed between
 * human-paced WhatsApp turns and each request re-does DNS + TCP + TLS (the cold
 * ~1.5s we saw on the first call of a turn). Widening the window keeps connections
 * warm so they're reused, shaving connection-setup time off every external call.
 *
 * Reliability: this only affects connection pooling, not request semantics. undici
 * still opens a fresh socket if the server closed an idle one, and existing
 * retries (AI SDK maxRetries) are unchanged. Call once, at process boot.
 */
export function installHttpAgent(): void {
  const keepAliveTimeout = config.HTTP_KEEPALIVE_TIMEOUT_S * 1000;
  setGlobalDispatcher(
    new Agent({
      keepAliveTimeout,
      // Hard ceiling on how long a connection may be kept alive (honours a server's
      // own keep-alive hint up to this max).
      keepAliveMaxTimeout: Math.max(keepAliveTimeout, 600_000),
      // Generous per-origin socket pool; we only talk to a handful of hosts.
      connections: 128,
    }),
  );
  log.info({ keepAliveTimeoutMs: keepAliveTimeout }, 'HTTP keep-alive dispatcher installed');
}
