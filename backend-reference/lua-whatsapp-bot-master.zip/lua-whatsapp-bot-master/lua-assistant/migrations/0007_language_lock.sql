-- Lua — language lock (client requirement, Day 7+).
-- Detect the user's language on first contact, store it in users.language, and
-- LOCK it for the rest of the session so replies never drift to another language.
--   language_locked = false → not yet detected (detect on the next turn)
--   language_locked = true  → fixed; the prompt always replies in users.language
-- (users.language already exists from 0001_init, default 'nl'.)

alter table users
  add column if not exists language_locked boolean not null default false;
