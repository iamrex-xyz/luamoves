-- Lua — crisis-pause state (plan.md §14, Day 5).
-- When the crisis protocol fires we pause the moving flow and resume ONLY when
-- the user explicitly says so (instructions.md). That "explicit resume" spans
-- turns, so it needs persistence: a single nullable timestamp on the user.
--   null      → flow active (normal)
--   timestamp → paused since (set on crisis, cleared on explicit resume)

alter table users
  add column if not exists safety_paused_at timestamptz;
