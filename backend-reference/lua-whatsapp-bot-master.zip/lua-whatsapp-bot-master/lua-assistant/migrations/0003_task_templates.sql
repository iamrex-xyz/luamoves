-- Lua — task_templates seed (plan.md §10, Day 5).
-- A sensible v1 rent/buy master list. Data-driven so the client's canonical list
-- drops straight in later (replace these rows). The table itself is created in
-- 0001_init.sql; this migration only seeds it.
--
-- Columns:
--   task_key          stable id (also used by the WhatsApp "done" path)
--   title             human-readable task (English v1; Dutch when the client delivers it)
--   offset_days       days relative to move_date (negative = before, positive = after)
--   applies_to        filter, evaluated in TS (features/checklist/generate.ts), NOT SQL:
--                       { "move_type": "rent" | "buy" }   omit → applies to both
--                       { "requires": ["children"] | ["pets"] }  household conditions
--   affiliate_trigger offer key matching monetization.md (energy/internet/insurance/
--                     moving_company); null → no commercial offer. Day 6 reads this.
--
-- Idempotent: ON CONFLICT updates every column so re-running re-seeds cleanly.

insert into task_templates (task_key, title, offset_days, applies_to, affiliate_trigger) values
  -- ── Both rent & buy ──────────────────────────────────────────────────────
  ('moving_company',        'Choose a moving company or arrange transport',                  -30, '{}',                          'moving_company'),
  ('home_insurance',        'Arrange home/contents insurance for the new address',            -7, '{}',                          'insurance'),
  ('arrange_energy',        'Arrange energy (gas & electricity) for the new address',         -14, '{}',                          'energy'),
  ('arrange_internet',      'Arrange or transfer internet for the new address',               -14, '{}',                          'internet'),
  ('postnl_forwarding',     'Set up mail forwarding via PostNL (postnl.nl/verhuizen)',         -7, '{}',                          null),
  ('meter_readings',        'Record meter readings (gas, water, electricity) on moving day',    0, '{}',                          null),
  ('municipality_register', 'Register your new address with the municipality (within 5 days)',  5, '{}',                          null),
  ('update_admin_address',  'Update your address with bank, employer and subscriptions',         1, '{}',                          null),

  -- ── Rent only ────────────────────────────────────────────────────────────
  ('give_notice',           'Give notice to your landlord (check your contract for the term)', -45, '{"move_type":"rent"}',       null),
  ('rental_handover',       'Schedule the final inspection / handover with your landlord',      -3, '{"move_type":"rent"}',       null),
  ('deposit_return',        'Arrange the return of your rental deposit',                        14, '{"move_type":"rent"}',       null),

  -- ── Buy only ─────────────────────────────────────────────────────────────
  ('notary_transfer',       'Confirm the transfer (transport) date with your notary',          -7, '{"move_type":"buy"}',        null),
  ('building_insurance',    'Arrange building insurance (opstalverzekering)',                   -7, '{"move_type":"buy"}',        'insurance'),
  ('final_inspection_buy',  'Do the final inspection (oplevering) of your new home',            -1, '{"move_type":"buy"}',        null),

  -- ── Household-conditional ────────────────────────────────────────────────
  ('school_registration',   'Register your children at a new school or childcare',             -21, '{"requires":["children"]}',  null),
  ('pet_transport',         'Arrange transport for your pets on moving day',                    -3, '{"requires":["pets"]}',      null),
  ('pet_registration',      'Update your pet''s chip registration and find a new vet',           7, '{"requires":["pets"]}',      null)
on conflict (task_key) do update set
  title             = excluded.title,
  offset_days       = excluded.offset_days,
  applies_to        = excluded.applies_to,
  affiliate_trigger = excluded.affiliate_trigger;
