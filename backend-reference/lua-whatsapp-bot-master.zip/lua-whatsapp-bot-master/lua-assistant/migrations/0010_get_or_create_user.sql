-- Single-round-trip get-or-create for a user by phone (latency: the new-user path
-- was two calls — lookup-miss + insert, ~181ms; this collapses it to one ~90ms
-- call, and existing users stay one call too).
--
-- Reliability notes:
--   * Atomic: ON CONFLICT handles the race where two first messages arrive at once
--     — exactly one inserts, the other returns the existing row. No try/catch.
--   * Non-destructive: on conflict we do a NO-OP update (set phone to itself) ONLY
--     so RETURNING yields the existing row. We deliberately do NOT write
--     tasklist_token here, so a returning user's checklist URL is never rewritten.
--   * p_token is used only when actually inserting a brand-new row.

create or replace function get_or_create_user(p_phone text, p_token text)
returns users
language sql
as $$
  insert into users (phone, tasklist_token)
  values (p_phone, p_token)
  on conflict (phone) do update set phone = excluded.phone
  returning *;
$$;

grant execute on function get_or_create_user(text, text) to service_role;
