-- Lua — English titles for the master task list.
-- The master list (0006) is the client's Dutch copy. We localise task TITLES so
-- an English-speaking user gets English task names in reminders (template msgs,
-- no LLM) and on the tasklist page. Language is locked at onboarding, so the
-- title is resolved per user at checklist creation (features/checklist/generate.ts).
--
-- Translations are keyed by the Dutch title, so a title shared by the rent and
-- buy lists is translated once. Titles only — explanation/tip stay Dutch for now.
-- Falls back to the Dutch title in code when title_en is null.

alter table task_templates add column if not exists title_en text;

update task_templates set title_en = 'Check your current rental contract'                 where title = 'Check je huidige huurcontract';
update task_templates set title_en = 'Confirm your new rental home'                        where title = 'Nieuwe huurwoning bevestigen';
update task_templates set title_en = 'Take stock of your belongings'                       where title = 'Inventariseer je spullen';
update task_templates set title_en = 'Review your moving schedule & deadlines'             where title = 'Verhuisplanning & deadlines controleren';
update task_templates set title_en = 'Arrange a moving company or helpers'                 where title = 'Verhuisbedrijf of helpers regelen';
update task_templates set title_en = 'Order moving boxes & packing materials'              where title = 'Verhuisdozen & verpakkingsmateriaal bestellen';
update task_templates set title_en = 'Arrange energy for your new address'                 where title = 'Energie voor je nieuwe adres regelen';
update task_templates set title_en = 'Arrange internet for your new address'               where title = 'Internet voor je nieuwe adres regelen';
update task_templates set title_en = 'End or transfer your current energy contract'        where title = 'Huidig energiecontract beëindigen of verhuizen';
update task_templates set title_en = 'End or transfer your current internet subscription'  where title = 'Huidig internetabonnement beëindigen of verhuizen';
update task_templates set title_en = 'Officially cancel your current rental'               where title = 'Huidige huur officieel opzeggen';
update task_templates set title_en = 'Arrange home contents insurance'                     where title = 'Inboedelverzekering regelen';
update task_templates set title_en = 'Check your liability insurance'                      where title = 'Aansprakelijkheidsverzekering checken';
update task_templates set title_en = 'Buy materials for DIY jobs'                          where title = 'Materiaal inkopen voor klussen';
update task_templates set title_en = 'Register your new address with the municipality'     where title = 'Adreswijziging doorgeven aan gemeente';
update task_templates set title_en = 'Set up mail forwarding'                              where title = 'Post doorsturen aanvragen';
update task_templates set title_en = 'Apply for a parking permit'                          where title = 'Parkeervergunning aanvragen';
update task_templates set title_en = 'Update your address with your bank(s)'               where title = 'Adreswijziging doorgeven aan bank(en)';
update task_templates set title_en = 'Update your address with your insurers'              where title = 'Adreswijziging doorgeven aan verzekeraars';
update task_templates set title_en = 'Inform your employer about the move'                 where title = 'Werkgever informeren over verhuizing';
update task_templates set title_en = 'Inform your GP, dentist and pharmacy'               where title = 'Huisarts, tandarts en apotheek informeren';
update task_templates set title_en = 'Check waste collection at your new address'          where title = 'Afvalinzameling nieuw adres checken';
update task_templates set title_en = 'Update your address with subscriptions & webshops'   where title = 'Adreswijziging doorgeven aan abonnementen & webshops';
update task_templates set title_en = 'Inform your vet'                                     where title = 'Dierenarts informeren';
update task_templates set title_en = 'Inform school or childcare'                          where title = 'School of kinderopvang informeren';
update task_templates set title_en = 'Arrange a moving lift'                               where title = 'Verhuislift regelen';
update task_templates set title_en = 'Inspect your new home and take photos'               where title = 'Nieuwe woning inspecteren en foto''s maken';
update task_templates set title_en = 'Prepare the final inspection of your old home'       where title = 'Eindinspectie oude woning voorbereiden';
update task_templates set title_en = 'Plan the cleaning'                                   where title = 'Schoonmaak plannen';
update task_templates set title_en = 'Check internet installation & modem in advance'      where title = 'Internetinstallatie & modem vooraf controleren';
update task_templates set title_en = 'Confirm your moving company or helpers'              where title = 'Verhuisbedrijf of helpers bevestigen';
update task_templates set title_en = 'Keep important items separate'                       where title = 'Belangrijke spullen apart houden';
update task_templates set title_en = 'Prepare a moving-day essentials kit'                 where title = 'Verhuisdag-noodpakket klaarleggen';
update task_templates set title_en = 'Record your meter readings'                          where title = 'Meterstanden vastleggen';
update task_templates set title_en = 'Hand over your old home'                             where title = 'Oplevering oude woning';
update task_templates set title_en = 'Carry out the move'                                  where title = 'Verhuizing uitvoeren';
update task_templates set title_en = 'Check that everything works'                         where title = 'Controleren of alles werkt';
update task_templates set title_en = 'Unpack & organize your boxes'                        where title = 'Dozen uitpakken & organiseren';
update task_templates set title_en = 'Notify other organizations of your move'             where title = 'Verhuizing doorgeven bij overige instanties';
update task_templates set title_en = 'Introduce yourself to your neighbours'              where title = 'Kennismaken met je buren';
update task_templates set title_en = 'Follow up on your deposit refund & final settlement' where title = 'Borgterugbetaling & eindafrekening opvolgen';
update task_templates set title_en = 'Check municipal taxes'                               where title = 'Gemeentelijke belastingen checken';
update task_templates set title_en = 'Leave feedback for the moving company'               where title = 'Feedback achterlaten voor verhuisbedrijf';

-- Buy-only tasks
update task_templates set title_en = 'Sign the preliminary purchase agreement'            where title = 'Voorlopig koopcontract tekenen';
update task_templates set title_en = 'Review the list of movable goods'                    where title = 'Roerende zaken doornemen';
update task_templates set title_en = 'Arrange a structural survey'                         where title = 'Bouwkundige keuring laten uitvoeren';
update task_templates set title_en = 'Choose a mortgage advisor and apply for your mortgage' where title = 'Hypotheekadviseur kiezen en hypotheek aanvragen';
update task_templates set title_en = 'Choose a civil-law notary'                           where title = 'Notaris kiezen';
update task_templates set title_en = 'Upload your mortgage documents'                       where title = 'Hypotheekdocumenten uploaden';
update task_templates set title_en = 'Arrange a property valuation'                         where title = 'Taxatie laten uitvoeren';
update task_templates set title_en = 'Arrange the deposit or bank guarantee'               where title = 'Waarborgsom of bankgarantie regelen';
update task_templates set title_en = 'Take out buildings insurance'                        where title = 'Opstalverzekering afsluiten';
update task_templates set title_en = 'Review the draft deeds from the notary'              where title = 'Conceptaktes van notaris doornemen';
update task_templates set title_en = 'Notary: transfer of the property'                     where title = 'Notaris: levering van de woning';
update task_templates set title_en = 'Check smoke detectors (mandatory)'                    where title = 'Rookmelders checken (verplicht)';
update task_templates set title_en = 'Replace the lock cylinders'                           where title = 'Slotcilinders vervangen';
update task_templates set title_en = 'Check your insurance after the key handover'          where title = 'Verzekeringen controleren na sleuteloverdracht';
update task_templates set title_en = 'Create an overview of your monthly costs'             where title = 'Maandlasten overzicht maken';
update task_templates set title_en = 'Set up a maintenance & reserve fund'                  where title = 'Onderhouds- en reservepot instellen';
update task_templates set title_en = 'Set up mortgage interest deduction'                   where title = 'Hypotheekrenteaftrek instellen';
update task_templates set title_en = 'Review the energy label & check improvement options'  where title = 'Energielabel bekijken & verbeterkansen checken';
