-- Lua — initial schema (plan.md §8).
-- Runs against the client-provided Supabase (Postgres). Idempotent where practical.
-- Service-role access only; RLS is not enabled (we connect with the service key).

create extension if not exists pgcrypto;  -- gen_random_uuid()

-- ---------------------------------------------------------------------------
-- updated_at trigger helper
-- ---------------------------------------------------------------------------
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ---------------------------------------------------------------------------
-- users — the authoritative profile + onboarding state
-- ---------------------------------------------------------------------------
create table if not exists users (
  id              uuid primary key default gen_random_uuid(),
  phone           text not null unique,                 -- E.164, idempotency anchor
  name            text,
  move_date       date,
  move_type       text check (move_type in ('rent', 'buy')),
  from_address    text,
  to_address      text,                                 -- nullable (may be unknown)
  home_type       text,
  household       jsonb,                                -- { adults, children, pets, ... }
  notice_given    boolean not null default false,
  language        text not null default 'nl',
  onboarding_step text not null default 'start',
  tasklist_token  text not null unique,                 -- random, unguessable URL token
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

drop trigger if exists trg_users_updated_at on users;
create trigger trg_users_updated_at before update on users
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------------
-- messages — full conversation log (idempotent on provider message_id)
-- ---------------------------------------------------------------------------
create table if not exists messages (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references users(id) on delete cascade,
  role        text not null check (role in ('user', 'assistant')),
  content     text not null,
  message_id  text unique,                              -- Bird message id; null for our outbound
  created_at  timestamptz not null default now()
);

create index if not exists idx_messages_user_created
  on messages (user_id, created_at);

-- ---------------------------------------------------------------------------
-- conversation_summaries — rolling natural-language summary (one per user)
-- ---------------------------------------------------------------------------
create table if not exists conversation_summaries (
  user_id          uuid primary key references users(id) on delete cascade,
  summary          text not null default '',
  summarized_up_to timestamptz,                         -- last message included in summary
  updated_at       timestamptz not null default now()
);

drop trigger if exists trg_summaries_updated_at on conversation_summaries;
create trigger trg_summaries_updated_at before update on conversation_summaries
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------------
-- checklist_tasks — the personalised moving checklist
-- ---------------------------------------------------------------------------
create table if not exists checklist_tasks (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references users(id) on delete cascade,
  task_key          text not null,
  title             text not null,
  status            text not null default 'pending'
                      check (status in ('pending', 'completed', 'snoozed')),
  due_date          date,
  affiliate_trigger text,                               -- nullable offer key
  completed_via     text check (completed_via in ('whatsapp', 'web')),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (user_id, task_key)
);

create index if not exists idx_tasks_user on checklist_tasks (user_id);

drop trigger if exists trg_tasks_updated_at on checklist_tasks;
create trigger trg_tasks_updated_at before update on checklist_tasks
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------------
-- affiliate_flags — per-offer state for the affiliate guards
-- ---------------------------------------------------------------------------
create table if not exists affiliate_flags (
  user_id         uuid not null references users(id) on delete cascade,
  offer_key       text not null,
  shown           boolean not null default false,
  declined        boolean not null default false,
  disclosure_sent boolean not null default false,       -- one-time per user
  updated_at      timestamptz not null default now(),
  primary key (user_id, offer_key)
);

drop trigger if exists trg_affiliate_updated_at on affiliate_flags;
create trigger trg_affiliate_updated_at before update on affiliate_flags
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------------
-- reminder_log — enforces max 1 reminder/day
-- ---------------------------------------------------------------------------
create table if not exists reminder_log (
  user_id          uuid not null references users(id) on delete cascade,
  reminder_key     text not null,
  last_reminder_at timestamptz not null default now(),
  primary key (user_id, reminder_key)
);

-- ---------------------------------------------------------------------------
-- session_metadata — WhatsApp 24h window tracking
-- ---------------------------------------------------------------------------
create table if not exists session_metadata (
  user_id          uuid primary key references users(id) on delete cascade,
  last_activity_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- task_templates — seed master list (rent/buy), data-driven
-- ---------------------------------------------------------------------------
create table if not exists task_templates (
  task_key          text primary key,
  title             text not null,
  offset_days       integer not null default 0,         -- relative to move_date (+/-)
  applies_to        jsonb not null default '{}'::jsonb,  -- { move_type, home_type, household }
  affiliate_trigger text
);
