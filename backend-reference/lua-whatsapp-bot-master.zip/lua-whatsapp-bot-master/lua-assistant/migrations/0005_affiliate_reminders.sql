-- Lua — affiliate + reminder support (plan.md §11/§12, Day 6).
-- affiliate_flags, reminder_log and session_metadata already exist (0001_init).
-- This migration adds the two columns Day 6 needs:
--   messages.commercial      → marks an assistant message as a commercial offer,
--                              so the 1-in-5 guard can count offers in the last 5.
--   users.reminders_opt_out  → set when the user says "stop"; the reminder scan
--                              skips opted-out users immediately.

alter table messages
  add column if not exists commercial boolean not null default false;

alter table users
  add column if not exists reminders_opt_out boolean not null default false;
