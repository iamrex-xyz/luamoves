-- Lua — delivery status on outbound messages (Bird whatsapp.outbound webhooks).
-- We store the latest delivery status per outbound message so failures are
-- visible without polling Bird. message_id already carries the Bird message id
-- (unique → indexed), which the status webhook references via payload.id.

alter table messages
  add column if not exists status            text,
  add column if not exists status_reason     text,
  add column if not exists status_updated_at timestamptz;
