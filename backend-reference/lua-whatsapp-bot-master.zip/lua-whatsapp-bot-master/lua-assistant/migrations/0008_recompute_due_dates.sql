-- Lua — recompute checklist due dates in ONE atomic call (latency fix).
-- A move-date correction re-dates the whole checklist. Doing that as N serial
-- UPDATEs from the app (one round-trip per task) cost ~8s on 40+ tasks and
-- blocked the reply. This function does it in a single transaction instead.
--
-- Date rule MIRRORS features/checklist/generate.ts (computeDueDate):
--   due = move_date + PHASE_OFFSET_DAYS[phase_order], clamped so it's never
--   before "today" in the app timezone. No move date → null.
-- ⚠️  KEEP THE OFFSETS BELOW IN SYNC with PHASE_OFFSET_DAYS in generate.ts.
--
-- Returns the number of rows whose due_date actually changed (only those are
-- written, so the updated_at trigger doesn't fire on unchanged rows).

create or replace function recompute_due_dates(p_user_id uuid, p_tz text)
returns integer
language plpgsql
as $$
declare
  v_move_date date;
  v_today     date := (now() at time zone p_tz)::date;
  v_updated   integer;
begin
  select move_date into v_move_date from users where id = p_user_id;

  with targets as (
    select
      t.id,
      case
        when v_move_date is null then null
        else greatest(
          v_move_date + (case t.phase_order
            when 1 then -45
            when 2 then -30
            when 3 then -21
            when 4 then -10
            when 5 then -5
            when 6 then 0
            when 7 then 7
            else 0
          end),
          v_today
        )
      end as new_due
    from checklist_tasks t
    where t.user_id = p_user_id
      and t.phase_order is not null
  ),
  upd as (
    update checklist_tasks t
    set due_date = tg.new_due
    from targets tg
    where t.id = tg.id
      and t.due_date is distinct from tg.new_due
    returning 1
  )
  select count(*) into v_updated from upd;

  return coalesce(v_updated, 0);
end;
$$;
