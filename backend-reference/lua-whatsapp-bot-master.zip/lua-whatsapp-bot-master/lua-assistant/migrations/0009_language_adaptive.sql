-- Lua — adaptive session language (replaces the 0007 "lock on first contact,
-- never drift" model). New behaviour (features/language/detect.ts):
--   * reply in the language the user actually writes in;
--   * stay in the language MOSTLY used across the recent messages (so a single
--     mixed-language sentence doesn't flip the reply language);
--   * switch immediately when the user explicitly asks ("reply in English").
--
-- `recent_languages` is a small rolling window of the last few detected ISO 639-1
-- codes (oldest → newest). The backend computes the session language as the
-- majority of this window, and persists the winner in users.language — which is
-- also the language reminders/templates fall back to when there's no live message
-- to read.
--
-- users.language (default 'nl') and users.language_locked (0007) already exist.
-- language_locked is now DEPRECATED — kept for backwards compatibility but no
-- longer read; the adaptive logic supersedes it.

alter table users
  add column if not exists recent_languages text[] not null default '{}';
