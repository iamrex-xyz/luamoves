-- Lua — affiliate link delivery (monetization.md §"How the offer should sound").
-- The offer is a two-turn flow: turn 1 asks "Zal ik je doorsturen?", turn 2 the
-- user accepts. The actual partner link is delivered by the BACKEND on the accept
-- turn (the model never types a URL). This flag marks that the link was actually
-- sent for an offer, so:
--   shown=true, declined=false, link_sent=false → offer is PENDING the user's
--     accept/decline (the accept turn appends the link).
--   link_sent=true → link already delivered; never re-send.

alter table affiliate_flags
  add column if not exists link_sent boolean not null default false;
