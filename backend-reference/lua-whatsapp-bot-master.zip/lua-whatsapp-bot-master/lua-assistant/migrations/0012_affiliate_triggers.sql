-- 0012: wire the full monetization.md partner set onto checklist tasks.
--
-- `task_templates.affiliate_trigger` is the offer key that drives onRadarCandidate
-- (eligibility.ts) — only a pending task carrying a trigger can produce an offer.
-- 0003/0006 set energy / internet / insurance / moving_company; this adds the rest
-- of the active partners from monetization.md (boxes, cleaning, renovation, mortgage,
-- lock, contract cancellation). Idempotent: UPDATE by exact task_key, rent + buy.

-- Moving boxes & packing material → gamma.nl (Commission to confirm)
update task_templates set affiliate_trigger = 'moving_boxes'
 where task_key in (
   'rent_verhuisdozen_verpakkingsmateriaal_bestellen',
   'buy_verhuisdozen_verpakkingsmateriaal_bestellen'
 );

-- Plan the cleaning → werkspot.nl
update task_templates set affiliate_trigger = 'cleaning'
 where task_key in ('rent_schoonmaak_plannen', 'buy_schoonmaak_plannen');

-- Buy materials for DIY / renovation → slimster.nl
update task_templates set affiliate_trigger = 'renovation'
 where task_key in (
   'rent_materiaal_inkopen_voor_klussen',
   'buy_materiaal_inkopen_voor_klussen'
 );

-- Choose a mortgage advisor & apply → ikbenfrits.nl (referral, not advice)
update task_templates set affiliate_trigger = 'mortgage'
 where task_key = 'buy_hypotheekadviseur_kiezen_en_hypotheek_aanvragen';

-- Replace the lock cylinders → werkspot.nl
update task_templates set affiliate_trigger = 'lock'
 where task_key = 'buy_slotcilinders_vervangen';

-- End / transfer current energy & internet contract → 123opzeggen.nl (Commission to confirm)
update task_templates set affiliate_trigger = 'contract_cancellation'
 where task_key in (
   'rent_huidig_energiecontract_beeindigen_of_verhuizen',
   'rent_huidig_internetabonnement_beeindigen_of_verhuize',
   'buy_huidig_energiecontract_beeindigen_of_verhuizen',
   'buy_huidig_internetabonnement_beeindigen_of_verhuize'
 );
