# Logging stack (Loki + Alloy + Grafana)

A lightweight, self-hosted log aggregation stack, kept **separate** from the
app so it can be started/stopped independently with zero impact on the app.

```
app (JSON logs → stdout) → Docker → Alloy (reads docker logs) → Loki → Grafana (UI)
```

## Start / stop

```bash
# start
docker compose -f docker-compose.logging.yml up -d

# stop (the app keeps running — this only stops logging)
docker compose -f docker-compose.logging.yml down

# stop AND delete stored logs
docker compose -f docker-compose.logging.yml down -v
```

Then open Grafana at **http://localhost:3101** (user/pass from `.env`, default
`admin`/`admin`). Loki is pre-wired as the datasource.

> For the app's logs to be parseable, run the app with **`LOG_FORMAT=json`**
> (or `NODE_ENV=production`). Otherwise it prints pretty (colour) logs, which
> Loki stores as plain text (still searchable, just not field-filterable).

## Viewing logs (Grafana → Explore)

Pick the **Loki** datasource, then try:

```logql
# everything from the app
{container="lua-assistant-app-1"}

# only errors (full detail)
{container="lua-assistant-app-1"} | json | level="error"

# delivery failures
{container="lua-assistant-app-1"} | json | msg="WhatsApp delivery FAILED"

# trace one conversation turn end-to-end (after reqId is added in Step A)
{container="lua-assistant-app-1"} | json | reqId="<id>"

# all containers (app + redis + ...)
{job="docker"}
```

Use **Live** (top-right in Explore) to tail logs in real time.

## Resources / retention

- ~350–500 MB RAM total; `mem_limit` caps each service.
- Loki retention: **30 days** default; set `LOKI_RETENTION_PERIOD` in `.env` (e.g. `336h` = 14 days).
- Loki is exposed only on `127.0.0.1:3102` (no auth) for local debugging.

## Production notes

- Pin image tags (`grafana/loki:X.Y.Z`, etc.) instead of `latest`.
- Put Grafana behind the reverse proxy / set a strong `GRAFANA_ADMIN_PASSWORD`.
- Do not expose Loki's 3100 publicly (it has no auth).
