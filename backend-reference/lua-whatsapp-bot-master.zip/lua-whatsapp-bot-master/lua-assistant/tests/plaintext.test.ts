import { describe, it, expect } from 'vitest';
import { toPlainText } from '../src/utils/plaintext.js';

describe('toPlainText', () => {
  it('strips bold and italic markers', () => {
    expect(toPlainText('Hello **world** and _you_')).toBe('Hello world and you');
  });

  it('converts links to their text', () => {
    expect(toPlainText('See [the list](https://lua.nl/x) now')).toBe('See the list now');
  });

  it('drops headings and blockquote markers', () => {
    expect(toPlainText('# Title\n> quoted')).toBe('Title\nquoted');
  });

  it('turns bullet markers into •', () => {
    expect(toPlainText('- one\n- two')).toBe('• one\n• two');
  });

  it('keeps fenced code content without the fences', () => {
    expect(toPlainText('```\nplan\n```')).toBe('plan');
  });

  it('removes inline code backticks', () => {
    expect(toPlainText('run `npm test` ok')).toBe('run npm test ok');
  });

  it('collapses excess blank lines and trims', () => {
    expect(toPlainText('a\n\n\n\nb\n\n')).toBe('a\n\nb');
  });

  it('leaves plain text untouched', () => {
    expect(toPlainText('Gewoon een tekst.')).toBe('Gewoon een tekst.');
  });
});
