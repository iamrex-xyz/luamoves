import { describe, it, expect } from 'vitest';
import {
  selectTasks,
  deriveHousehold,
  dueDateFor,
  computeDueDate,
  PHASE_OFFSET_DAYS,
} from '../src/features/checklist/generate.js';
import { renderChecklistBlock, redactTaskKeys } from '../src/features/checklist/context.js';
import {
  selectCompletionTarget,
  activeTask,
  resolveAndRescheduleTask,
} from '../src/features/checklist/updateStatus.js';
import {
  renderTaskDone,
  renderTaskRescheduled,
  renderTaskRescheduleRejected,
} from '../src/templates/checklist.js';
import type { TaskRow, TaskTemplateRow, UserRow } from '../src/types/db.js';

// A "today" early enough that the August move's phase offsets never clamp.
const TODAY = '2026-06-01';

function tmpl(p: Partial<TaskTemplateRow> = {}): TaskTemplateRow {
  return {
    task_key: 'rent_x', move_type: 'rent', phase_order: 2, phase_name: 'Op tijd vastleggen',
    category: 'Verhuizing', title: 'Taak', title_en: 'Task', explanation: 'uitleg', tip: 'tip',
    condition: 'altijd', affiliate_trigger: null, sort_order: 1, ...p,
  };
}

const TEMPLATES: TaskTemplateRow[] = [
  tmpl({ task_key: 'rent_energy', move_type: 'rent', phase_order: 2, condition: 'altijd', affiliate_trigger: 'energy', sort_order: 1 }),
  tmpl({ task_key: 'rent_notice', move_type: 'rent', phase_order: 3, condition: 'altijd', sort_order: 2 }),
  tmpl({ task_key: 'buy_notary', move_type: 'buy', phase_order: 3, condition: 'altijd', sort_order: 3 }),
  tmpl({ task_key: 'rent_school', move_type: 'rent', phase_order: 4, condition: 'kinderen', sort_order: 4 }),
  tmpl({ task_key: 'rent_vet', move_type: 'rent', phase_order: 4, condition: 'huisdieren', sort_order: 5 }),
  tmpl({ task_key: 'rent_parking', move_type: 'rent', phase_order: 4, condition: 'parkeren', sort_order: 6 }),
  tmpl({ task_key: 'rent_lift', move_type: 'rent', phase_order: 4, condition: 'hoog', sort_order: 7 }),
];

function user(partial: Partial<UserRow> = {}): UserRow {
  return {
    id: 'u1', phone: '+31600000000', name: 'Sam', move_date: '2026-08-01',
    move_type: 'rent', from_address: 'A', to_address: 'B', home_type: 'apartment',
    household: { description: 'alone' }, notice_given: false, language: 'nl', language_locked: false, recent_languages: [],
    onboarding_step: 'completed', tasklist_token: 'tok', safety_paused_at: null,
    reminders_opt_out: false, created_at: '', updated_at: '', ...partial,
  };
}

describe('deriveHousehold', () => {
  it('detects children and pets (en + nl)', () => {
    expect(deriveHousehold({ description: 'partner en 2 kinderen' })).toEqual({ children: true, pets: false });
    expect(deriveHousehold({ description: 'me and my dog' })).toEqual({ children: false, pets: true });
    expect(deriveHousehold({ description: 'alleen' })).toEqual({ children: false, pets: false });
    expect(deriveHousehold(null)).toEqual({ children: false, pets: false });
  });
});

describe('dueDateFor (phase → offset)', () => {
  it('derives due dates from the phase offset relative to move_date', () => {
    expect(dueDateFor(tmpl({ phase_order: 2 }), '2026-08-01', TODAY)).toBe('2026-07-02'); // -30
    expect(dueDateFor(tmpl({ phase_order: 6 }), '2026-08-01', TODAY)).toBe('2026-08-01'); // move day
    expect(dueDateFor(tmpl({ phase_order: 7 }), '2026-08-01', TODAY)).toBe('2026-08-08'); // +7
    expect(dueDateFor(tmpl(), null, TODAY)).toBeNull();
    expect(PHASE_OFFSET_DAYS[1]).toBe(-45);
  });

  it('clamps past due dates to today for a near-term move (bug fix)', () => {
    // Move 6 days out → phase 1 (-45) would land in the PAST; clamp to today.
    expect(computeDueDate(1, '2026-06-15', '2026-06-09')).toBe('2026-06-09');
    expect(computeDueDate(2, '2026-06-15', '2026-06-09')).toBe('2026-06-09');
    // Phases on/after today are untouched.
    expect(computeDueDate(6, '2026-06-15', '2026-06-09')).toBe('2026-06-15');
    expect(computeDueDate(7, '2026-06-15', '2026-06-09')).toBe('2026-06-22');
  });
});

describe('selectTasks', () => {
  it('includes only the matching move type', () => {
    const keys = selectTasks(user({ move_type: 'rent' }), TEMPLATES, TODAY).map((t) => t.task_key);
    expect(keys).toContain('rent_energy');
    expect(keys).not.toContain('buy_notary');
  });

  it('gates kinderen/huisdieren on the household but shows verbouwing/hoog/parkeren to everyone', () => {
    const alone = selectTasks(user({ household: { description: 'alleen' } }), TEMPLATES, TODAY).map((t) => t.task_key);
    expect(alone).not.toContain('rent_school'); // kinderen → no
    expect(alone).not.toContain('rent_vet'); // huisdieren → no
    expect(alone).toContain('rent_parking'); // parkeren → shown to all
    expect(alone).toContain('rent_lift'); // hoog → shown to all

    const family = selectTasks(user({ household: { description: 'partner, kinderen en een hond' } }), TEMPLATES, TODAY).map((t) => t.task_key);
    expect(family).toContain('rent_school');
    expect(family).toContain('rent_vet');
  });

  it('computes due dates from the phase and carries the rich fields', () => {
    const tasks = selectTasks(user({ move_type: 'rent' }), TEMPLATES, TODAY);
    const energy = tasks.find((t) => t.task_key === 'rent_energy')!;
    expect(energy.due_date).toBe('2026-07-02'); // phase 2 → -30
    expect(energy.affiliate_trigger).toBe('energy');
    expect(energy.phase_name).toBe('Op tijd vastleggen');
    expect(energy.category).toBe('Verhuizing');
    expect(energy.sort_order).toBe(1);
  });

  it('leaves due dates null when the move date is unknown', () => {
    const tasks = selectTasks(user({ move_date: null }), TEMPLATES, TODAY);
    expect(tasks.every((t) => t.due_date === null)).toBe(true);
  });

  it('localises the title to the user language at creation (en → title_en, nl → title)', () => {
    const en = selectTasks(user({ language: 'en' }), TEMPLATES, TODAY);
    expect(en.find((t) => t.task_key === 'rent_energy')!.title).toBe('Task');

    const nl = selectTasks(user({ language: 'nl' }), TEMPLATES, TODAY);
    expect(nl.find((t) => t.task_key === 'rent_energy')!.title).toBe('Taak');

    // Falls back to the Dutch title when no English title exists.
    const noEn = [tmpl({ task_key: 'rent_energy', title: 'Taak', title_en: null })];
    expect(selectTasks(user({ language: 'en' }), noEn, TODAY)[0]!.title).toBe('Taak');
  });
});

function task(p: Partial<TaskRow> = {}): TaskRow {
  return {
    id: 'tid', user_id: 'u1', task_key: 'rent_energy', title: 'Energie regelen',
    status: 'pending', due_date: '2026-06-20', affiliate_trigger: null, completed_via: null,
    phase_order: null, phase_name: null, category: null, explanation: null,
    tip: null, sort_order: null, created_at: '', updated_at: '', ...p,
  };
}

describe('renderChecklistBlock', () => {
  const tasks: TaskRow[] = [
    task({ task_key: 'a', title: 'Energie regelen', status: 'completed' }),
    task({ task_key: 'b', title: 'Internet regelen', status: 'completed' }),
    task({ task_key: 'c', title: 'Dozen bestellen', status: 'pending', due_date: '2026-06-18' }),
    task({ task_key: 'd', title: 'Verhuurder informeren', status: 'pending', due_date: '2026-06-25' }),
  ];

  it('states unambiguous counts (done · open · total)', () => {
    expect(renderChecklistBlock(tasks)).toContain('2 afgerond · 2 open · 4 totaal');
  });

  it('lists the completed tasks so the model can answer "which are done"', () => {
    const block = renderChecklistBlock(tasks);
    expect(block).toContain('Afgeronde taken:');
    expect(block).toContain('Energie regelen');
    expect(block).toContain('Internet regelen');
  });

  it('shows pending task_keys for completion but not on done tasks', () => {
    const block = renderChecklistBlock(tasks);
    expect(block).toContain('[c] Dozen bestellen');
    expect(block).not.toContain('[a]'); // completed tasks carry no key
  });

  it('surfaces the current (nearest-due pending) task', () => {
    expect(renderChecklistBlock(tasks)).toContain('Huidige taak: Dozen bestellen');
  });
});

describe('selectCompletionTarget (backend decides WHICH task "done" completes)', () => {
  const tasks: TaskRow[] = [
    task({ task_key: 'a', title: 'Contract', status: 'completed' }),
    task({ task_key: 'c', title: 'Bevestigen', status: 'pending', due_date: '2026-06-18' }),
    task({ task_key: 'd', title: 'Inventariseren', status: 'pending', due_date: '2026-06-25' }),
  ];

  it('returns null without completion intent', () => {
    expect(selectCompletionTarget(tasks, false, null)).toBeNull();
  });

  it('a bare "done" (no key) completes the active = nearest-due pending task', () => {
    const r = selectCompletionTarget(tasks, true, null)!;
    expect(r.target.task_key).toBe('c');
    expect(r.next?.task_key).toBe('d');
  });

  it('an explicitly named pending task is completed', () => {
    expect(selectCompletionTarget(tasks, true, 'd')!.target.task_key).toBe('d');
  });

  it('falls back to the active task when the proposed key is already done (the 3:51 bug)', () => {
    expect(selectCompletionTarget(tasks, true, 'a')!.target.task_key).toBe('c');
  });

  it('falls back to the active task when the proposed key is unknown', () => {
    expect(selectCompletionTarget(tasks, true, 'nope')!.target.task_key).toBe('c');
  });

  it('returns null when nothing is left pending', () => {
    const allDone = [task({ task_key: 'a', status: 'completed' })];
    expect(selectCompletionTarget(allDone, true, null)).toBeNull();
  });

  it('activeTask is the nearest-due pending task', () => {
    expect(activeTask(tasks)?.task_key).toBe('c');
  });
});

describe('renderTaskDone (confirmation matches the task actually marked)', () => {
  it('names the done + next task (nl default)', () => {
    const out = renderTaskDone('Contract checken', 'Woning bevestigen', 'nl');
    expect(out).toContain('"Contract checken"');
    expect(out).toContain('Volgende stap: "Woning bevestigen"');
  });

  it('English when the session language is en', () => {
    const out = renderTaskDone('Check contract', 'Confirm home', 'en');
    expect(out).toContain('"Check contract"');
    expect(out).toContain('Next up: "Confirm home"');
  });

  it('handles the last task (no next)', () => {
    expect(renderTaskDone('Laatste taak', null, 'nl')).toContain('laatste openstaande taak');
    expect(renderTaskDone('Last task', null, 'en')).toContain('last open task');
  });
});

describe('redactTaskKeys (never leak an internal key to the user)', () => {
  const tasks: TaskRow[] = [task({ task_key: 'renthuisarts_informeren', title: 'Huisarts informeren' })];

  it('swaps a leaked bare key for the readable title', () => {
    const out = redactTaskKeys('The next task is renthuisarts_informeren, due soon.', tasks);
    expect(out).toBe('The next task is Huisarts informeren, due soon.');
    expect(out).not.toContain('renthuisarts_informeren');
  });

  it('swaps the bracketed [key] form too', () => {
    expect(redactTaskKeys('Do [renthuisarts_informeren] next.', tasks)).toBe('Do Huisarts informeren next.');
  });

  it('leaves clean text untouched', () => {
    expect(redactTaskKeys('All done, nice work!', tasks)).toBe('All done, nice work!');
  });
});

describe('resolveAndRescheduleTask (change ONE task deadline, never the move date)', () => {
  const TODAY = '2026-06-24';
  const tasks: TaskRow[] = [
    task({ id: 't-c', task_key: 'c', title: 'Dozen bestellen', status: 'pending', due_date: '2026-06-30' }),
    task({ id: 't-a', task_key: 'a', title: 'Energie regelen', status: 'completed' }),
  ];

  it('returns null when there is no reschedule intent', async () => {
    expect(await resolveAndRescheduleTask('u1', tasks, null, null, TODAY)).toBeNull();
    expect(await resolveAndRescheduleTask('u1', tasks, 'c', null, TODAY)).toBeNull();
    expect(await resolveAndRescheduleTask('u1', tasks, null, '2026-07-01', TODAY)).toBeNull();
  });

  it('rejects an unknown / non-pending key without writing', async () => {
    expect(await resolveAndRescheduleTask('u1', tasks, 'nope', '2026-07-01', TODAY))
      .toEqual({ ok: false, reason: 'unknown', task: null });
    // 'a' exists but is already completed → not reschedulable.
    expect(await resolveAndRescheduleTask('u1', tasks, 'a', '2026-07-01', TODAY))
      .toEqual({ ok: false, reason: 'unknown', task: null });
  });

  it('rejects an unparseable date without writing', async () => {
    const r = await resolveAndRescheduleTask('u1', tasks, 'c', 'next week', TODAY);
    expect(r).toMatchObject({ ok: false, reason: 'unclear' });
    expect((r as { task: TaskRow }).task.task_key).toBe('c');
  });

  it('rejects a past date without writing', async () => {
    const r = await resolveAndRescheduleTask('u1', tasks, 'c', '2026-06-01', TODAY);
    expect(r).toMatchObject({ ok: false, reason: 'past' });
  });
});

describe('renderTaskRescheduled / renderTaskRescheduleRejected', () => {
  it('confirms the moved deadline and that nothing else changed (nl + en)', () => {
    const nl = renderTaskRescheduled('Dozen bestellen', '2026-08-16', 'nl');
    expect(nl).toContain('Dozen bestellen');
    expect(nl).toContain('2026-08-16');
    expect(nl).toContain('niets gewijzigd');

    const en = renderTaskRescheduled('Order boxes', '2026-08-16', 'en');
    expect(en).toContain('Order boxes');
    expect(en).toContain('Nothing else changed');
  });

  it('re-asks on a past or unclear date', () => {
    expect(renderTaskRescheduleRejected('Dozen', 'past', '2026-06-24', 'nl')).toContain('al geweest');
    expect(renderTaskRescheduleRejected('Boxes', 'past', '2026-06-24', 'en')).toContain('already passed');
    expect(renderTaskRescheduleRejected('Dozen', 'unclear', '2026-06-24', 'nl')).toContain('geen duidelijke datum');
    expect(renderTaskRescheduleRejected('Boxes', 'unclear', '2026-06-24', 'en')).toContain("didn't catch");
  });
});
