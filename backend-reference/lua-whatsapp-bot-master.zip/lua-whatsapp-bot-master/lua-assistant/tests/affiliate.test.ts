import { describe, it, expect } from 'vitest';
import { decideOffer, passesOneInFive, isDeclined } from '../src/features/affiliate/guards.js';
import { detectTopics, onRadarCandidate, pickPendingOffer } from '../src/features/affiliate/eligibility.js';
import {
  buildLink,
  partnerName,
  partnerDisplayName,
  isCommercial,
  delinkifyPartners,
} from '../src/features/affiliate/links.js';
import { normalizeSignals } from '../src/types/llm.js';
import type { AffiliateFlagRow, TaskRow } from '../src/types/db.js';

function task(partial: Partial<TaskRow>): TaskRow {
  return {
    id: 'tid', user_id: 'u1', task_key: 'k', title: 't', status: 'pending',
    due_date: null, affiliate_trigger: null, completed_via: null,
    phase_order: null, phase_name: null, category: null, explanation: null,
    tip: null, sort_order: null, created_at: '', updated_at: '', ...partial,
  };
}

function flag(partial: Partial<AffiliateFlagRow> = {}): AffiliateFlagRow {
  return { user_id: 'u1', offer_key: 'energy', shown: false, declined: false, disclosure_sent: false, link_sent: false, updated_at: '', ...partial };
}

describe('detectTopics', () => {
  it('maps partner-topic keywords to offers (en + nl)', () => {
    expect(detectTopics('I still need to sort out energie en internet')).toEqual(['energy', 'internet']);
    expect(detectTopics('which verzekering should I get?')).toEqual(['insurance']);
    expect(detectTopics('do you know a good verhuisbedrijf?')).toEqual(['moving_company']);
    expect(detectTopics('what time is the municipality open?')).toEqual([]);
  });
});

describe('onRadarCandidate', () => {
  const tasks = [
    task({ task_key: 'arrange_energy', affiliate_trigger: 'energy', status: 'pending' }),
    task({ task_key: 'arrange_internet', affiliate_trigger: 'internet', status: 'completed' }),
  ];
  it('returns a mentioned topic only when it has a pending triggering task', () => {
    expect(onRadarCandidate(['energy'], tasks)).toBe('energy');
    // internet task is completed → not on radar
    expect(onRadarCandidate(['internet'], tasks)).toBeNull();
    // insurance never mentioned/on list
    expect(onRadarCandidate(['insurance'], tasks)).toBeNull();
  });
});

describe('1-in-5 guard', () => {
  it('allows up to 1 recent commercial, suppresses at 2+', () => {
    expect(passesOneInFive(0)).toBe(true);
    expect(passesOneInFive(1)).toBe(true);
    expect(passesOneInFive(2)).toBe(false);
  });
});

describe('isDeclined', () => {
  it('reflects the sticky decline flag', () => {
    expect(isDeclined(flag({ declined: true }))).toBe(true);
    expect(isDeclined(flag({ declined: false }))).toBe(false);
    expect(isDeclined(null)).toBe(false);
  });
});

describe('decideOffer', () => {
  it('is eligible with a candidate, no decline, and room under 1-in-5', () => {
    expect(decideOffer({ candidate: 'energy', flag: null, recentCommercialCount: 0 })).toEqual({ offer: 'energy', reason: 'eligible' });
  });
  it('suppresses when no trigger', () => {
    expect(decideOffer({ candidate: null, flag: null, recentCommercialCount: 0 }).offer).toBeNull();
  });
  it('suppresses a declined offer', () => {
    expect(decideOffer({ candidate: 'energy', flag: flag({ declined: true }), recentCommercialCount: 0 })).toEqual({ offer: null, reason: 'declined-this-session' });
  });
  it('suppresses under the 1-in-5 guard', () => {
    expect(decideOffer({ candidate: 'energy', flag: null, recentCommercialCount: 2 })).toEqual({ offer: null, reason: 'one-in-five' });
  });
});

describe('pickPendingOffer (the "ja" turn resolves the awaiting offer)', () => {
  it('returns null when nothing is shown', () => {
    expect(pickPendingOffer([])).toBeNull();
    expect(pickPendingOffer([flag({ shown: false })])).toBeNull();
  });
  it('returns a shown, not-declined, not-yet-delivered offer', () => {
    expect(pickPendingOffer([flag({ offer_key: 'moving_company', shown: true })])).toBe('moving_company');
  });
  it('excludes declined and already-delivered offers', () => {
    expect(pickPendingOffer([flag({ shown: true, declined: true })])).toBeNull();
    // link already delivered → no longer pending, never re-send
    expect(pickPendingOffer([flag({ shown: true, link_sent: true })])).toBeNull();
  });
  it('picks the most recently shown offer when several are pending', () => {
    const flags = [
      flag({ offer_key: 'energy', shown: true, updated_at: '2026-06-23T10:00:00Z' }),
      flag({ offer_key: 'moving_boxes', shown: true, updated_at: '2026-06-23T12:00:00Z' }),
    ];
    expect(pickPendingOffer(flags)).toBe('moving_boxes');
  });
});

describe('affiliate accept signal', () => {
  it('normalizes user_accepted (defaults false, preserves true)', () => {
    expect(normalizeSignals({}).affiliate.user_accepted).toBe(false);
    expect(normalizeSignals({ affiliate: { user_accepted: true } }).affiliate.user_accepted).toBe(true);
  });
});

describe('partner display names (brand, no TLD → no WhatsApp auto-link)', () => {
  it('maps offers to brand names without a domain TLD', () => {
    expect(partnerDisplayName('moving_company')).toBe('Verhuisoffertes');
    expect(partnerDisplayName('moving_boxes')).toBe('Gamma');
    expect(partnerDisplayName('energy')).toBe('Overstappen');
    expect(partnerDisplayName('mortgage')).toBe('IkBenFrits');
    // a display name must never itself be a linkifiable domain
    for (const k of ['energy', 'moving_company', 'moving_boxes', 'mortgage'] as const) {
      expect(partnerDisplayName(k)).not.toMatch(/\.(nl|com)\b/);
    }
  });
});

describe('delinkifyPartners (no stray partner URL reaches chat)', () => {
  it('rewrites a bare partner domain to the brand name', () => {
    expect(delinkifyPartners('I work with verhuisoffertes.com — they compare movers.')).toBe(
      'I work with Verhuisoffertes — they compare movers.',
    );
    expect(delinkifyPartners('Bestel je dozen via gamma.nl.')).toBe('Bestel je dozen via Gamma.');
  });
  it('rewrites full/www partner URLs too', () => {
    expect(delinkifyPartners('see https://www.werkspot.nl/cleaners now')).toBe('see Werkspot now');
    expect(delinkifyPartners('www.overstappen.nl')).toBe('Overstappen');
  });
  it('leaves NON-partner referral domains clickable (postnl, government)', () => {
    const t = 'Regel je post via postnl.nl/verhuizen en check mijnoverheid.nl.';
    expect(delinkifyPartners(t)).toBe(t);
  });
  it('leaves ordinary text untouched', () => {
    expect(delinkifyPartners('When are you moving?')).toBe('When are you moving?');
  });
});

describe('links', () => {
  it('maps offers to partner names', () => {
    expect(partnerName('energy')).toBe('overstappen.nl');
    expect(partnerName('moving_company')).toBe('verhuisoffertes.com');
    expect(partnerName('cleaning')).toBe('werkspot.nl');
    expect(partnerName('renovation')).toBe('slimster.nl');
    expect(partnerName('mortgage')).toBe('ikbenfrits.nl');
    expect(partnerName('lock')).toBe('werkspot.nl');
    expect(partnerName('moving_boxes')).toBe('gamma.nl');
    expect(partnerName('contract_cancellation')).toBe('123opzeggen.nl');
  });
  it('flags active affiliates as commercial and "commission to confirm" as not', () => {
    expect(isCommercial('energy')).toBe(true);
    expect(isCommercial('mortgage')).toBe(true);
    // Commission-to-confirm → convenience links, no disclosure.
    expect(isCommercial('moving_boxes')).toBe(false);
    expect(isCommercial('contract_cancellation')).toBe(false);
  });
  it('detects the new partner topics, with cancellation beating energy on "opzeggen"', () => {
    expect(detectTopics('ik wil mijn energiecontract opzeggen')[0]).toBe('contract_cancellation');
    expect(detectTopics('I need to sort a mortgage / hypotheek')).toContain('mortgage');
    expect(detectTopics('waar bestel ik verhuisdozen?')).toContain('moving_boxes');
    expect(detectTopics('can you help me plan the cleaning?')).toContain('cleaning');
    expect(detectTopics('ik moet de slotcilinders vervangen')).toContain('lock');
  });
  it('appends UTM params with the right separator', () => {
    const link = buildLink('energy');
    expect(link).toContain('utm_source=lua');
    expect(link.startsWith('http')).toBe(true);
  });
});
