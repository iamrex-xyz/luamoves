import { describe, it, expect } from 'vitest';
import { daysUntil, renderReminder, renderStopAck } from '../src/templates/reminder.js';
import { stopRequested } from '../src/features/reminders/optOut.js';
import type { TaskRow } from '../src/types/db.js';

function task(partial: Partial<TaskRow> = {}): TaskRow {
  return {
    id: 'tid', user_id: 'u1', task_key: 'municipality_register', title: 'Register at the municipality',
    status: 'pending', due_date: '2026-06-09', affiliate_trigger: null, completed_via: null,
    phase_order: null, phase_name: null, category: null, explanation: null,
    tip: null, sort_order: null, created_at: '', updated_at: '', ...partial,
  };
}

describe('daysUntil', () => {
  it('counts whole UTC days between dates', () => {
    expect(daysUntil('2026-06-09', '2026-06-05')).toBe(4);
    expect(daysUntil('2026-06-05', '2026-06-05')).toBe(0);
    expect(daysUntil('2026-06-04', '2026-06-05')).toBe(-1);
  });
});

describe('renderReminder', () => {
  it('phrases the lead time and includes the stop hint (English default)', () => {
    expect(renderReminder(task(), '2026-06-05')).toContain('In 4 days');
    expect(renderReminder(task({ due_date: '2026-06-06' }), '2026-06-05')).toContain('Tomorrow');
    expect(renderReminder(task({ due_date: '2026-06-05' }), '2026-06-05')).toContain('Due now');
    expect(renderReminder(task(), '2026-06-05').toLowerCase()).toContain('stop');
  });

  it('renders in the stored session language (Dutch)', () => {
    expect(renderReminder(task(), '2026-06-05', 'nl')).toContain('Over 4 dagen');
    expect(renderReminder(task({ due_date: '2026-06-06' }), '2026-06-05', 'nl')).toContain('Morgen');
    expect(renderReminder(task(), '2026-06-05', 'nl').toLowerCase()).toContain('klaar');
  });

  it('falls back to English for unsupported languages', () => {
    expect(renderReminder(task(), '2026-06-05', 'de')).toContain('In 4 days');
  });
});

describe('renderStopAck', () => {
  it('acknowledges without persuasion or a follow-up question', () => {
    const ack = renderStopAck();
    expect(ack.toLowerCase()).toContain("won't send");
    expect(ack).not.toContain('?');
  });

  it('acknowledges in Dutch when the session language is nl', () => {
    const ack = renderStopAck('nl');
    expect(ack.toLowerCase()).toContain('herinneringen');
    expect(ack).not.toContain('?');
  });
});

describe('stopRequested', () => {
  it('detects standalone stop and stop phrases (en + nl)', () => {
    expect(stopRequested('stop')).toBe(true);
    expect(stopRequested('STOP.')).toBe(true);
    expect(stopRequested('please send no more messages')).toBe(true);
    expect(stopRequested('geen berichten meer aub')).toBe(true);
  });
  it('does not fire on normal text mentioning stop', () => {
    expect(stopRequested('I need to stop by the municipality first')).toBe(false);
  });
});
