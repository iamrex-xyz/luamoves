import { describe, it, expect } from 'vitest';
import { renderTasklistPage } from '../src/web/tasklistPage.js';
import type { TaskRow, UserRow } from '../src/types/db.js';

function task(p: Partial<TaskRow>): TaskRow {
  return {
    id: 'id', user_id: 'u1', task_key: 'k', title: 'Taak', status: 'pending',
    due_date: '2026-08-01', affiliate_trigger: null, completed_via: null,
    phase_order: 1, phase_name: 'Net rond', category: 'Administratie',
    explanation: 'uitleg', tip: 'tip', sort_order: 1, created_at: '', updated_at: '', ...p,
  };
}

const user: UserRow = {
  id: 'u1', phone: '+316', name: 'Sanne', move_date: '2026-08-01', move_type: 'rent',
  from_address: null, to_address: null, home_type: null, household: null, notice_given: false,
  language: 'nl', language_locked: false, recent_languages: [], onboarding_step: 'completed', tasklist_token: 'tok123', safety_paused_at: null,
  reminders_opt_out: false, created_at: '', updated_at: '',
};

describe('renderTasklistPage', () => {
  const tasks = [
    task({ id: 't1', phase_name: 'Net rond', title: 'Eerste taak', status: 'completed', sort_order: 1 }),
    task({ id: 't2', phase_name: 'Net rond', title: 'Tweede taak', sort_order: 2 }),
    task({ id: 't3', phase_name: 'Verhuisdag', title: 'Derde taak', phase_order: 6, sort_order: 3 }),
  ];

  it('renders tasks grouped under phase headings', () => {
    const html = renderTasklistPage(user, tasks);
    expect(html).toContain('<h2>Net rond</h2>');
    expect(html).toContain('<h2>Verhuisdag</h2>');
    expect(html).toContain('Eerste taak');
    expect(html).toContain('data-id="t3"');
  });

  it('shows progress (completed / total) and embeds the token for write-back', () => {
    const html = renderTasklistPage(user, tasks);
    expect(html).toContain('van 3 afgerond');
    expect(html).toContain('>1<'); // doneCount
    expect(html).toContain('"tok123"'); // token in the inline script
  });

  it('marks completed tasks and pre-checks their box', () => {
    const html = renderTasklistPage(user, tasks);
    expect(html).toMatch(/class="task done" data-id="t1"/);
    expect(html).toContain('checked');
  });

  it('escapes user-provided content', () => {
    const html = renderTasklistPage({ ...user, name: '<script>x</script>' }, []);
    expect(html).not.toContain('<script>x</script>');
    expect(html).toContain('&lt;script&gt;');
    expect(html).toContain('Je checklist is nog leeg.');
  });
});
