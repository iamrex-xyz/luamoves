import { describe, it, expect } from 'vitest';
import { fixDoubledScheme } from '../src/utils/url.js';

describe('fixDoubledScheme', () => {
  it('collapses a doubled scheme (the prod checklist-link bug)', () => {
    expect(fixDoubledScheme('https://https://lua-moves.vercel.app/tasklist?token=x')).toBe(
      'https://lua-moves.vercel.app/tasklist?token=x',
    );
    expect(fixDoubledScheme('http://http://example.com')).toBe('http://example.com');
  });

  it('leaves a correct single-scheme URL untouched', () => {
    expect(fixDoubledScheme('https://lua-moves.vercel.app/tasklist?token=x')).toBe(
      'https://lua-moves.vercel.app/tasklist?token=x',
    );
    expect(fixDoubledScheme('http://localhost:3000/tasklist/abc')).toBe('http://localhost:3000/tasklist/abc');
  });
});
