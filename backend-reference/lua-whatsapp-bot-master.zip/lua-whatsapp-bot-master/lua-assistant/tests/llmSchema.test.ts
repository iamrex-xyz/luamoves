import { describe, it, expect } from 'vitest';
import {
  buildReplySchema,
  normalizeSignals,
  llmReplySchema,
  type ReplySchemaState,
} from '../src/types/llm.js';

const STATES: Record<string, ReplySchemaState> = {
  onboarding: { onboardingActive: true, completed: false, paused: false, offerEligible: false, offerPending: false },
  completed: { onboardingActive: false, completed: true, paused: false, offerEligible: false, offerPending: false },
  completedOffer: { onboardingActive: false, completed: true, paused: false, offerEligible: true, offerPending: false },
  completedPending: { onboardingActive: false, completed: true, paused: false, offerEligible: false, offerPending: true },
  paused: { onboardingActive: false, completed: false, paused: true, offerEligible: false, offerPending: false },
};

/** Keys present under `signals` for a built schema. */
function signalKeys(state: ReplySchemaState): string[] {
  const schema = buildReplySchema(state) as any;
  return Object.keys(schema.shape.signals.shape).sort();
}

describe('buildReplySchema — group inclusion per state', () => {
  it('always includes the safety/language base signals', () => {
    for (const state of Object.values(STATES)) {
      const keys = signalKeys(state);
      for (const base of ['crisis', 'jailbreak', 'off_topic', 'detected_language', 'requested_language', 'stop_reminders']) {
        expect(keys).toContain(base);
      }
    }
  });

  it('onboarding turn: full onboarding, no checklist/affiliate/safety', () => {
    const keys = signalKeys(STATES.onboarding);
    expect(keys).toContain('onboarding');
    expect(keys).not.toContain('checklist');
    expect(keys).not.toContain('affiliate');
    expect(keys).not.toContain('safety');
  });

  it('completed turn: onboarding (nullable) + checklist, but no affiliate/safety', () => {
    const keys = signalKeys(STATES.completed);
    expect(keys).toContain('onboarding');
    expect(keys).toContain('checklist');
    expect(keys).not.toContain('affiliate');
    expect(keys).not.toContain('safety');
  });

  it('completed onboarding group is nullable (cheap no-correction turn)', () => {
    const schema = buildReplySchema(STATES.completed);
    const parsed = schema.safeParse({
      reply: 'hoi',
      signals: {
        crisis: false,
        jailbreak: false,
        off_topic: false,
        detected_language: null,
        requested_language: null,
        stop_reminders: false,
        onboarding: null,
        checklist: {
          task_completed: false,
          task_done_key: null,
          task_reschedule_key: null,
          task_new_due_date: null,
          wants_dashboard: false,
        },
      },
    });
    expect(parsed.success).toBe(true);
  });

  it('affiliate group appears when an offer is eligible OR pending (the "ja" turn)', () => {
    expect(signalKeys(STATES.completed)).not.toContain('affiliate');
    expect(signalKeys(STATES.completedOffer)).toContain('affiliate');
    // Pending: the keyword-less accept/decline turn still needs the affiliate group.
    expect(signalKeys(STATES.completedPending)).toContain('affiliate');
  });

  it('safety (resume_ok) group appears only while paused', () => {
    expect(signalKeys(STATES.completed)).not.toContain('safety');
    expect(signalKeys(STATES.paused)).toContain('safety');
  });
});

describe('normalizeSignals — always returns the full shape', () => {
  it('fills every group with safe defaults from an empty object', () => {
    const sig = normalizeSignals({});
    expect(sig).toEqual({
      crisis: false,
      jailbreak: false,
      off_topic: false,
      detected_language: null,
      requested_language: null,
      stop_reminders: false,
      onboarding: {
        name: null,
        move_date: null,
        move_type: null,
        from_address: null,
        to_address: null,
        home_type: null,
        household: null,
        date_unclear: false,
        no_longer_moving: false,
      },
      checklist: {
        task_completed: false,
        task_done_key: null,
        task_reschedule_key: null,
        task_new_due_date: null,
        wants_dashboard: false,
      },
      safety: { resume_ok: false },
      affiliate: { offered: null, user_declined: false, user_accepted: false },
    });
  });

  it('handles null/undefined input without throwing', () => {
    expect(() => normalizeSignals(null)).not.toThrow();
    expect(() => normalizeSignals(undefined)).not.toThrow();
    expect(normalizeSignals(null).onboarding.name).toBe(null);
  });

  it('coerces a null onboarding group to the full default shape', () => {
    const sig = normalizeSignals({
      onboarding: null,
      checklist: { task_completed: true, task_done_key: 'x' },
    });
    expect(sig.onboarding.no_longer_moving).toBe(false);
    expect(sig.checklist.task_completed).toBe(true);
    expect(sig.checklist.task_done_key).toBe('x');
  });

  it('defaults checklist.task_completed to false when omitted', () => {
    expect(normalizeSignals({}).checklist.task_completed).toBe(false);
    expect(normalizeSignals({}).checklist.task_done_key).toBe(null);
  });

  it('normalizes checklist.wants_dashboard (defaults false, preserves true)', () => {
    expect(normalizeSignals({}).checklist.wants_dashboard).toBe(false);
    expect(
      normalizeSignals({ checklist: { wants_dashboard: true } }).checklist.wants_dashboard,
    ).toBe(true);
  });

  it('preserves a populated onboarding correction', () => {
    const sig = normalizeSignals({ onboarding: { move_date: '2026-07-16', no_longer_moving: false } });
    expect(sig.onboarding.move_date).toBe('2026-07-16');
    expect(sig.onboarding.name).toBe(null);
  });

  it('preserves safety + affiliate signals when present', () => {
    const sig = normalizeSignals({
      safety: { resume_ok: true },
      affiliate: { offered: 'energy', user_declined: true },
    });
    expect(sig.safety.resume_ok).toBe(true);
    expect(sig.affiliate.offered).toBe('energy');
    expect(sig.affiliate.user_declined).toBe(true);
  });

  it('output always satisfies the canonical full schema (signals only)', () => {
    const full = llmReplySchema.shape.signals;
    expect(full.safeParse(normalizeSignals({})).success).toBe(true);
    expect(full.safeParse(normalizeSignals({ crisis: true })).success).toBe(true);
  });
});
