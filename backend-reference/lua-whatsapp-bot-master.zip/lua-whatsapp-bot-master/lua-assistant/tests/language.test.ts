import { describe, it, expect } from 'vitest';
import { normalizeLanguageCode, languageName, majorityLanguage, guessLanguage } from '../src/utils/language.js';
import { buildLanguageDirective } from '../src/features/conversation/promptBuilder.js';
import { decideSessionLanguage } from '../src/features/language/detect.js';
import { renderWelcome } from '../src/templates/welcome.js';
import type { UserRow } from '../src/types/db.js';

function user(p: Partial<UserRow> = {}): UserRow {
  return {
    id: 'u1', phone: '+316', name: null, move_date: null, move_type: null,
    from_address: null, to_address: null, home_type: null, household: null,
    notice_given: false, language: 'nl', language_locked: false, recent_languages: [],
    onboarding_step: 'start', tasklist_token: 't', safety_paused_at: null,
    reminders_opt_out: false, created_at: '', updated_at: '', ...p,
  };
}

describe('normalizeLanguageCode', () => {
  it('cleans codes and rejects junk', () => {
    expect(normalizeLanguageCode('nl')).toBe('nl');
    expect(normalizeLanguageCode('EN')).toBe('en');
    expect(normalizeLanguageCode('nl-NL')).toBe('nl');
    expect(normalizeLanguageCode(null)).toBeNull();
    expect(normalizeLanguageCode('1')).toBeNull();
    expect(normalizeLanguageCode('123')).toBeNull();
  });
});

describe('languageName', () => {
  it('resolves English names for codes', () => {
    expect(languageName('nl')).toBe('Dutch');
    expect(languageName('en')).toBe('English');
    expect(languageName('de')).toBe('German');
  });
});

describe('majorityLanguage', () => {
  it('returns null for an empty window', () => {
    expect(majorityLanguage([])).toBeNull();
  });
  it('picks the most-used language', () => {
    expect(majorityLanguage(['nl', 'en', 'nl'])).toBe('nl');
    expect(majorityLanguage(['en', 'en', 'nl', 'en'])).toBe('en');
  });
  it('does not flip on a single stray message', () => {
    // Four Dutch, one English mixed in → stays Dutch.
    expect(majorityLanguage(['nl', 'nl', 'en', 'nl', 'nl'])).toBe('nl');
  });
  it('breaks ties toward the more recent language', () => {
    expect(majorityLanguage(['en', 'nl'])).toBe('nl');
    expect(majorityLanguage(['nl', 'nl', 'en', 'en'])).toBe('en');
  });
});

describe('guessLanguage (fast, LLM-free first-message guess)', () => {
  it('picks English for clear English greetings/sentences', () => {
    expect(guessLanguage('Hi')).toBe('en');
    expect(guessLanguage('Hello how are you')).toBe('en');
    expect(guessLanguage("Hi, what's your name?")).toBe('en');
  });

  it('picks Dutch for clear Dutch greetings/sentences', () => {
    expect(guessLanguage('Hoi')).toBe('nl');
    expect(guessLanguage('Hallo, ik wil graag verhuizen')).toBe('nl');
    expect(guessLanguage('Wat is je naam?')).toBe('nl');
  });

  it('defaults to Dutch when ambiguous or unknown', () => {
    expect(guessLanguage('')).toBe('nl');
    expect(guessLanguage('👋')).toBe('nl');
    expect(guessLanguage('12 St Street')).toBe('nl');
  });
});

describe('renderWelcome (exact client copy, language-picked, 3 bubbles)', () => {
  it('returns 3 ordered messages in Dutch by default and English for en', () => {
    const nl = renderWelcome('nl');
    expect(nl).toHaveLength(3);
    expect(nl[0]).toContain('Ik ben Lua');
    expect(nl[2]).toContain('Wat is je naam?'); // name ask is the LAST bubble

    const en = renderWelcome('en');
    expect(en).toHaveLength(3);
    expect(en[0]).toContain("I'm Lua");
    expect(en[2]).toContain("What's your name?");

    expect(renderWelcome(null)[0]).toContain('Ik ben Lua'); // default → NL
  });
});

// NOTE: REPLY_LANGUAGE is empty in the test env, so the forced-override branch
// isn't exercised here; we cover the detect (first contact) + established modes.
describe('buildLanguageDirective', () => {
  it('asks the model to detect + reply in the user\'s own language on first contact', () => {
    const d = buildLanguageDirective(user({ recent_languages: [] }));
    expect(d).toContain('Detect the language');
    expect(d).toContain('Do NOT default to Dutch');
    expect(d).toContain('detected_language');
  });

  it('pins replies to the established session language but allows an explicit switch', () => {
    const d = buildLanguageDirective(user({ language: 'de', recent_languages: ['de', 'de'] }));
    expect(d).toContain('German');
    expect(d).toContain('no mixing');
    expect(d).toContain('EXCEPTION');
    expect(d).toContain('requested_language');
  });
});

describe('decideSessionLanguage (detect once, then lock — no drift)', () => {
  it('locks an unlocked session from the first detected language', () => {
    const u = decideSessionLanguage(user({ language: 'nl', recent_languages: [] }), 'en', null);
    expect(u).toEqual({ language: 'en', recent_languages: ['en'], switched: true });
  });

  it('never drifts once locked, even on a sustained switch of detected language', () => {
    // Locked to Dutch; the user writes English (a name/address misread, or a few
    // English messages) — the reply language must stay locked, no drift.
    expect(
      decideSessionLanguage(user({ language: 'nl', recent_languages: ['nl'] }), 'en', null),
    ).toBeNull();
  });

  it('honours an explicit switch request even from a locked session', () => {
    const u = decideSessionLanguage(
      user({ language: 'nl', recent_languages: ['nl'] }),
      'nl', // they wrote in Dutch but asked for English
      'en',
    );
    expect(u).toEqual({ language: 'en', recent_languages: ['en'], switched: true });
  });

  it('locks an unlocked session on an explicit request (no detection yet)', () => {
    const u = decideSessionLanguage(user({ language: 'nl', recent_languages: [] }), null, 'en');
    expect(u).toEqual({ language: 'en', recent_languages: ['en'], switched: true });
  });

  it('returns null when the explicit request matches the locked language', () => {
    expect(
      decideSessionLanguage(user({ language: 'en', recent_languages: ['en'] }), 'en', 'en'),
    ).toBeNull();
  });

  it('returns null when an unlocked turn is ambiguous (no detected language)', () => {
    expect(decideSessionLanguage(user({ recent_languages: [] }), null, null)).toBeNull();
  });
});
