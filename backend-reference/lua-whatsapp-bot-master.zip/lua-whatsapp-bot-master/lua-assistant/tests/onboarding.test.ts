import { describe, it, expect } from 'vitest';
import { decide, classifyMoveDate } from '../src/features/onboarding/stateMachine.js';
import { nextStepAfter, currentStep } from '../src/features/onboarding/steps.js';
import { renderDateInPast } from '../src/templates/date.js';
import type { OnboardingSignals } from '../src/types/llm.js';

const NOW = new Date('2026-06-04T12:00:00Z');

/** Build a full onboarding-signals object (all keys present), with overrides. */
function sig(partial: Partial<OnboardingSignals> = {}): OnboardingSignals {
  return {
    name: null,
    move_date: null,
    move_type: null,
    from_address: null,
    to_address: null,
    home_type: null,
    household: null,
    date_unclear: false,
    no_longer_moving: false,
    ...partial,
  };
}

describe('onboarding steps', () => {
  it('orders steps and maps start → name', () => {
    expect(currentStep('start')).toBe('name');
    expect(currentStep('move_type')).toBe('move_type');
    expect(nextStepAfter('name')).toBe('move_date');
    expect(nextStepAfter('household')).toBe('completed');
  });
});

describe('onboarding decide()', () => {
  it('captures the name and advances', () => {
    const d = decide('name', sig({ name: 'Sam' }), NOW);
    expect(d.patch.name).toBe('Sam');
    expect(d.advanced).toBe(true);
    expect(d.nextStep).toBe('move_date');
  });

  it('does not advance when the current step is unanswered', () => {
    const d = decide('name', sig({ move_type: 'rent' }), NOW);
    expect(d.advanced).toBe(false);
    expect(d.nextStep).toBe('name');
    // but a provided field is still written (correction-friendly)
    expect(d.patch.move_type).toBe('rent');
  });

  it('rejects a greeting wrongly proposed as a name (does not store or advance)', () => {
    // The real prod bug: the model put its own "Nice to meet you!" into name.
    for (const bad of ['Nice to meet you!', 'Hi', 'hello there', 'thanks', 'Ok']) {
      const d = decide('name', sig({ name: bad }), NOW);
      expect(d.patch.name).toBeUndefined();
      expect(d.advanced).toBe(false);
    }
  });

  it('rejects name-like junk (digits, long sentences) but accepts real names', () => {
    expect(decide('name', sig({ name: 'I am moving in July 2026' }), NOW).patch.name).toBeUndefined();
    expect(decide('name', sig({ name: 'Anne-Marie' }), NOW).patch.name).toBe('Anne-Marie');
    expect(decide('name', sig({ name: 'Jan de Vries' }), NOW).patch.name).toBe('Jan de Vries');
  });

  it('accepts a clear future date', () => {
    const d = decide('move_date', sig({ move_date: '2026-08-01' }), NOW);
    expect(d.patch.move_date).toBe('2026-08-01');
    expect(d.advanced).toBe(true);
    expect(d.moveDateStatus).toBe('future');
  });

  it('rejects a past date (no advance) and flags it as past', () => {
    const d = decide('move_date', sig({ move_date: '2020-01-01' }), NOW);
    expect(d.patch.move_date).toBeUndefined();
    expect(d.advanced).toBe(false);
    expect(d.moveDateStatus).toBe('past');
  });

  it('rejects a vague date (date_unclear) and flags it unclear', () => {
    const d = decide('move_date', sig({ move_date: '2026-08-01', date_unclear: true }), NOW);
    expect(d.patch.move_date).toBeUndefined();
    expect(d.advanced).toBe(false);
    expect(d.moveDateStatus).toBe('unclear');
  });

  it('stores unknown new address as null and advances', () => {
    const d = decide('to_address', sig({ to_address: 'unknown' }), NOW);
    expect(d.patch.to_address).toBeNull();
    expect(d.advanced).toBe(true);
    expect(d.nextStep).toBe('home_type');
  });

  it('completes after household', () => {
    const d = decide('household', sig({ household: 'partner + 1 kat' }), NOW);
    expect(d.patch.household).toEqual({ description: 'partner + 1 kat' });
    expect(d.advanced).toBe(true);
    expect(d.nextStep).toBe('completed');
    expect(d.justCompleted).toBe(true);
  });

  it('pauses when the user is no longer moving', () => {
    const d = decide('move_date', sig({ no_longer_moving: true }), NOW);
    expect(d.paused).toBe(true);
    expect(d.patch.onboarding_step).toBe('paused');
    expect(d.advanced).toBe(false);
  });

  it('applies a correction to an earlier field without advancing', () => {
    // On home_type step, user corrects the destination city.
    const d = decide('home_type', sig({ to_address: 'Rotterdam' }), NOW);
    expect(d.patch.to_address).toBe('Rotterdam');
    expect(d.advanced).toBe(false);
    expect(d.nextStep).toBe('home_type');
  });
});

describe('classifyMoveDate (deterministic past/future — backend, not the model)', () => {
  it('treats a later-this-year date as FUTURE (the exact prod bug)', () => {
    // Today June 16 2026; "August" is later the same year → future, NOT passed.
    const today = new Date('2026-06-16T10:00:00Z');
    expect(classifyMoveDate(sig({ move_date: '2026-08-23' }), today)).toBe('future');
    expect(classifyMoveDate(sig({ move_date: '2026-08-02' }), today)).toBe('future');
  });

  it('treats today as future (not past) and earlier dates as past', () => {
    const today = new Date('2026-06-16T10:00:00Z');
    expect(classifyMoveDate(sig({ move_date: '2026-06-16' }), today)).toBe('future');
    expect(classifyMoveDate(sig({ move_date: '2026-06-15' }), today)).toBe('past');
  });

  it('flags vague / unparseable / absent dates', () => {
    const today = new Date('2026-06-16T10:00:00Z');
    expect(classifyMoveDate(sig({ move_date: '2026-08-01', date_unclear: true }), today)).toBe('unclear');
    expect(classifyMoveDate(sig({ move_date: 'next summer' }), today)).toBe('unclear');
    expect(classifyMoveDate(sig({ move_date: null }), today)).toBe('none');
  });
});

describe('renderDateInPast (code-owned wording)', () => {
  it('states the past date and today, in the session language', () => {
    const en = renderDateInPast('2026-05-01', '2026-06-16', 'en');
    expect(en).toContain('2026-05-01');
    expect(en).toContain('2026-06-16');
    expect(en.toLowerCase()).toContain('passed');

    const nl = renderDateInPast('2026-05-01', '2026-06-16', 'nl');
    expect(nl.toLowerCase()).toContain('al geweest');
  });
});
