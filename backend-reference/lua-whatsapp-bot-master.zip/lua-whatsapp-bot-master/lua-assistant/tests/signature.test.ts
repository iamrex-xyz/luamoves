import { describe, it, expect, beforeAll } from 'vitest';
import { createHash, createHmac } from 'node:crypto';

const KEY = 'test-signing-key';
const TS = '1700000000';
const URL = 'https://tunnel.example.com/webhook';

// Build a valid signature exactly as Bird does:
//   payload = `${ts}\n${url}\n` + SHA256(body bytes);  base64(HMAC_SHA256(key, payload))
function sign(body: Buffer): string {
  const bodyHash = createHash('sha256').update(body).digest();
  const payload = Buffer.concat([Buffer.from(`${TS}\n${URL}\n`, 'utf8'), bodyHash]);
  return createHmac('sha256', KEY).update(payload).digest('base64');
}

type Verify = typeof import('../src/services/bird.service.js').verifyWebhookSignature;
let verifyWebhookSignature: Verify;

beforeAll(async () => {
  process.env.BIRD_WEBHOOK_SIGNING_KEY = KEY; // set before config loads
  ({ verifyWebhookSignature } = await import('../src/services/bird.service.js'));
});

describe('verifyWebhookSignature', () => {
  const body = Buffer.from(JSON.stringify({ event: 'whatsapp.inbound', payload: { id: 'x' } }));

  it('accepts a correctly signed request', () => {
    expect(
      verifyWebhookSignature({
        signatureHeader: sign(body),
        timestampHeader: TS,
        url: URL,
        rawBody: body,
      }),
    ).toBe(true);
  });

  it('rejects a tampered body', () => {
    expect(
      verifyWebhookSignature({
        signatureHeader: sign(body),
        timestampHeader: TS,
        url: URL,
        rawBody: Buffer.from('tampered'),
      }),
    ).toBe(false);
  });

  it('rejects a wrong/garbage signature', () => {
    expect(
      verifyWebhookSignature({
        signatureHeader: 'AAAAAAAA',
        timestampHeader: TS,
        url: URL,
        rawBody: body,
      }),
    ).toBe(false);
  });

  it('rejects when headers are missing', () => {
    expect(
      verifyWebhookSignature({
        signatureHeader: undefined,
        timestampHeader: undefined,
        url: URL,
        rawBody: body,
      }),
    ).toBe(false);
  });

  it('rejects when the signed URL differs', () => {
    expect(
      verifyWebhookSignature({
        signatureHeader: sign(body),
        timestampHeader: TS,
        url: 'https://evil.example.com/webhook',
        rawBody: body,
      }),
    ).toBe(false);
  });
});
