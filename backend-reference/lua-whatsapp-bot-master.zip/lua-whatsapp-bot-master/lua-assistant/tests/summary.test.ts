import { describe, it, expect } from 'vitest';
import { renderSummary } from '../src/templates/summary.js';
import type { UserRow } from '../src/types/db.js';

function user(overrides: Partial<UserRow> = {}): UserRow {
  return {
    id: 'u1',
    phone: '+31600000000',
    name: 'Sam',
    move_date: '2026-08-01',
    move_type: 'rent',
    from_address: 'Damstraat 1, 1012 AB Amsterdam',
    to_address: 'Coolsingel 2, 3011 AD Rotterdam',
    home_type: 'apartment',
    household: { description: 'partner + 1 cat' },
    notice_given: false,
    language: 'nl',
    onboarding_step: 'completed',
    tasklist_token: 'tok123',
    created_at: '',
    updated_at: '',
    ...overrides,
  };
}

describe('renderSummary (client copy, localised)', () => {
  it('renders the Dutch copy with Dutch labels by default', () => {
    const out = renderSummary(user());
    expect(out).toContain('Oké, ik weet voorlopig genoeg om je te helpen!');
    expect(out).toContain('Je verhuizing in het kort:');
    expect(out).toContain('Naam: Sam');
    expect(out).toContain('Verhuisdatum: 2026-08-01');
    expect(out).toContain('Type: huur'); // rent → huur
    expect(out).toContain('Van: Damstraat 1, 1012 AB Amsterdam');
    expect(out).toContain('Naar: Coolsingel 2, 3011 AD Rotterdam');
    expect(out).toContain('Woningtype: apartment');
    expect(out).toContain('Huishouden: partner + 1 cat');
    expect(out).toContain('Heb je nu nog vragen?');
    expect(out).toContain('tok123'); // tasklist URL token present
  });

  it('renders the English copy when the session language is en', () => {
    const out = renderSummary(user({ language: 'en' }));
    expect(out).toContain('Okay, I know enough for now to help you!');
    expect(out).toContain('Moving date: 2026-08-01');
    expect(out).toContain('Type: Rental');
    expect(out).toContain('Any questions right now?');
  });

  it('maps buy → koop / Purchase and an unknown destination', () => {
    expect(renderSummary(user({ move_type: 'buy', to_address: null }))).toContain('Type: koop');
    expect(renderSummary(user({ move_type: 'buy', to_address: null }))).toContain('Naar: onbekend');
    expect(renderSummary(user({ language: 'en', move_type: 'buy', to_address: null }))).toContain(
      'To: unknown',
    );
  });
});
