#!/usr/bin/env python3
"""Generate migrations/0006_master_tasklist.sql from the client's master task
list (requirement-docs/lua-takenlijst.xlsx). Re-run this whenever the client
ships an updated spreadsheet — the migration is fully derived, never hand-edited.

Run from the lua-assistant/ directory:  python3 scripts/gen_tasklist_migration.py
"""
import zipfile, unicodedata, re, xml.etree.ElementTree as ET
from pathlib import Path

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
XLSX = Path('../requirement-docs/lua-takenlijst.xlsx')
OUT = Path('migrations/0006_master_tasklist.sql')

MOVE_TYPE = {'huur': 'rent', 'koop': 'buy'}
AFFILIATE = {  # Dutch trigger -> our offer key (monetization.md)
    'verhuisbedrijf': 'moving_company', 'energie': 'energy',
    'internet': 'internet', 'verzekering': 'insurance',
}


def read_rows():
    z = zipfile.ZipFile(XLSX)
    shared = []
    r = ET.fromstring(z.read('xl/sharedStrings.xml'))
    for si in r.findall(f'{NS}si'):
        shared.append(''.join(t.text or '' for t in si.iter(f'{NS}t')))
    sheet = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))

    def colnum(ref):
        c = ''.join(ch for ch in ref if ch.isalpha()); n = 0
        for ch in c:
            n = n * 26 + (ord(ch) - 64)
        return n - 1

    rows = []
    for row in sheet.iter(f'{NS}row'):
        cells = {}
        for c in row.findall(f'{NS}c'):
            v = c.find(f'{NS}v'); txt = ''
            if v is not None:
                txt = shared[int(v.text)] if c.get('t') == 's' else v.text
            cells[colnum(c.get('r'))] = (txt or '').strip()
        if cells:
            rows.append([cells.get(i, '') for i in range(max(cells) + 1)])
    return rows


def slug(s):
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode()
    s = re.sub(r'[^a-z0-9]+', '_', s.lower()).strip('_')
    return s[:48]


def sql(v):
    if v is None or v == '':
        return 'null'
    return "'" + str(v).replace("'", "''") + "'"


def main():
    rows = read_rows()
    header = [h.strip() for h in rows[0]]
    idx = {name: i for i, name in enumerate(header)}
    get = lambda r, name: r[idx[name]] if idx[name] < len(r) else ''

    seen = set()
    values = []
    for n, r in enumerate(rows[1:], start=1):
        mt = MOVE_TYPE[get(r, 'type')]
        title = get(r, 'titel taak')
        key = f"{mt}_{slug(title)}"
        while key in seen:
            key += '_x'
        seen.add(key)
        aff = AFFILIATE.get(get(r, 'affiliate'), None)
        values.append((
            key, mt, int(get(r, 'fase_volgorde')), get(r, 'fase naam'),
            get(r, 'categorie'), title, get(r, 'uitleg taak'),
            get(r, 'tip'), get(r, 'conditie'), aff, n,
        ))

    cols = ('task_key, move_type, phase_order, phase_name, category, title, '
            'explanation, tip, condition, affiliate_trigger, sort_order')
    lines = []
    for v in values:
        cells = [sql(v[0]), sql(v[1]), str(v[2]), sql(v[3]), sql(v[4]), sql(v[5]),
                 sql(v[6]), sql(v[7]), sql(v[8]), sql(v[9]), str(v[10])]
        lines.append('  (' + ', '.join(cells) + ')')

    out = f"""-- Lua — master task list (plan.md §10, Day 7).
-- GENERATED from requirement-docs/lua-takenlijst.xlsx by
-- scripts/gen_tasklist_migration.py — do not hand-edit; re-run the script when
-- the client ships an updated spreadsheet. Supersedes the v1 seed (0003).
--
-- The client's list is PHASE-based (fase 1..7), not date-based. Due dates are
-- derived in code from phase_order (features/checklist/generate.ts). Conditions:
-- 'altijd' + verbouwing/hoog/parkeren apply to everyone; kinderen/huisdieren are
-- gated on the household answer. Content is the client's Dutch copy, used verbatim.

alter table task_templates
  drop column if exists applies_to,
  drop column if exists offset_days,
  add column if not exists move_type   text check (move_type in ('rent','buy')),
  add column if not exists phase_order int,
  add column if not exists phase_name  text,
  add column if not exists category    text,
  add column if not exists explanation text,
  add column if not exists tip         text,
  add column if not exists condition   text,
  add column if not exists sort_order  int;

alter table checklist_tasks
  add column if not exists phase_order int,
  add column if not exists phase_name  text,
  add column if not exists category    text,
  add column if not exists explanation text,
  add column if not exists tip         text,
  add column if not exists sort_order  int;

-- Replace the v1 seed wholesale.
delete from task_templates;

insert into task_templates ({cols}) values
""" + ',\n'.join(lines) + ';\n'

    OUT.write_text(out)
    print(f"wrote {OUT} — {len(values)} tasks "
          f"({sum(1 for v in values if v[1]=='rent')} rent / "
          f"{sum(1 for v in values if v[1]=='buy')} buy)")


if __name__ == '__main__':
    main()
