# RUN

> Keep this file short and precise — run commands only.
> Docs: [README.md](README.md) · logging: [logging/README.md](logging/README.md)

Prereq: `cp .env.example .env` and fill values.

## Make (shortcuts)
```bash
make local        # app only (local)
make local-logs   # app + logging (local)
make prod         # app only (production)
make prod-logs    # app + logging (production)
make down         # stop app
make down-logs    # stop logging
make down-all     # stop everything
make ps           # show services + ports
```

## Local — without logging
```bash
docker compose up -d --build
```

## Local — with logging
```bash
docker compose up -d --build
docker compose -f docker-compose.logging.yml up -d
```

## Prod — without logging
Set `NODE_ENV=production` and `LOG_FORMAT=json` in `.env`, then:
```bash
docker compose up -d --build
```

## Prod — with logging
Set `NODE_ENV=production` and `LOG_FORMAT=json` in `.env`, then:
```bash
docker compose up -d --build
docker compose -f docker-compose.logging.yml up -d
```

## Stop
```bash
docker compose down                                  # app
docker compose -f docker-compose.logging.yml down    # logging (app unaffected)
```
