# CLAUDE.md — Lua WhatsApp Moving Assistant

Guidance for any AI/coding agent working in this repository. Read this first, every time.

---

## 🚫 Hard rules (never break these)

1. **`requirement-docs/` is READ-ONLY.** Never create, edit, move, rename, or delete anything inside `requirement-docs/` (including `requirement-docs/config-files/`). It is the client's source material. Read it freely; change nothing.
2. **Do NOT edit `plan.md` or `7-day-implementation-plan.md` on your own.** These two files change **only when the user explicitly asks** for a change to them. Never "improve", reformat, or update them proactively — even if you think they're outdated. If you believe something should change, **tell the user and wait for instruction.**
3. **Behaviour spec is used verbatim.** The config files in `requirement-docs/config-files/` (`SOUL.md`, `flow.md`, `instructions.md`, `knowledge.md`, `monetization.md`, `privacy.md`) define Lua's behaviour. Use them as-is; do not rewrite Lua's personality, tone, or rules.
4. **All application code lives in `lua-assistant/`.** Never scatter code in the repo root or inside `requirement-docs/`.

---

## 📁 Key documents (the source of truth)

| File | Purpose | Editable? |
|---|---|---|
| `plan.md` | Architecture reference — **what** we build & **how** | Only when user asks |
| `7-day-implementation-plan.md` | Day-by-day execution guide | Only when user asks |
| `requirement-docs/` | Client briefing + behaviour config files | **Read-only** |
| `CLAUDE.md` | This file — working rules | Only when user asks |

Always read `plan.md` (architecture) and the relevant day in `7-day-implementation-plan.md` before writing code.

---

## What we're building (1 line)

A Dutch-language WhatsApp moving assistant: **backend orchestration** connecting Bird (WhatsApp) → our webhook → an LLM (OpenRouter, `SOUL.md` as system prompt) → back to Bird, plus memory, checklist, reminders, affiliate logic, and a task-list web page. (OpenClaw was dropped; Supabase is provided by the client, not hosted by us.)

---

## Core principle

> **The LLM proposes, the backend disposes.**

The LLM only writes natural-language conversation. Every hard guarantee — max 1 reminder/day, the affiliate 1-in-5 guard, exact-format messages, crisis routing, never promising savings, 24h session window — is enforced in **deterministic TypeScript**, never left to the model.

Messages that must be **exact** are **code-rendered templates**, not LLM output: onboarding summary, crisis message, affiliate disclosure, off-topic deflection, jailbreak reply.

---

## Tech stack (locked)

- **Node.js + TypeScript + Express**
- **Vercel AI SDK** + `@openrouter/ai-sdk-provider` (thin LLM layer — not LangChain)
- Models from env: `MAIN_MODEL` (default `openai/gpt-4.1-mini`), `SUMMARY_MODEL` (default `openai/gpt-4.1-nano`) — **never hard-code a model**
- **Supabase** (Postgres) — client-provided connection; we only connect + define migrations
- **BullMQ + Redis** — reminder queue only
- **Docker + docker-compose** — `app` + `redis` + `worker` (no Supabase in our compose)

---

## Project structure (inside `lua-assistant/`)

Mental model: **Routes receive HTTP → Features do the thinking → Services & Repositories talk to the outside world.**

```
src/
  config/        # env (Zod-validated) + loads prompt files at boot
  routes/        # thin HTTP endpoints (webhook, tasklist, health)
  features/      # business logic by topic (conversation, onboarding, memory,
                 #   checklist, affiliate, reminders, safety)
  services/      # external systems: llm, bird, supabase (one file each)
  repositories/  # database access, one file per table
  prompts/       # SOUL.md + config files (loaded as system prompt)
  templates/     # fixed-text messages (summary, crisis, disclosure, deflection)
  web/           # task-list page
  utils/         # logger, plain-text formatter, helpers
  types/         # shared TypeScript types
migrations/      # SQL schema
```

- Add a feature → add a folder under `features/`. Keep external integrations isolated in `services/`, DB access in `repositories/`.

---

## Non-negotiable engineering rules

- **Plain text output** — strip all markdown/bold/bullets before sending to WhatsApp.
- **Stable prompt prefix** — static system prompt FIRST, per-turn dynamic data LAST (required for prompt caching; see `plan.md` §6). Never put changing values (timestamps, names, counters) inside the cached system prompt.
- **Idempotent webhook** — dedupe inbound by `message_id` (Supabase unique constraint); Bird may retry.
- **Config from env / files only** — never hard-code models, partner URLs, or the disclosure text.
- **Validate before write** — LLM-extracted data (onboarding fields, task references) must be validated in code before persisting.
- **Log decisions** — token usage incl. `cachedPromptTokens`, and why guards fired (offer suppressed, reminder skipped).
- **Test the guarantees** — unit-test the 1-in-5 guard, dedupe, disclosure-once, onboarding state machine, plain-text formatter.

---

## Safety & privacy (from the spec — always enforce)

- **Crisis** triggers → send the exact `instructions.md` message, pause flow, resume only on explicit OK. Run this check **before** normal generation.
- **Jailbreak / role-change** → fixed deflection, no engagement.
- **Sensitive data** (BSN, bank, passwords) → never request, store, or echo; ask the user not to share.
- **No advice out of scope** (legal/financial/tax) and **never promise savings** ("best price" is forbidden).

---

## Open dependencies & deferred work

- Client-provided (use v1 stand-ins until delivered): master task list, WhatsApp re-engagement template, affiliate UTM/referral params, canonical disclosure wording.
- Deferred (do not build unless asked): GDPR deletion script.
- See `plan.md` §18–§19 for the full list.

---

## When in doubt

- If a change would touch `requirement-docs/`, `plan.md`, or `7-day-implementation-plan.md` and the user didn't ask for it → **stop and ask.**
- If the spec files conflict (e.g. the disclosure wording) → follow `plan.md`'s noted resolution and flag it; don't silently pick one.
